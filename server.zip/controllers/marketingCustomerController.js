const express = require('express');
const router = express.Router();
const moment = require('moment');

module.exports = (db)=>{

    

    router.get('/getmarketingCustData',(req,res) =>{
        const getData = 'select mc.*,emp.emp_name from marketing_customer mc inner join employee emp on mc.emp_id = emp.emp_id';
        db.query(getData,(getDataErr,getDataRes)=>{
            if(getDataErr){
                res.status(500).json({getDataErr:"Marketing Customer Data could not be fetched"})
            }else{
                if(getDataRes.length === 0){
                    res.status(404).json({message:"Marketing Customer Data Not Found"})
                }else{
                    const categoryLookUp ={
                        1 : "1st Priority",
                        2 : "2nd Priority",
                        3 : "3rd Priority",
                        4 : "4th Priority"
                    }
                    const convertData = getDataRes.map((markCus) =>({
                        ...markCus,
                        follow_up_date : moment(markCus.follow_up_date).format("YYYY-MM-DD"),
                        category : categoryLookUp[markCus.category] || null
                    }))
                    res.status(200).json(convertData)
                }
            }
        })
    })


    router.get('/getmarketingEmployee',(req,res) =>{
        const getMarkEmployee = 'select * from employee where role_id = 5';
        db.query(getMarkEmployee,(dataErr,dataRes) =>{
            if(dataErr){
                res.status(500).json({dataErr:'Market Employee Data could not fetched'})
            }else{
                if(dataRes.length === 0){
                    res.status(404).json({message:"Market Employee Data not found"})
                }else{
                    res.status(200).json(dataRes)
                }
            }
        })
    })

    router.post('/postmarkCustData',(req,res) =>{
        const {mark_cust_name ,
        mark_cust_mobile ,
        mark_cust_email ,
        mark_cust_bus_name ,
        mark_cust_bus_category,
        category ,
        follow_up_date ,
        emp_id } = req.body;
        const currentDateTime = moment().format("YYYY-MM-DD HH:mm:ss");
        const insertData = `insert into marketing_customer(emp_id,mark_cust_name,mark_cust_mobile,mark_cust_email,mark_cust_bus_name,mark_cust_bus_category,category,follow_up_date,created_at) value(?,?,?,?,?,?,?,?,?)`;
        db.query(insertData,[
            emp_id,
            mark_cust_name,
            mark_cust_mobile,
            mark_cust_email,
            mark_cust_bus_name,
            mark_cust_bus_category,
            category,
            follow_up_date,
            currentDateTime
        ],(insertErr,insertRes) =>{
            if(insertErr){
                console.error("Error :",insertErr)
                res.status(500).json({insertErr:"Marketing Customer data could not be added"})
            }else{
                if (insertRes.affectedRows > 0) {
                    res.status(200).json({ message: "Marketing Customer data added successfully" });
                } else {
                    res.status(500).json({ insertErr: "Marketing Customer data could not be added" });
                }
            }
        })
    })


    router.delete('/:mark_cust_id/delete', (req, res) => {
        const mark_cust_id = req.params.mark_cust_id;
    
        const dltCust = 'DELETE FROM marketing_customer WHERE mark_cust_id = ?';
    
        db.query(dltCust, [mark_cust_id], (err, results) => {
          if (err) {
            console.error('Error deleting Customer:', err);
            res.status(500).json({ error: 'Error deleting Customer' });
          } else {
            // console.log('Employee deleted:', results);
            res.status(200).json({ message: 'Customer deleted successfully' });
          }
        });
      });


      router.put('/:mark_cust_id/update', (req, res) => {
        const mark_cust_id = req.params.mark_cust_id;
        const {
            emp_id,
            mark_cust_name,
            mark_cust_mobile,
            mark_cust_email,
            mark_cust_bus_name,
            mark_cust_bus_category,
            category,
            follow_up_date
        } = req.body;
    
        const currentDateTime = moment().format("YYYY-MM-DD HH:mm:ss");
        const updateData = `
            update marketing_customer set emp_id=?,mark_cust_name=?,mark_cust_mobile=?,mark_cust_email=?,
            mark_cust_bus_name=?,mark_cust_bus_category=?,category=?,follow_up_date=?,updated_at=? where mark_cust_id=?
        `;
    
        db.query(updateData, [
            emp_id,
            mark_cust_name,
            mark_cust_mobile,
            mark_cust_email,
            mark_cust_bus_name,
            mark_cust_bus_category,
            category,
            follow_up_date,
            currentDateTime,
            mark_cust_id
        ], (updateErr, updateRes) => {
            if (updateErr) {
                res.status(500).json({ updateErr: "Marketing Customer could not be updated" });
            } else {
                res.status(200).json({ updateRes: "Marketing Customer data updated Successfully" });
            }
        });
    });
    

    router.get('/markCustFilter', (req, res) => {
        const { mark_cust_id, emp_id, mark_cust_bus_name, category, f_date, t_date } = req.query;
    
        let filterData = `
            SELECT mc.*, e.emp_name
            FROM marketing_customer mc
            LEFT JOIN employee e ON mc.emp_id = e.emp_id
            WHERE 1=1
        `;
    
        if (mark_cust_id) {
            filterData += ` AND mc.mark_cust_id = ${mark_cust_id}`;
        }
    
        if (emp_id) {
            filterData += ` AND mc.emp_id = ${emp_id}`;
        }
    
        if (mark_cust_bus_name) {
            filterData += ` AND mc.mark_cust_bus_name = '${mark_cust_bus_name}'`;
        }
    
        if (category) {
            filterData += ` AND mc.category = ${category}`;
        }
    
        if (f_date && t_date) {
            filterData += ` AND mc.follow_up_date >= '${f_date}' AND mc.follow_up_date <= '${t_date}'`;
        }
    
        // Assuming you are using some database library (e.g., MySQL or PostgreSQL) to execute the query
        db.query(filterData, (filterErr, filterRes) => {
            if (filterErr) {
                console.error("Error :", filterErr);
                res.status(500).json({ filterErr: "Filtered Data is Not Fetched" });
            } else {
                const categoryLookUp = {
                    1: "1st Priority",
                    2: "2nd Priority",
                    3: "3rd Priority",
                    4: "4th Priority",
                };
    
                const convertData = filterRes.map((filter) => ({
                    ...filter,
                    follow_up_date: moment(filter.follow_up_date).format("YYYY-MM-DD"),
                    category: categoryLookUp[filter.category] || null,
                }));
    
                res.status(200).json(convertData);
            }
        });
    });
    

    // router.get('/markCustFilter', (req, res) => {
    //     const { mark_cust_id, emp_id, mark_cust_bus_name, category, f_date, t_date } = req.query;
      
    //     let filterData = `
    //       SELECT mc.*, e.emp_name
    //       FROM marketing_customer mc
    //       LEFT JOIN employee e ON mc.emp_id = e.emp_id
    //       WHERE 1=1
    //     `;
      
    //     const params = [];
      
    //     if (mark_cust_id) {
    //       filterData += ` AND mc.mark_cust_id = ?`;
    //       params.push(mark_cust_id);
    //     }
      
    //     if (emp_id) {
    //       filterData += ` AND mc.emp_id = ?`;
    //       params.push(emp_id);
    //     }
      
    //     if (mark_cust_bus_name) {
    //       filterData += ` AND mc.mark_cust_bus_name = ?`;
    //       params.push(mark_cust_bus_name);
    //     }
      
    //     if (category) {
    //       filterData += ` AND mc.category = ?`;
    //       params.push(category);
    //     }
      
    //     if (f_date && t_date) {
    //       // Assuming f_date and t_date are in 'YYYY-MM-DD' format
    //       filterData += ` AND mc.follow_up_date BETWEEN ? AND ?`;
    //       params.push(f_date, t_date);
    //     }
      
    //     // Assuming you are using some database library (e.g., MySQL or PostgreSQL) to execute the query
    //     db.query(filterData, params, (filterErr, filterRes) => {
    //       if (filterErr) {
    //         console.error("Error:", filterErr);
    //         res.status(500).json({ filterErr: "Filtered Data is Not Fetched" });
    //       } else {
    //         const categoryLookUp = {
    //           1: "1st Priority",
    //           2: "2nd Priority",
    //           3: "3rd Priority",
    //           4: "4th Priority",
    //         };
      
    //         const convertData = filterRes.map((filter) => ({
    //           ...filter,
    //           follow_up_date: moment(filter.follow_up_date).format("YYYY-MM-DD"),
    //           category: categoryLookUp[filter.category] || null,
    //         }));
      
    //         res.status(200).json(convertData);
    //       }
    //     });
    //   });
    

    return router;
}