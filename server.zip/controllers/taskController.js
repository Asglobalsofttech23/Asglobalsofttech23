const express = require("express");
const router = express.Router();
const moment = require("moment");

module.exports = (db) => {

  
  // Store Task Data and their employee data

  // router.post("/postTask", (req, res) => {
  //   const {
  //     pro_id,
  //     pro_module_id,
  //     sub_mod_id,
  //     pro_name,
  //     module_name,
  //     sub_module_name,
  //     task_name,
  //     task_desc,
  //     start_date,
  //     end_date,
  //     selectedEmployee,
  //   } = req.body;

  //   const getSubModuleData = "SELECT * FROM sub_module WHERE sub_mod_id=?";
  //   db.query(
  //     getSubModuleData,
  //     [sub_mod_id],
  //     (getSubModError, getSubModResult) => {
  //       if (getSubModError) {
  //         console.error("Error fetching Sub Module Data:", getSubModError);
  //         return res
  //           .status(500)
  //           .json({ error: "Error fetching Sub Module Data" });
  //       }

  //       const subModuleStartDate = new Date(getSubModResult[0].start_date);
  //       const subModuleEndDate = new Date(getSubModResult[0].end_date);
  //       const inputTaskStartDate = new Date(start_date);
  //       const inputTaskEndDate = new Date(end_date);

  //       console.log("Sub Module Start date", subModuleStartDate);
  //       console.log("Sub Module End date", subModuleEndDate);

  //       if (
  //         subModuleStartDate > inputTaskStartDate ||
  //         subModuleStartDate > inputTaskEndDate
  //       ) {
  //         return res
  //           .status(400)
  //           .json({ Message: "Task dates are before Sub Module start date" });
  //       } else if (
  //         subModuleEndDate < inputTaskStartDate ||
  //         subModuleEndDate < inputTaskEndDate
  //       ) {
  //         return res
  //           .status(400)
  //           .json({ message: "Task dates are after Sub Module end date" });
  //       }

  //       const currentDate = moment().format("YYYY-MM-DD HH:mm:ss");
  //       const insertTaskData = `
  //       INSERT INTO task(pro_id, pro_module_id, sub_mod_id, pro_name, module_name, sub_module_name, task_name, task_desc, start_date, end_date, created_at)
  //       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  //     `;

  //       db.query(
  //         insertTaskData,
  //         [
  //           pro_id,
  //           pro_module_id,
  //           sub_mod_id,
  //           pro_name,
  //           module_name,
  //           sub_module_name,
  //           task_name,
  //           task_desc,
  //           start_date,
  //           end_date,
  //           currentDate,
  //         ],
  //         (insertTaskError, insertTaskResult) => {
  //           if (insertTaskError) {
  //             console.error("Error adding Task data:", insertTaskError);
  //             return res.status(500).json({ error: "Error adding Task data" });
  //           }

  //           const task_id = insertTaskResult.insertId;
  //           const allocation_date = currentDate;

  //           // Iterate through selected employees and insert them into task_employee
  //           selectedEmployee.forEach((empId) => {
  //             const getEmpData = "SELECT * FROM employee WHERE emp_id = ?";
  //             db.query(getEmpData, [empId], (getEmpError, getEmpResult) => {
  //               if (getEmpError) {
  //                 console.error("Error fetching Employee data:", getEmpError);
  //                 return res
  //                   .status(500)
  //                   .json({ error: "Error fetching Employee data" });
  //               }

  //               const emp_name = getEmpResult[0].emp_name;
  //               const insertTaskEmployee = `
  //               INSERT INTO task_employee(pro_id,pro_module_id,sub_mod_id,task_id,emp_id,pro_name,module_name,sub_module_name,task_name,emp_name,allocation_date,created_at)
  //               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
  //             `;

  //               db.query(
  //                 insertTaskEmployee,
  //                 [
  //                   pro_id,
  //                   pro_module_id,
  //                   sub_mod_id,
  //                   task_id,
  //                   empId,
  //                   pro_name,
  //                   module_name,
  //                   sub_module_name,
  //                   task_name,
  //                   emp_name,
  //                   allocation_date,
  //                   currentDate,
  //                 ],
  //                 (insertTaskEmpError, insertTaskEmpResult) => {
  //                   if (insertTaskEmpError) {
  //                     console.error(
  //                       "Error adding Task Employee data:",
  //                       insertTaskEmpError
  //                     );
  //                     // Handle error for individual employee insertion
  //                   }
  //                 }
  //               );
  //             });
  //           });

  //           return res
  //             .status(200)
  //             .json({
  //               message: "Task and Task Employee data added successfully",
  //             });
  //         }
  //       );
  //     }
  //   );
  // });



// without date validation;

// router.post("/postTask", (req, res) => {
//   const {
//     pro_id,
//     pro_module_id,
//     sub_mod_id,
//     pro_name,
//     module_name,
//     sub_module_name,
//     task_name,
//     task_desc,
//     start_date,
//     end_date,
//     selectedEmployee,
//   } = req.body;

//   const getSubModuleData = "SELECT * FROM sub_module WHERE sub_mod_id=?";
//   db.query(
//     getSubModuleData,
//     [sub_mod_id],
//     (getSubModError, getSubModResult) => {
//       if (getSubModError) {
//         console.error("Error fetching Sub Module Data:", getSubModError);
//         return res
//           .status(500)
//           .json({ error: "Error fetching Sub Module Data" });
//       }

      
//      const start_date = moment(start_date).format("YYYY-MM-DD HH:mm:ss");
//      const end_date = moment(end_date).format("YYYY-MM-DD HH:mm:ss");
      

//       const currentDate = moment().format("YYYY-MM-DD HH:mm:ss");
//       const insertTaskData = `
//       INSERT INTO task(pro_id, pro_module_id, sub_mod_id, pro_name, module_name, sub_module_name, task_name, task_desc, start_date, end_date, created_at)
//       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
//     `;

//       db.query(
//         insertTaskData,
//         [
//           pro_id,
//           pro_module_id,
//           sub_mod_id,
//           pro_name,
//           module_name,
//           sub_module_name,
//           task_name,
//           task_desc,
//           start_date,
//           end_date,
//           currentDate,
//         ],
//         (insertTaskError, insertTaskResult) => {
//           if (insertTaskError) {
//             console.error("Error adding Task data:", insertTaskError);
//             return res.status(500).json({ error: "Error adding Task data" });
//           }

//           const task_id = insertTaskResult.insertId;
//           const allocation_date = currentDate;

//           // Iterate through selected employees and insert them into task_employee
//           selectedEmployee.forEach((empId) => {
//             const getEmpData = "SELECT * FROM employee WHERE emp_id = ?";
//             db.query(getEmpData, [empId], (getEmpError, getEmpResult) => {
//               if (getEmpError) {
//                 console.error("Error fetching Employee data:", getEmpError);
//                 return res
//                   .status(500)
//                   .json({ error: "Error fetching Employee data" });
//               }

//               const emp_name = getEmpResult[0].emp_name;
//               const insertTaskEmployee = `
//               INSERT INTO task_employee(pro_id,pro_module_id,sub_mod_id,task_id,emp_id,pro_name,module_name,sub_module_name,task_name,emp_name,allocation_date,created_at)
//               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
//             `;

//               db.query(
//                 insertTaskEmployee,
//                 [
//                   pro_id,
//                   pro_module_id,
//                   sub_mod_id,
//                   task_id,
//                   empId,
//                   pro_name,
//                   module_name,
//                   sub_module_name,
//                   task_name,
//                   emp_name,
//                   allocation_date,
//                   currentDate,
//                 ],
//                 (insertTaskEmpError, insertTaskEmpResult) => {
//                   if (insertTaskEmpError) {
//                     console.error(
//                       "Error adding Task Employee data:",
//                       insertTaskEmpError
//                     );
//                     // Handle error for individual employee insertion
//                   }
//                 }
//               );
//             });
//           });

//           return res
//             .status(200)
//             .json({
//               message: "Task and Task Employee data added successfully",
//             });
//         }
//       );
//     }
//   );
// });


router.post("/postTask", (req, res) => {
  const {
    pro_id,
    pro_module_id,
    sub_mod_id,
    pro_name,
    module_name,
    sub_module_name,
    task_name,
    task_desc,
    start_date,
    end_date,
    selectedEmployee,
  } = req.body;

  const formattedStartDate = moment(start_date).format("YYYY-MM-DD HH:mm:ss");
  const formattedEndDate = moment(end_date).format("YYYY-MM-DD HH:mm:ss");
  const currentDate = moment().format("YYYY-MM-DD HH:mm:ss");

  const insertTaskData = `
    INSERT INTO task(pro_id, pro_module_id, sub_mod_id, pro_name, module_name, sub_module_name, task_name, task_desc, start_date, end_date, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(
    insertTaskData,
    [
      pro_id,
      pro_module_id,
      sub_mod_id,
      pro_name,
      module_name,
      sub_module_name,
      task_name,
      task_desc,
      formattedStartDate,
      formattedEndDate,
      currentDate,
    ],
    (insertTaskError, insertTaskResult) => {
      if (insertTaskError) {
        console.error("Error adding Task data:", insertTaskError);
        return res.status(500).json({ error: "Error adding Task data" });
      }

      const task_id = insertTaskResult.insertId;
      const allocation_date = currentDate;

      // Iterate through selected employees and insert them into task_employee
      selectedEmployee.forEach((empId) => {
        const getEmpData = "SELECT * FROM employee WHERE emp_id = ?";
        db.query(getEmpData, [empId], (getEmpError, getEmpResult) => {
          if (getEmpError) {
            console.error("Error fetching Employee data:", getEmpError);
            return res.status(500).json({ error: "Error fetching Employee data" });
          }

          const emp_name = getEmpResult[0].emp_name;
          const insertTaskEmployee = `
            INSERT INTO task_employee(pro_id,pro_module_id,sub_mod_id,task_id,emp_id,pro_name,module_name,sub_module_name,task_name,emp_name,allocation_date,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
          `;

          db.query(
            insertTaskEmployee,
            [
              pro_id,
              pro_module_id,
              sub_mod_id,
              task_id,
              empId,
              pro_name,
              module_name,
              sub_module_name,
              task_name,
              emp_name,
              allocation_date,
              currentDate,
            ],
            (insertTaskEmpError, insertTaskEmpResult) => {
              if (insertTaskEmpError) {
                console.error("Error adding Task Employee data:", insertTaskEmpError);
                // Handle error for individual employee insertion
              }
            }
          );
        });
      });

      return res.status(200).json({
        message: "Task and Task Employee data added successfully",
      });
    }
  );
});



router.get('/getTaskData',(req,res) =>{
  const getTaskData = "select * from task inner join task_employee on task.task_id = task_employee.task_id";
  db.query(getTaskData,(getTaskErr,getTaskRes)=>{
    if(getTaskErr){
      console.error("Error :",getTaskErr);
      res.status(500).json({getTaskErr:"Error Task Data is not fetched."})
    }
     if (getTaskRes.length === 0) {
      return res.status(404).json({ Msg: "Task Not Found" });
    }

    // console.log("Resultss :", getTaskRes);
    return res.status(200).json(getTaskRes);
  });
});







  
// router.get("/getTaskData", (req, res) => {
//   const getTaskData = "select * from task";







  router.get("/getTaskEmp/:task_id", (req, res) => {
    const task_id = req.params.task_id;
    const getTaskEmp = "select * from task_employee where task_id=?";
    db.query(getTaskEmp, [task_id], (getEmpErr, getEmpResult) => {
      if (getEmpErr) {
        console.error("Error :", getEmpErr);
        res
          .status(500)
          .json({ getEmpErr: "Error Task Employee data is not fetching." });
      }
      // console.log("Result :", getEmpResult);
      res.status(200).json(getEmpResult);
    });
  });

  // Update Task and their employee




  router.put("/updateTask/:task_id", (req, res) => {
    const task_id = req.params.task_id;
    const {
      pro_id,
      pro_module_id,
      sub_mod_id,
      pro_name,
      module_name,
      sub_module_name,
      task_name,
      task_desc,
      start_date,
      end_date,
      emp_id,
      emp_name
    } = req.body;
  
    const updated_at = new Date().toISOString().slice(0, 19).replace('T', ' ');
  
    const updateTaskQuery = `
      UPDATE task 
      SET 
        task_name=?, 
        task_desc=?, 
        start_date=?, 
        end_date=?, 
        updated_at=?
      WHERE task_id=?
    `;
    
    db.query(updateTaskQuery, [
      task_name,
      task_desc,
      start_date,
      end_date,
      updated_at,
      task_id
    ], (updateErr, updateResult) => {
      if (updateErr) {
        console.error("Error updating Task data:", updateErr);
        return res.status(500).json({ error: "Error updating Task data" });
      }
  
      const selectExistingEmployeesQuery = `SELECT emp_id FROM task_employee WHERE task_id=?`;
      db.query(selectExistingEmployeesQuery, [task_id], (selectEmpErr, existingEmpResult) => {
        if (selectEmpErr) {
          console.error("Error retrieving existing employees:", selectEmpErr);
          return res.status(500).json({ error: "Error retrieving existing employees" });
        }
  
        const previousEmployeeIDs = existingEmpResult.map(row => row.emp_id);
        const removedEmployees = previousEmployeeIDs.filter(id => !emp_id.includes(id));
  
        removedEmployees.forEach(empID => {
          const deleteQuery = 'DELETE FROM task_employee WHERE task_id = ? AND emp_id = ?';
          db.query(deleteQuery, [task_id, empID], (deleteErr, deleteResult) => {
            if (deleteErr) {
              console.error('Error deleting task_employee record:', deleteErr);
             
            }
            
          });
        });
  
        for (let i = 0; i < emp_id.length; i++) {
          const selectQuery = `SELECT COUNT(*) AS count FROM task_employee WHERE task_id=? AND emp_id=?`;
          db.query(selectQuery, [task_id, emp_id[i]], (selectErr, selectResult) => {
            if (selectErr) {
              console.error("Error checking if data exists:", selectErr);
              return res.status(500).json({ error: "Error checking data existence" });
            }
  
            const count = selectResult[0].count;
  
            if (count === 0) {
              const insertTaskEmp = `
                INSERT INTO task_employee 
                (pro_id, pro_module_id, sub_mod_id, task_id, emp_id, pro_name, module_name, sub_module_name, task_name, emp_name,allocation_date, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)
              `;
              db.query(insertTaskEmp, [
                pro_id,
                pro_module_id,
                sub_mod_id,
                task_id,
                emp_id[i],
                pro_name,
                module_name,
                sub_module_name,
                task_name,
                emp_name[i],
                updated_at,
                updated_at
              ], (taskEmpInsertErr, taskEmpInsertResult) => {
                if (taskEmpInsertErr) {
                  console.error("Error inserting Task Employee data:", taskEmpInsertErr);
                  return res.status(500).json({ error: "Error inserting Task Employee data" });
                }
              });
            } else {
              const updateTaskEmp = `
                UPDATE task_employee 
                SET 
                  pro_id=?, 
                  pro_module_id=?, 
                  sub_mod_id=?, 
                  pro_name=?, 
                  module_name=?, 
                  sub_module_name=?, 
                  task_name=?, 
                  emp_name=?, 
                  updated_at=?
                WHERE task_id=? AND emp_id=?
              `;
              db.query(updateTaskEmp, [
                pro_id,
                pro_module_id,
                sub_mod_id,
                pro_name,
                module_name,
                sub_module_name,
                task_name,
                emp_name[i],
                updated_at,
                task_id,
                emp_id[i]
              ], (taskEmpUpdateErr, taskEmpUpdateResult) => {
                if (taskEmpUpdateErr) {
                  console.error("Error updating Task Employee data:", taskEmpUpdateErr);
                  return res.status(500).json({ error: "Error updating Task Employee data" });
                }
              });
            }
          });
        }
  
        res.status(200).json({ message: "Task and Task Employee data updated successfully" });
      });
    });
  });
  





  router.delete('/deleteTaskData/:task_id',(req,res) =>{
    const task_id = req.params.task_id;

    const deleteData = "delete from task where task_id=?";
    db.query(deleteData,[task_id],(taskDelErr,taskDelRes) =>{
      if(taskDelErr){
        console.error("Error :",taskDelErr);
        res.status(500).json({taskDelErr:"Error Task Data is Not Deleted"})
      }
      // console.log("Result :",taskDelRes);
      res.status(200).json({taskDelRes:"Task Data is Deleted Successfully"})
    })
  })



    
  

  // Fetch Task Data

  router.get("/getEmpTaskData", (req, res) => {
    const getTaskdata =
      "select * from task inner join task_employee on task.task_id = task_employee.task_id;";
    db.query(getTaskdata, (getTaskerr, getTaskResult) => {
      if (getTaskerr) {
        console.error("Error :", getTaskerr);
        res
          .status(500)
          .json({ getTaskerr: "Error The Task Data is not fetching" });
      } else if (getTaskResult.length == 0) {
        res.status(404).json({ Message: "Task Data Not Found" });
      } else res.json(getTaskResult);
    });
  });

  return router;
};
