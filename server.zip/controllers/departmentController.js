const express = require('express');
const router = express.Router();
const multer = require('multer');

module.exports = (db) => {
  // Set up multer storage
  const storage = multer.memoryStorage(); // Store the file in memory
  const upload = multer({ storage: storage });

  router.get('/', (req, res) => {
    const getDepartment = 'SELECT * FROM department';
    db.query(getDepartment, (deptError, deptResult) => {
      if (deptError) {
        res.status(500).json({ deptError: "Fetching Department Error" });
      }
      res.json(deptResult);
    });
  });

  router.post('/uploadImages', upload.single('imageData'), (req, res) => {
    const imageData = req.file.buffer; // Use req.file.buffer for in-memory storage
    console.log("Image", imageData);

    db.query('INSERT INTO image (images) VALUES (?)', [imageData], (err, result) => {
      if (err) {
        console.error('Error inserting image:', err);
        res.status(500).send('Error inserting image');
      } else {
        console.log('Image inserted successfully');
        res.status(200).send('Image inserted successfully');
      }
    });
  });

  
  router.get('/getAllImages', (req, res) => {
    const query = 'SELECT images FROM image';
    db.query(query, (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).send('Error retrieving images');
      }
  
      const imageDataArray = results.map((result) => ({
        imageData: result.images.toString('base64'), // Convert Buffer to base64 string
      }));
  
      res.status(200).json(imageDataArray);
    });
  });
  
  

  return router;
};
