const express = require('express')
const router = express.Router()
const moment = require('moment')

module.exports = (db) =>{




  router.get('/getCustMainDataAdmin',(req,res) =>{
    const getCustMainData = 'select  customer_maintenance.*,customers.dist,customers.city from customer_maintenance join customers on customer_maintenance.cust_id = customers.cust_id';
    db.query(getCustMainData,(getErr,getRes) =>{
      if(getErr){
        res.status(500).json({getErr:"Customer Maintenance Data is not fetched"});
      }
      const categoryLookup={
        1:"1st Priority",
        2:"2nd Priority",
        3:"3rd Priority",
        4:"4th Priority",
      }
      const convertedData = getRes.map((custMain) =>({
        ...custMain,
        category:categoryLookup[custMain.category] || null,
        cur_follow_up_date:moment(custMain.cur_follow_up_date).format("YYYY-MM-DD"),
        cus_avail_date:moment(custMain.cus_avail_date).format("YYYY-MM-DD")
      }))
      res.status(200).json(convertedData)
    })
  })


  router.post('/postCustMainData', (req, res) => {
    const {
      cust_id,
      follow_emp_id,
      follow_emp_name,
      cust_name,
      cust_email,
      bus_name,
      bus_category,
      category,
      notes,
      cust_available,
      cur_date,
      cust_avail_date,
    } = req.body;
  
    const currentDate = moment().format('YYYY-MM-DD HH:mm:ss');
    let postCustData = '';
  
    if (cust_available === 'yes') {
      postCustData = "INSERT INTO customer_maintenance(cust_id, emp_id, emp_name, cust_name, cust_email, bus_name, bus_category, category, notes, cur_follow_up_date, cust_available, cus_avail_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    } else {
      postCustData = "INSERT INTO customer_maintenance(cust_id, emp_id, emp_name, cust_name, cust_email, bus_name, bus_category, category, notes, cur_follow_up_date, cust_available, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    }
  
    const queryParams = [
      cust_id,
      follow_emp_id,
      follow_emp_name,
      cust_name,
      cust_email,
      bus_name,
      bus_category,
      category,
      notes,
      cur_date,
    ];
  
    if (cust_available === 'yes') {
      queryParams.push(cust_available, cust_avail_date, currentDate);
    } else {
      queryParams.push(cust_available, currentDate);
    }
  
    db.query(postCustData, queryParams, (custPostErr, custPostRes) => {
      if (custPostErr) {
        console.error("Error :", custPostErr);
        res.status(500).json({ custPostErr: "Error Customer Maintenance Data is not stored" });
      }
      res.status(200).json({ custPostRes: "Customer Maintenance Data stored Successfully" });
    });
  });
  


    router.get('/getCustomerByEmpID' , (req,res) =>{
        const emp_id = req.query.emp_id;
        const getCustData = "select  customer_maintenance.*,customers.* from customer_maintenance join customers on customer_maintenance.cust_id = customers.cust_id where emp_id = ?";
        db.query(getCustData,[emp_id],(getCustErr,getCustRes) =>{
          if(getCustErr){
            console.error("Error :",getCustErr);
            res.status(500).json({getCustErr:"Error Customer data is not fetching using Employee Id"})
          }

          const categoryLookup = {
            1: "1st Priority",
            2: "2nd Priority",
            3: "3rd Priority",
            4: "4th Priority"
            // Add more categories if needed
          };

          const custData = getCustRes.map((customer) =>({
            ...customer,
            cur_follow_up_date : moment(customer.cur_follow_up_date).format("YYYY-MM-DD"),
            cus_avail_date : moment(customer.cus_avail_date).format("YYYY-MM-DD"),
            category: categoryLookup[customer.category] || null // Lookup the category value in the object
          }))
          
          res.json(custData)
        })
      })


      router.put('/:cust_main_id', (req, res) => {
        const cust_main_id = req.params.cust_main_id;
        const {
          cust_id,
          emp_id,
          emp_name,
          cust_name,
          cust_email,
          bus_name,
          bus_category,
          notes,
          cust_available,
          cur_follow_up_date,
          cus_avail_date
        } = req.body;
      
        const currentDate = moment().format('YYYY-MM-DD HH:mm:ss');
        let updateCustMainData = '';
        let queryParams = [
          cust_id,
          emp_id,
          emp_name,
          cust_name,
          cust_email,
          bus_name,
          bus_category,
          notes,
          cur_follow_up_date,
        ];
      
        if (cust_available === 'yes') {
          updateCustMainData = 'UPDATE customer_maintenance SET cust_id=?, emp_id=?, emp_name=?, cust_name=?, cust_email=?, bus_name=?, bus_category=?, notes=?, cur_follow_up_date=?, cust_available=?, cus_avail_date=?, updated_at=? WHERE cust_main_id=?';
      
          queryParams.push(cust_available, cus_avail_date, currentDate, cust_main_id);
        } else {
          updateCustMainData = 'UPDATE customer_maintenance SET cust_id=?, emp_id=?, emp_name=?, cust_name=?, cust_email=?, bus_name=?, bus_category=?, notes=?, cur_follow_up_date=?, cust_available=?, cus_avail_date=NULL, updated_at=? WHERE cust_main_id=?';
      
          queryParams.push(cust_available, currentDate, cust_main_id);
        }
      
        db.query(updateCustMainData, queryParams, (updateErr, updateRes) => {
          if (updateErr) {
            console.error("Error :", updateErr);
            res.status(500).json({ updateErr: "Error Customer Maintenance Data is not Updated" });
          }
          res.status(200).json({ updateRes: "Update Customer Maintenance Data Successfully" });
        });
      });
      

      router.delete('/:cust_main_id/delete',(req,res)=>{
        const cust_main_id = req.params.cust_main_id;
        const deleteCustMainData = "delete from customer_maintenance where cust_main_id=?";
        db.query(deleteCustMainData,[cust_main_id],(dltErr,dltRes)=>{
          if(dltErr){
            console.error("Error :",dltErr);
            res.status(500).json({dltErr:"Error Customer Maintence Data is Not Deleted"})
          }
          res.status(200).json({dltRes:"Customer Maintence Data is Deleted Successfully."})
        })
      })



      // Report Data

      router.get('/filter', (req, res) => {
        const { category, fromDate, toDate, dist, city,emp_id } = req.query;
    
        let query = 'SELECT customer_maintenance.*, customers.* FROM customer_maintenance JOIN customers ON customer_maintenance.cust_id = customers.cust_id WHERE 1=1';
    
        if (category) {
            query += ` AND category = ${db.escape(category)}`; // Sanitize input using db.escape()
        }
        if (fromDate && toDate) {
            query += ` AND cur_follow_up_date BETWEEN ${db.escape(fromDate)} AND ${db.escape(toDate)}`; // Sanitize input
        }
        if (dist) {
            query += ` AND dist = ${db.escape(dist)}`; // Sanitize input using db.escape()
        }
        if (city) {
            query += ` AND city = ${db.escape(city)}`; // Sanitize input using db.escape()
        }
        if (emp_id) {
            query += ` AND emp_id = ${db.escape(emp_id)}`; // Sanitize input using db.escape()
        }
    
        db.query(query, (filterErr, filterRes) => {
            if (filterErr) {
                console.error("Error:", filterErr);
                return res.status(500).json({ filterErr: "Error fetching filtered data." });
            }
    
            const categoryLookup = {
                1: "1st Priority",
                2: "2nd Priority",
                3: "3rd Priority",
                4: "4th Priority"
            };
    
            const custMainData = filterRes.map((cust) => ({
                ...cust,
                category: categoryLookup[cust.category] || null,
                cur_follow_up_date: moment(cust.cur_follow_up_date).format('YYYY-MM-DD'),
                cus_avail_date: moment(cust.cus_avail_date).format('YYYY-MM-DD'),
                created_at: moment(cust.created_at).format('YYYY-MM-DD HH:mm:ss'),
                updated_at: moment(cust.updated_at).format('YYYY-MM-DD HH:mm:ss'),
            }));
    
            res.status(200).json(custMainData);
            console.log("Dattta:", custMainData);
        });
    });
    


      router.get('/adminFilter', (req, res) => {
        const { category, fromDate, toDate, cust_email, emp_id ,dist, city } = req.query;
      
        let query = 'SELECT customer_maintenance.*, customers.* FROM customer_maintenance JOIN customers ON customer_maintenance.cust_id = customers.cust_id WHERE 1=1';
      
        if (category) {
          query = query + ` AND category = ${category}`;
        }
      
        if (fromDate && toDate) {
          query = query + ` AND cur_follow_up_date >= '${fromDate}' AND cur_follow_up_date <= '${toDate}'`;
        }
      
        if (cust_email) {
          query = query + ` AND cust_email = '${cust_email}'`;
        }
      
        if (emp_id) {
          query = query + ` AND emp_id = ${emp_id}`;
        }

        if (dist) {
          query += ` AND dist = ${db.escape(dist)}`; // Sanitize input using db.escape()
      }
      if (city) {
          query += ` AND city = ${db.escape(city)}`; // Sanitize input using db.escape()
      }

        
      
        db.query(query, (getErr, getRes) => {
          if (getErr) {
            res.status(500).json({ getErr: 'Filtered Data is Not Fetched' });
          } else {
            const categoryLookup = {
              1: "1st Priority",
              2: "2nd Priority",
              3: "3rd Priority",
              4: "4th Priority"
            };
      
            const convertedData = getRes.map((filter) => ({
              ...filter,
              cur_follow_up_date: moment(filter.cur_follow_up_date).format('YYYY-MM-DD'),
              cus_avail_date: moment(filter.cus_avail_date).format('YYYY-MM-DD'),
              category: categoryLookup[filter.category] || null
            }));
      
            res.status(200).json(convertedData);
          }
        });
      });
      



      // Reminder
      router.get('/reminder',(req,res) =>{
        const emp_id = req.query.emp_id;
        const getData =
        `
        SELECT 
    cust_main.*,
    CASE
        WHEN category = 1 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 15 DAY)
        WHEN category = 2 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 30 DAY)
        WHEN category = 3 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 45 DAY)
        WHEN category = 4 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 60 DAY)
        ELSE DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 60 DAY) -- Reminder after 60 days if category is null
    END AS reminder_date
FROM 
    customer_maintenance cust_main
JOIN (
    SELECT 
        cust_id,
        MAX(
            CASE
                WHEN category = 1 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 15 DAY)
                WHEN category = 2 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 30 DAY)
                WHEN category = 3 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 45 DAY)
                WHEN category = 4 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 60 DAY)
            END
        ) AS max_followup
    FROM 
        customer_maintenance
    GROUP BY 
        cust_id
) latest ON cust_main.cust_id = latest.cust_id 
WHERE 
    cust_main.emp_id = ?
AND (
    IFNULL(cust_main.cus_avail_date, cust_main.cur_follow_up_date) = latest.max_followup
    OR (
        cust_main.category = 1
        AND DATE_ADD(IFNULL(cust_main.cus_avail_date, cust_main.cur_follow_up_date), INTERVAL 15 DAY) = latest.max_followup
    )
    OR (
        cust_main.category = 2
        AND DATE_ADD(IFNULL(cust_main.cus_avail_date, cust_main.cur_follow_up_date), INTERVAL 30 DAY) = latest.max_followup
    )
    OR (
        cust_main.category = 3
        AND DATE_ADD(IFNULL(cust_main.cus_avail_date, cust_main.cur_follow_up_date), INTERVAL 45 DAY) = latest.max_followup
    )
    OR (
        cust_main.category = 4
        AND DATE_ADD(IFNULL(cust_main.cus_avail_date, cust_main.cur_follow_up_date), INTERVAL 60 DAY) = latest.max_followup
    )
)
        `;
        db.query(getData,[emp_id],(getDataErr,getDataRes) =>{
          if(getDataErr){
            console.error("Error:",getDataErr);
            res.status(500).json({getDataErr:"Reminder Data is Not Fetched"})
          }
          const convertData = getDataRes.map((cust) =>({
            ...cust,
            cur_follow_up_date:moment(cust.cur_follow_up_date).format('YYYY-MM-DD'),
            cus_avail_date:moment(cust.cus_avail_date).format('YYYY-MM-DD'),
            created_at:moment(cust.created_at).format('YYYY-MM-DD'),
            createupdated_atd_at:moment(cust.updated_at).format('YYYY-MM-DD'),
            reminder_date : moment(cust.reminder_date).format('YYYY-MM-DD')
          }))

          res.status(200).json(convertData)
        })
      })


      router.get('/allEmpReminderDates',(req,res)=>{
        const getReminderQuery = `
        SELECT 
    cust_main.*,employee.*,
    CASE
        WHEN category = 1 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 15 DAY)
        WHEN category = 2 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 30 DAY)
        WHEN category = 3 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 45 DAY)
        WHEN category = 4 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 60 DAY)
        ELSE NULL
    END AS reminder_date
FROM 
    customer_maintenance cust_main
    JOIN employee ON cust_main.emp_id = employee.emp_id
JOIN (
    SELECT 
        cust_id,
        MAX(
            CASE
                WHEN category = 1 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 15 DAY)
                WHEN category = 2 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 30 DAY)
                WHEN category = 3 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 45 DAY)
                WHEN category = 4 THEN DATE_ADD(IFNULL(cus_avail_date, cur_follow_up_date), INTERVAL 60 DAY)
            END
        ) AS max_followup
    FROM 
        customer_maintenance
    GROUP BY 
        cust_id
) latest ON cust_main.cust_id = latest.cust_id 
AND (
    IFNULL(cust_main.cus_avail_date, cust_main.cur_follow_up_date) = latest.max_followup
    OR (
        cust_main.category = 1
        AND DATE_ADD(IFNULL(cust_main.cus_avail_date, cust_main.cur_follow_up_date), INTERVAL 15 DAY) = latest.max_followup
    )
    OR (
        cust_main.category = 2
        AND DATE_ADD(IFNULL(cust_main.cus_avail_date, cust_main.cur_follow_up_date), INTERVAL 30 DAY) = latest.max_followup
    )
    OR (
        cust_main.category = 3
        AND DATE_ADD(IFNULL(cust_main.cus_avail_date, cust_main.cur_follow_up_date), INTERVAL 45 DAY) = latest.max_followup
    )
    OR (
        cust_main.category = 4
        AND DATE_ADD(IFNULL(cust_main.cus_avail_date, cust_main.cur_follow_up_date), INTERVAL 60 DAY) = latest.max_followup
    )
)`;
db.query(getReminderQuery,(err,result)=>{
  if(err){
    res.status(500).json({message:"Internal server error.Reminder dates are could not be fetched"})
  }else{
    if(result.length === 0){
      res.status(404).json({message:"Reminder Data not found"})
    }else{
     const convertDate = result.map((reminder)=>({
      ...reminder,
      emp_img : reminder.emp_img.toString('base64'),
      cur_follow_up_date : moment(reminder.cur_follow_up_date).format('YYYY-MM-DD'),
      cus_avail_date : moment(reminder.cus_avail_date).format('YYYY-MM-DD'),
      reminder_date : moment(reminder.reminder_date).format('YYYY-MM-DD'),

     }))
     res.status(200).json(convertDate)
    }
  }
})
      })


      

      router.get('/getEmployeeByCustMainEmpId',(req,res)=>{
        const getEmployee = `select employee.* from employee join customer_maintenance on employee.emp_id = customer_maintenance.emp_id group by employee.emp_id`;
        db.query(getEmployee,(err,result)=>{
          if(err){
            res.status(500).json({message:"Internal server error.Data could not be fetched."})
          }else{
            res.status(200).json(result)
          }
        })
      })



     
      
      

    return router
}