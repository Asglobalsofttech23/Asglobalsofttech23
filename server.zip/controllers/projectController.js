const express = require("express");
const router = express.Router();
const moment = require("moment");

module.exports = (db) => {

  
  // router.post('/', (req, res) => {
  //     const { cust_email, pro_name, pro_desc ,start_date,end_date} = req.body;

  //     getCustomer = 'select cust_id, cust_name, cust_mobile, bus_category from customers where cust_email=?'
  //     db.query(getCustomer, [cust_email], (custError, custResult) => {
  //         if (custError) {
  //             console.error("Error:", customerError);
  //             return res.status(500).json({ error: "Error Customer data Added" });
  //         }
  //         if (custResult.length === 0) {
  //             return res.status(404).json({ error: "Customer not found" });
  //         }
  //         const { cust_id, cust_name, cust_mobile, bus_category } = custResult[0];
  //         const currentTime = moment().format('YYYY-MM-DD HH:mm:ss');
  //         const insertProject = 'insert into projects(cust_id, cust_name, cust_mobile, cust_email, bus_category, pro_name, pro_desc,start_date,end_date, created_at) values(?, ?, ?, ?, ?, ?, ?, ?,?,?)';
  //         db.query(insertProject, [
  //             cust_id,
  //             cust_name,
  //             cust_mobile,
  //             cust_email,
  //             bus_category,
  //             pro_name,
  //             pro_desc,
  //             start_date,
  //             end_date,
  //             currentTime
  //         ], (proError, proResult) => {
  //             if (proError) {
  //                 console.error("Error:", projectError);
  //                 return res.status(500).json({ error: "Error Project added" });
  //             }
  //             console.log("Result", proResult);
  //             res.status(200).json({ result: "Successfully Added Project" });
  //         })
  //     })
  // })

  router.post("/", (req, res) => {
    const {
      cust_email,
      pro_name,
      pro_desc,
      start_date,
      end_date,
      allocation_date,
      selectedEmployees,
      totalWorkingHours,
      totalWorkingDays,
      hoursPerDay
    } = req.body;

    // Fetch customer information
    const getCustomer =
      "SELECT cust_id, cust_name, cust_mobile, bus_category FROM customers WHERE cust_email=?";
    db.query(getCustomer, [cust_email], (custError, custResult) => {
      if (custError) {
        console.error("Error:", custError);
        return res.status(500).json({ error: "Error fetching customer data" });
      }
      if (custResult.length === 0) {
        return res.status(404).json({ error: "Customer not found" });
      }

      const { cust_id, cust_name, cust_mobile, bus_category } = custResult[0];
      const currentTime = moment().format("YYYY-MM-DD HH:mm:ss");

      // Insert project details into 'projects' table
      const insertProject =
        "INSERT INTO projects (cust_id, cust_name, cust_mobile, cust_email, bus_category, pro_name, pro_desc, start_date, end_date,totalworkingdays,totalworkinghours,workinghoursperday, created_at) VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      db.query(
        insertProject,
        [
          cust_id,
          cust_name,
          cust_mobile,
          cust_email,
          bus_category,
          pro_name,
          pro_desc,
          start_date,
          end_date,
          totalWorkingDays,
          totalWorkingHours,
          hoursPerDay,
          
          currentTime,
        ],
        (proError, proResult) => {
          if (proError) {
            console.error("Error:", proError);
            return res.status(500).json({ error: "Error adding project data" });
          }

          // Insert selected employees into 'project_employee' table with their names
          const projectId = proResult.insertId;
          const insertEmployees =
            "INSERT INTO project_employee (pro_id, emp_id, pro_name, emp_name, allocation_date, created_at) VALUES ?";

          // Prepare data for bulk insertion
          const employeesData = selectedEmployees.map((empId) => [
            projectId,
            empId,
            pro_name,
            "",
            allocation_date,
            currentTime,
          ]);

          // Fetch employee names based on emp_ids
          const empIds = selectedEmployees.join(",");
          const getEmployeeNames = `SELECT emp_id, emp_name FROM employee WHERE emp_id IN (${empIds})`;

          db.query(getEmployeeNames, (empNameError, empNameResult) => {
            if (empNameError) {
              console.error("Error:", empNameError);
              return res
                .status(500)
                .json({ error: "Error fetching employee names" });
            }

            // Map retrieved employee names to the employeesData array
            empNameResult.forEach((emp) => {
              const index = employeesData.findIndex(
                (data) => data[1] === emp.emp_id
              );
              if (index !== -1) {
                employeesData[index][3] = emp.emp_name;
              }
            });

            // Insert data into 'project_employee' table
            db.query(
              insertEmployees,
              [employeesData],
              (empInsertError, empInsertResult) => {
                if (empInsertError) {
                  console.error("Error:", empInsertError);
                  return res
                    .status(500)
                    .json({ error: "Error adding employee data" });
                }

                // console.log("Result", proResult);
                res.status(200).json({
                  result: "Successfully added project and employee data",
                });
              }
            );
          });
        }
      );
    });
  });

  // It is can't display customer  duplicate data

  router.get("/selectCustomer", (req, res) => {
    const getCustomer = `SELECT *
    FROM (
        SELECT 
            *,
            ROW_NUMBER() OVER (PARTITION BY cust_id ORDER BY pro_id) as rn
        FROM projects
    ) AS numbered
    WHERE rn = 1;
    `;
    // const getCustomer = "select * from projects group by cust_id";
    db.query(getCustomer, (getCustError, getCustResult) => {
      if (getCustError) {
        console.error("Error :", getCustError);
        res.status(500).json({ getCustError: "Error Fetching Customer" });
      }
      // console.log("Result :", getCustResult);
      res.json(getCustResult);
    });
  });

  // Customer ID to get project name

  router.get("/cust_id", (req, res) => {
    const cust_id = req.query.cust_id;
    const getCustomerProject = "select * from projects where cust_id =?";
    db.query(getCustomerProject, [cust_id], (custError, custResult) => {
      if (custError) {
        console.error("Error :", custError);
        res.status(500).json({ custError: "Error Fetching customer Project " });
      }
      // console.log("Result :", custResult);
      res.status(200).json(custResult);
    });
  });

  // Get Project Employeee

  router.get("/projectEmployee", (req, res) => {
    const pro_id = req.query.pro_id;
    const getEmployee = "select * from project_employee where pro_id = ?";
    db.query(getEmployee, [pro_id], (proEmpError, proEmpResult) => {
      if (proEmpError) {
        console.error("Error :", proEmpError);
        res
          .status(500)
          .json({ proEmpError: "Error Fetching Project Employee" });
      }
      // console.log("Result :", proEmpResult);
      res.status(200).json(proEmpResult);
    });
  });


  
  router.get("/", (req, res) => {
    const getProject = "SELECT * FROM projects";
    db.query(getProject, (proError, proResult) => {
      if (proError) {
        console.error("Error :", proError);
        return res.status(500).json({ error: "Error Project Fetching" });
      }
  
      if (proResult.length === 0) {
        return res.status(404).json({ error: "Project not found" });
      }
  
      // Format the date fields before sending the response
      const formattedProjects = proResult.map((project) => ({
        ...project,
        start_date: moment(project.start_date).format("YYYY-MM-DD"),
        end_date: moment(project.end_date).format("YYYY-MM-DD"),
        
      }));
  
      // console.log("Result :", formattedProjects);
      res.json(formattedProjects);
    });
  });
  


  router.get("/dashboardproject", (req, res) => {
    const getProject = "select * from projects";
    db.query(getProject, (proError, proResult) => {
      if (proError) {
        console.error("Error :", proError);
        res.status(500).json({ error: "Error Project Fetching" });
      }
     
      // console.log("Result :", proResult);
      res.json(proResult);
    });
  });

  // router.put('/:edit', (req, res) => {
  //     pro_id = req.params.pro_id;
  //     const { cust_email, pro_name, pro_desc } = req.body;
  //     getCustomer = 'select cust_id, cust_name, cust_mobile, bus_category from customers where cust_email=?';
  //     db.query(getCustomer, [cust_email], (editError, editResult) => {
  //         if (editError) {
  //             console.error('Error :', editError);
  //             res.status(500).json({ editError: "Error Project Editing" })
  //         }
  //         const { cust_id, cust_name, cust_mobile, bus_category } = editResult[0];
  //         const currentTime = moment().format('YYYY-MM-DD HH:mm:ss');
  //         const updateProject = 'update projects set cust_name=?,cust_mobile=?,cust_email=?,bus_category=?,pro_name=?,pro_desc=?,updated_at=? where pro_id=?';
  //         db.query(updateProject, [
  //             cust_id,
  //             cust_name,
  //             cust_mobile,
  //             cust_email,
  //             bus_category,
  //             pro_name,
  //             pro_desc,
  //             currentTime
  //         ], (proEditError, proEditResult) => {
  //             if (proEditError) {
  //                 console.error('Error :', proEditError);
  //                 res.status(500).json({ proEditError: " Project is Not Editing" })
  //             }
  //             else {
  //                 console.log('Updated Project:', proEditResult);
  //                 res.json(proEditResult);
  //             }
  //         })
  //     })

  // })

  router.put("/:pro_id", (req, res) => {
    const pro_id = req.params.pro_id;
    const { cust_email, pro_name, pro_desc,start_date,end_date } = req.body;

    const getCustomerQuery =
      "SELECT cust_id, cust_name, cust_mobile, bus_category FROM customers WHERE cust_email=?";
    db.query(
      getCustomerQuery,
      [cust_email],
      (getCustomerError, getCustomerResult) => {
        if (getCustomerError) {
          console.error("Error fetching customer:", getCustomerError);
          return res
            .status(500)
            .json({ getCustomerError: "Error fetching customer data" });
        }

        if (getCustomerResult.length === 0) {
          return res.status(404).json({ message: "Customer not found" });
        }

        const { cust_id, cust_name, cust_mobile, bus_category } =
          getCustomerResult[0];
        const currentTime = moment().format("YYYY-MM-DD HH:mm:ss");

        const updateProjectQuery = `
        UPDATE projects
        SET cust_id=?, cust_name=?, cust_mobile=?, cust_email=?, bus_category=?, pro_name=?, pro_desc=?,start_date=?,end_date=?, updated_at=?
        WHERE pro_id=?
      `;

        db.query(
          updateProjectQuery,
          [
            cust_id,
            cust_name,
            cust_mobile,
            cust_email,
            bus_category,
            pro_name,
            pro_desc,
            start_date,
            end_date,
            currentTime,
            pro_id,
          ],
          (updateProjectError, updateProjectResult) => {
            if (updateProjectError) {
              console.error("Error updating project:", updateProjectError);
              return res
                .status(500)
                .json({ updateProjectError: "Error updating project data" });
            }

            // console.log("Updated Project:", updateProjectResult);
            return res
              .status(200)
              .json({ message: "Project updated successfully" });
          }
        );
      }
    );
  });

  router.delete("/:pro_id/delete", (req, res) => {
    proId = req.params.pro_id;
    const deleteproject = "DELETE FROM projects WHERE pro_id = ?";
    // console.log("Delete Query:", deleteproject);
    db.query(deleteproject, [proId], (proDeleteError, proDeleteResult) => {
      if (proDeleteError) {
        console.error("Error :", proDeleteError);
        res.status(500).json({ proDeleteError: "Error deleting data" });
      }
      // console.log("Reuslt :", proDeleteResult);
      res.status(200).json({ message: "project deleted successfully" });
    });
  });

  // Store Project Module and employee data

  // router.post("/projectModule", (req, res) => {
  //   const {
  //     cust_id,
  //     pro_id,
  //     pro_name,
  //     module_name,
  //     module_desc,
  //     start_date,
  //     end_date,
  //     selectedEmployees,
  //   } = req.body;
  //   const getProjectDate = "select * from projects where pro_id=? ";
  //   db.query(getProjectDate, [pro_id], (getProErro, getProResult) => {
  //     if (getProErro) {
  //       console.log("Error :", getProErro);
  //       res.status(500).json({ getProErro: "Error Fetching project data" });
  //     }
  //     if (getProResult.length === 0) {
  //       res.status(404).json({ message: "Customer Not Found" });
  //     }

  //     const currentDate = moment().format("YYYY-MM-DD HH:mm:ss");
  //     const projectStartDate = new Date(getProResult[0].start_date);
  //     const projectEndDate = new Date(getProResult[0].end_date);
  //     const inputModuleStartDate = new Date(start_date);
  //     const inputModuleEndDate = new Date(end_date);

  //     if (projectStartDate > inputModuleStartDate) {
  //       return res.status(400).json({
  //         Message:
  //           " Sorry Module Start date  is before Project start date so not accept",
  //       });
  //     } else if (projectStartDate > inputModuleEndDate) {
  //       return res.status(400).json({
  //         Message:
  //           " Sorry Module End date  is before Project start date so not accept",
  //       });
  //     } else if (projectEndDate < inputModuleStartDate) {
  //       return res
  //         .status(400)
  //         .json({ message: "Dates are not within project duration" });
  //     } else if (projectEndDate < inputModuleEndDate) {
  //       return res
  //         .status(400)
  //         .json({ message: "Dates are not within project duration" });
  //     }

  //     const insertprojectModule =
  //       "insert into project_modules (pro_id,pro_name,module_name,module_desc,start_date,end_date,created_at) values(?,?,?,?,?,?,?)";
  //     db.query(
  //       insertprojectModule,
  //       [
  //         pro_id,
  //         pro_name,
  //         module_name,
  //         module_desc,
  //         start_date,
  //         end_date,
  //         currentDate,
  //       ],
  //       (insertModuleError, insertModuleResult) => {
  //         if (insertModuleError) {
  //           console.log("Error :", insertModuleError);
  //           res
  //             .status(500)
  //             .json({ insertModuleError: "Error module data is not added" });
  //         }

  //         const pro_module_id = insertModuleResult.insertId;
  //         selectedEmployees.forEach((empId) => {
  //           const getEmployee = "select * from project_employee where emp_id=?";
  //           db.query(getEmployee, [empId], (empError, empResult) => {
  //             if (empError) {
  //               console.error("Error:", empError);
  //               res
  //                 .status(500)
  //                 .json({ empError: "Error fetching employee data" });
  //             } else {
  //               const emp_name = empResult[0].emp_name;
  //               const insertModuleEmployee =
  //                 "INSERT INTO module_employee (pro_id,pro_module_id, emp_id,pro_name, module_name, emp_name, allocation_date, created_at) VALUES (?, ?, ?, ?, ?, ?)";
  //               const allocationDate = currentDate;
  //               db.query(
  //                 insertModuleEmployee,
  //                 [
  //                   pro_id,
  //                   pro_module_id,
  //                   empId,
  //                   pro_name,
  //                   module_name,
  //                   emp_name,
  //                   allocationDate,
  //                   currentDate,
  //                 ],
  //                 (insertmoduleEmpError, insertModuleEmpResult) => {
  //                   if (insertmoduleEmpError) {
  //                     console.error("Error :", insertmoduleEmpError);
  //                     res.status(500).json({
  //                       insertmoduleEmpError: "Error Not added employee data",
  //                     });
  //                   } 
                      
                     
                 
  //                 }
  //               );
  //             }
  //           });
  //         });
  //         res.status(200).json({insertModuleEmpResult: "Data Added Successfully"});
  //       }
  //     );
  //   });
  // });



  
  

  // Get Module data using project ID

  router.get("/selectmodule", (req, res) => {
    const pro_id = req.query.pro_id;
    const getModuleData = "select * from project_modules where pro_id=?";
    db.query(getModuleData, [pro_id], (getModuleError, getModuleResult) => {
      if (getModuleError) {
        console.error("Error :", getModuleError);
        req.status(500).json({ getModuleError: "Error fetching Module data" });
      }
      // console.log("Result :", getModuleResult);
      res.status(200).json(getModuleResult);
    });
  });

  // Get Module Employee data using Pro_module_id

  router.get("/selectModuleEmployee", (req, res) => {
    const pro_module_id = req.query.pro_module_id;
    const getModuleEmployeeData =
      "select * from module_employee where pro_module_id =?";
    db.query(
      getModuleEmployeeData,
      [pro_module_id],
      (getModEmpError, getModEmpResult) => {
        if (getModEmpError) {
          console.error("Error :", getModEmpError);
          res.status(500).json({
            getModEmpError: "Error Module Employee data is not fetching",
          });
        }
        // console.log("Result :", getModEmpResult);
        res.status(200).json(getModEmpResult);
      }
    );
  });

  // Store Sub_module data and their employee data
  
  

  // Fetch Sub Module Data using module Id

  router.get("/selectSubModule", (req, res) => {
    const pro_module_id = req.query.pro_module_id;
    const getSubModuleData = "select * from sub_module where pro_module_id=?";
    db.query(
      getSubModuleData,
      [pro_module_id],
      (getSubModError, getSubModResult) => {
        if (getSubModError) {
          console.error("Error :", getSubModError);
          res
            .status(500)
            .json({ getSubModError: "Error fetching Sub Module Data" });
        }
        // console.log("Result :", getSubModResult);
        res.status(200).json(getSubModResult);
      }
    );
  });

  // Get SubModule Employee data using SubModule Id

  router.get("/selectSubmoduleEmployee", (req, res) => {
    const sub_mod_id = req.query.sub_mod_id;
    const getSubModuleEmployee =
      "select * from sub_module_employee where sub_mod_id=?";
    db.query(
      getSubModuleEmployee,
      [sub_mod_id],
      (getSubModEmpError, getSubModEmpResult) => {
        if (getSubModEmpError) {
          console.error("Error :", getSubModEmpError);
          res.status(500).json({
            getSubModEmpError: "Error fetching Sub Module Employee data",
          });
        }
        // console.log("Result :", getSubModEmpResult);
        res.status(200).json(getSubModEmpResult);
      }
    );
  });



 router.get('/updateProgress',(req,res) =>{
  const getProgress = "CALL UpdateProgress()";
  db.query(getProgress,(error,result) =>{
    if(error){
      console.error('Error executing stored procedure:', error);
      res.status(500).json({ error: 'Error executing stored procedure' });
    }
    // console.log('Stored procedure executed successfully');
    res.status(200).json({ message: 'Stored procedure executed successfully' });
  })
 })



//  fetching project data for date validation
router.get('/getProjectByProId/:pro_id', (req, res) => {
  const pro_id = req.params.pro_id;
  const getDataById = `SELECT * FROM projects WHERE pro_id = ?`;

  db.query(getDataById, [pro_id], (getDataErr, getDataRes) => {
    if (getDataErr) {
      console.error("Error:", getDataErr);
      res.status(500).json({ getDataErr: "Error fetching project data" });
    } else {
      const convertedData = getDataRes.map((project) => ({
        ...project,
        start_date: moment(project.start_date).format('YYYY-MM-DD'),
        end_date: moment(project.end_date).format('YYYY-MM-DD'),
        created_at: moment(project.created_at).format('YYYY-MM-DD HH:mm:ss'),
        updated_at: moment(project.updated_at).format('YYYY-MM-DD HH:mm:ss')
      }));
      res.status(200).json(convertedData);
    }
  });
});



router.get('/getProjectEmployeeByProId',(req,res) =>{
  const pro_id = req.query.pro_id;
  const getProEmpData = `
  select pro_emp.pro_emp_id,pro.pro_id, pro.pro_name,pro.start_date,pro.end_date,
  pro_emp.emp_id,pro_emp.emp_name,pro_emp.allocation_date,pro_emp.progress from projects pro 
  inner join project_employee pro_emp on pro.pro_id = pro_emp.pro_id where pro.pro_id = ?;
  `;
  db.query(getProEmpData,[pro_id],(getErr,getRes)=>{
    if(getErr){
      console.error("Error:",getErr);
      res.status(500).json({getErr:"Project Employee Data is not Fetched"})
    }else{
      if(getRes.length === 0){
        res.status(404).json({ message: "Project Employee Not Found" });
      }else{
        const convertData = getRes.map((proEmp) => ({
          ...proEmp,
          start_date: proEmp.start_date ? moment(proEmp.start_date).format("YYYY-MM-DD") : null,
          end_date: proEmp.end_date ? moment(proEmp.end_date).format("YYYY-MM-DD") : null,
          allocation_date: proEmp.allocation_date ? moment(proEmp.allocation_date).format("YYYY-MM-DD") : null
        }));
        res.status(200).json(convertData);
      }
    }
   
  })
})


router.put('/updeateProEmployee/:pro_emp_id', (req, res) => {
  const pro_emp_id = req.params.pro_emp_id;
  const { allocation_date, progress } = req.body;

  const updateData = `UPDATE project_employee SET allocation_date=?, progress=? WHERE pro_emp_id=?`;
  db.query(updateData, [allocation_date, progress, pro_emp_id], (updateErr, updateRes) => {
    if (updateErr) {
      res.status(500).json({ updateErr: "Project Employee Data could not be updated" });
    } else {
      if (updateRes.affectedRows > 0) {
        res.status(200).json({ message: "Project Employee data updated successfully" });
      } else {
        res.status(404).json({ error: "Project Employee not found or data remains unchanged" });
      }
    }
  });
});


router.delete('/deleteEmployee/:pro_emp_id', (req, res) => {
  const pro_emp_id = req.params.pro_emp_id;
  const dltData = 'DELETE FROM project_employee WHERE pro_emp_id = ?';

  db.query(dltData, [pro_emp_id], (dltErr, dltRes) => {
    if (dltErr) {
      res.status(500).json({ dltErr: "Project Employee could not be deleted" });
    } else {
      if (dltRes.affectedRows === 0) {
        res.status(404).json({ message: "Project Employee Not Found" });
      } else {
        res.status(200).json({ dltRes: "Project Employee Successfully Deleted" });
      }
    }
  });
});




router.get('/getEmpExceptIds', (req, res) => {
  const { employeeIds } = req.query;
  const exceptIds = JSON.parse(employeeIds);

  // Ensure exceptIds is an array before proceeding and it's not empty
  if (!Array.isArray(exceptIds) || exceptIds.length === 0) {
    return res.status(400).json({ error: 'Invalid or empty input for employeeIds' });
  }

  // Create placeholders for the query based on the length of exceptIds
  const placeholders = Array(exceptIds.length).fill('?').join(',');

  const query = `SELECT * FROM crm.employee WHERE emp_id NOT IN (${placeholders})`;

  db.query(query, exceptIds, (err, result) => {
    if (err) {
      console.error('Error fetching employee data:', err);
      return res.status(500).json({ error: 'Failed to fetch employee data' });
    }
    res.status(200).json(result);
  });
});



router.post('/addProjectEmployee', (req, res) => {
  const { pro_id, emp_id, pro_name, selectedEmployees, allocation_date } = req.body;

  // Construct the SQL query to insert data into your 'project_employee' table
  const sql = `INSERT INTO project_employee (pro_id, emp_id, pro_name, emp_name, allocation_date, created_at) VALUES ?`;

  const values = emp_id.map((empId, index) => [
    pro_id,
    empId,
    pro_name,
    selectedEmployees[index],
    allocation_date,
    new Date(), // Assuming 'created_at' is a timestamp field
  ]);

  // Perform the database insertion
  db.query(sql, [values], (error, results) => {
    if (error) {
      console.error('Error inserting data:', error);
      res.status(500).json({ message: 'Error inserting data' });
      return;
    }
    res.status(200).json({ message: 'Data inserted successfully' });
  });
});


router.get('/getProjectEmployeeByEmpId',(req,res) =>{
  const emp_id = req.query.emp_id;
  const getData = `select pro.pro_id,pro.cust_name,pro.cust_mobile,pro.cust_email,pro.pro_name,pro.pro_desc,
  pro.start_date,pro.end_date,pe.pro_emp_id,pe.emp_name,pe.progress from projects pro inner join project_employee pe 
  on pro.pro_id = pe.pro_id where emp_id=?`;
  db.query(getData,[emp_id],(getDataErr,getDataRes)=>{
    if(getDataErr){
      res.status(500).json({getDataErr:"Project Employee Data could not be fetched"})
    }else{
      if(getDataRes.length === 0){
        res.status(404).json({message:"Project Employee data not found"})
      }else{
        const convertData = getDataRes.map((proEmp)=>({
          ...proEmp,
          start_date : moment(proEmp.start_date).format('YYYY-MM-DD'),
          end_date   : moment(proEmp.end_date).format("YYYY-MM-DD")
        }))
        res.status(200).json(convertData)
      }
    }
  })


  router.put('/updateprogress/:pro_emp_id', (req, res) => {
    const pro_emp_id = req.params.pro_emp_id;
    const { progress } = req.body;
    const currentDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
    const updateProgress = 'UPDATE project_employee SET progress=?, updated_at=? WHERE pro_emp_id=?';
    
    db.query(updateProgress, [progress, currentDateTime, pro_emp_id], (updateErr, updateRes) => {
      if (updateErr) {
        res.status(500).json({ updateErr: 'Progress could not be updated.' });
      } else {
        if (updateRes.affectedRows > 0) {
          res.status(200).json({ updateRes: 'Progress data updated successfully.' });
        } else {
          res.status(500).json({ updateErr: 'No rows affected, progress not updated.' });
        }
      }
    });
  });

})




  return router;
};
