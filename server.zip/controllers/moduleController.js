const express = require('express');
const router  = express.Router();
const moment = require('moment');

module.exports = (db) =>{


  


    router.post("/projectModule", (req, res) => {
        const {
          cust_id,
          pro_id,
          pro_name,
          module_name,
          module_desc,
          start_date,
          end_date,
          selectedEmployees,
        } = req.body;
      
        const getProjectDate = "SELECT * FROM projects WHERE pro_id = ?";
        db.query(getProjectDate, [pro_id], (getProError, getProResult) => {
          if (getProError) {
            console.log("Error :", getProError);
            return res.status(500).json({ getProError: "Error fetching project data" });
          }
          if (getProResult.length === 0) {
            return res.status(404).json({ message: "Project Not Found" });
          }
      
          const currentDate = moment().format("YYYY-MM-DD HH:mm:ss");
          const projectStartDate = new Date(getProResult[0].start_date);
          const projectEndDate = new Date(getProResult[0].end_date);
          const inputModuleStartDate = new Date(start_date);
          const inputModuleEndDate = new Date(end_date);
      
          if (projectStartDate > inputModuleStartDate || projectStartDate > inputModuleEndDate) {
            return res.status(400).json({ Message: "Module dates are before project start date" });
          } else if (projectEndDate < inputModuleStartDate || projectEndDate < inputModuleEndDate) {
            return res.status(400).json({ message: "Module dates are after project end date" });
          }
      
          const insertProjectModule = `
            INSERT INTO project_modules (pro_id, pro_name, module_name, module_desc, start_date, end_date, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
          `;
          db.query(
            insertProjectModule,
            [pro_id, pro_name, module_name, module_desc, start_date, end_date, currentDate],
            (insertModuleError, insertModuleResult) => {
              if (insertModuleError) {
                console.log("Error :", insertModuleError);
                return res.status(500).json({ insertModuleError: "Error adding module data" });
              }
      
              const pro_module_id = insertModuleResult.insertId;
              const insertPromises = selectedEmployees.map((empId) => {
                return new Promise((resolve, reject) => {
                  const getEmployee = "SELECT * FROM project_employee WHERE emp_id = ?";
                  db.query(getEmployee, [empId], (empError, empResult) => {
                    if (empError) {
                      console.error("Error:", empError);
                      reject({ empError: "Error fetching employee data" });
                    } else {
                      const emp_name = empResult[0].emp_name;
                      const insertModuleEmployee = `
                        INSERT INTO module_employee (pro_id, pro_module_id, emp_id, pro_name, module_name, emp_name, allocation_date, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                      `;
                      db.query(
                        insertModuleEmployee,
                        [pro_id, pro_module_id, empId, pro_name, module_name, emp_name, currentDate, currentDate],
                        (insertModuleEmpError, insertModuleEmpResult) => {
                          if (insertModuleEmpError) {
                            console.error("Error :", insertModuleEmpError);
                            reject({ insertmoduleEmpError: "Error adding employee data" });
                          } else {
                            resolve(insertModuleEmpResult);
                          }
                        }
                      );
                    }
                  });
                });
              });
      
              Promise.all(insertPromises)
                .then(() => {
                  res.status(200).json({ message: "Data Added Successfully" });
                })
                .catch((error) => {
                  res.status(500).json(error);
                });
            }
          );
        });
      });


      router.get('/getModuleData',(req,res)=>{
        const getModuleData = "select * from project_modules inner join module_employee on project_modules.pro_module_id = module_employee.pro_module_id";
        db.query(getModuleData,(getModerr,getModResult) =>{
            if(getModerr){
                console.error("Error :",getModerr)
            }
            else if(getModResult.length == 0){
                res. status(404).json({Message :"Module Data Not Found"});
            }
            else {

                res.status(200).json(getModResult)

            }
        })
      })

      router.get("/getModuleEmp/:pro_module_id", (req, res) => {
        const pro_module_id = req.params.pro_module_id;
        const getModuleEmp = "select * from module_employee where pro_module_id=?";
        db.query(getModuleEmp, [pro_module_id], (getEmpErr, getEmpResult) => {
          if (getEmpErr) {
            console.error("Error :", getEmpErr);
            res
              .status(500)
              .json({ getEmpErr: "Error Module Employee data is not fetching." });
          }
          // console.log("Result :", getEmpResult);  
          res.status(200).json(getEmpResult);
        });
      });

      
      // router.put('/updateModule/:pro_module_id', (req, res) => {
      //   const pro_module_id = req.params.pro_module_id;
      //   const {
      //     pro_id,
      //     pro_name,
      //     module_name,
      //     module_desc,
      //     start_date,
      //     end_date,
      //     emp_id,
      //     emp_name
      //   } = req.body;
      
      //   const updated_at = moment().format('YYYY-MM-DD HH:mm:ss');
      
      //   const updateModule = `UPDATE project_modules SET pro_id=?, pro_name=?, module_name=?, module_desc=?, start_date=?, end_date=?, updated_at=? WHERE pro_module_id=?`;
      //   db.query(updateModule, [
      //     pro_id,
      //     pro_name,
      //     module_name,
      //     module_desc,
      //     start_date,
      //     end_date,
      //     updated_at,
      //     pro_module_id
      //   ], (updateErr, updateRes) => {
      //     if (updateErr) {
      //       console.error("Error", updateErr);
      //       return res.status(500).json({ updateErr: "Module data is not updated" });
      //     }
      
      //     const selectExistingEmployee = "SELECT emp_id FROM module_employee WHERE pro_module_id = ?";
      //     db.query(selectExistingEmployee, [pro_module_id], (existEmpErr, existEmpRes) => {
      //       if (existEmpErr) {
      //         console.error("Error", existEmpErr);
      //         return res.status(500).json({ existEmpErr: "Error retrieving existing employees" });
      //       }
      
      //       const previousEmployeeIDs = existEmpRes.map(row => row.emp_id);
      //       const removedEmployees = previousEmployeeIDs.filter(id => !emp_id.includes(id));
      
      //       removedEmployees.forEach(empID => {
      //         const dltData = 'DELETE FROM module_employee WHERE pro_module_id=? AND emp_id=?';
      //         db.query(dltData, [pro_module_id, empID], (dltErr, dltRes) => {
      //           if (dltErr) {
      //             console.error("Error deleting Module Employee record :", dltErr);
      //           }
      //           // Handle successful deletion if needed
      //         });
      //       });
      
      //       for (let i = 0; i < emp_id.length; i++) {
      //         const selectQuery = "SELECT COUNT(*) AS count FROM module_employee WHERE pro_module_id=? AND emp_id=?";
      //         db.query(selectQuery, [pro_module_id, emp_id[i]], (selectErr, selectResult) => {
      //           if (selectErr) {
      //             console.error("Error checking if data exists:", selectErr);
      //             return res.status(500).json({ error: "Error checking data existence" });
      //           }

      //           const allocation_date = moment().format('')
      //           const count = selectResult[0].count;
      //           if (count === 0) {
      //             const moduleEmp = `INSERT INTO module_employee(pro_id, pro_module_id, emp_id, pro_name, module_name, emp_name, allocation_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
      //             db.query(moduleEmp, [
      //               pro_id,
      //               pro_module_id,
      //               emp_id[i],
      //               pro_name,
      //               module_name,
      //               emp_name[i],
      //               allocation_date,
      //               updated_at
      //             ], (moduleEmpInsertErr, moduleEmpInsertRes) => {
      //               if (moduleEmpInsertErr) {
      //                 console.error("Error inserting Module Employee data:", moduleEmpInsertErr);
      //                 return res.status(500).json({ error: "Error inserting Module Employee data" });
      //               }
      //               // Handle successful insertion if needed
      //             });
      //           } else {
      //             const updateModuleEmp = `
      //               UPDATE module_employee 
      //               SET pro_id=?, pro_module_id=?, emp_id=?, pro_name=?, module_name=?, emp_name=?, updated_at=?
      //               WHERE pro_module_id=? AND emp_id=?
      //             `;
      //             db.query(updateModuleEmp, [
      //               pro_id,
      //               pro_module_id,
      //               emp_id[i],
      //               pro_name,
      //               module_name,
      //               emp_name[i],
      //               updated_at,
      //               pro_module_id,
      //               emp_id[i]
      //             ], (updateModuleEmpErr, updateModuleEmpRes) => {
      //               if (updateModuleEmpErr) {
      //                 console.error("Error updating Module Employee data:", updateModuleEmpErr);
      //                 return res.status(500).json({ error: "Error updating Module Employee data" });
      //               }
      //               // Handle successful update if needed
      //             });
      //           }
      //         });
      //       }
      //       // Respond with success message or appropriate response after updating module employees
      //       res.status(200).json({ message: "Module data updated successfully" });
      //     });
      //   });
      // });
      

      router.put('/updateModule/:pro_module_id', async (req, res) => {
        try {
          const pro_module_id = req.params.pro_module_id;
          const {
            pro_id,
            pro_name,
            module_name,
            module_desc,
            start_date,
            end_date,
            emp_id,
            emp_name
          } = req.body;
      
          const updated_at = moment().format('YYYY-MM-DD HH:mm:ss');
      
          // Disable foreign key checks before performing operations
          await db.promise().query('SET FOREIGN_KEY_CHECKS = 0');
      
          const updateModule = `UPDATE project_modules SET pro_id=?, pro_name=?, module_name=?, module_desc=?, start_date=?, end_date=?, updated_at=? WHERE pro_module_id=?`;
          await db.promise().query(updateModule, [
            pro_id,
            pro_name,
            module_name,
            module_desc,
            start_date,
            end_date,
            updated_at,
            pro_module_id
          ]);
      
          const selectExistingEmployee = "SELECT emp_id FROM module_employee WHERE pro_module_id = ?";
          const [existEmpRes] = await db.promise().query(selectExistingEmployee, [pro_module_id]);
      
          const previousEmployeeIDs = existEmpRes.map(row => row.emp_id);
          const removedEmployees = previousEmployeeIDs.filter(id => !emp_id.includes(id));
      
          for (const empID of removedEmployees) {
            const dltData = 'DELETE FROM module_employee WHERE pro_module_id=? AND emp_id=?';
            await db.promise().query(dltData, [pro_module_id, empID]);
          }
      
          for (let i = 0; i < emp_id.length; i++) {
            const selectQuery = "SELECT COUNT(*) AS count FROM module_employee WHERE pro_module_id=? AND emp_id=?";
            const [selectResult] = await db.promise().query(selectQuery, [pro_module_id, emp_id[i]]);
      
            const allocation_date = moment().format('YYYY-MM-DD HH:mm:ss');
            const count = selectResult[0].count;
      
            if (count === 0) {
              const moduleEmp = `INSERT INTO module_employee(pro_id, pro_module_id, emp_id, pro_name, module_name, emp_name, allocation_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
              await db.promise().query(moduleEmp, [
                pro_id,
                pro_module_id,
                emp_id[i],
                pro_name,
                module_name,
                emp_name[i],
                allocation_date,
                updated_at
              ]);
            } else {
              const updateModuleEmp = `
                UPDATE module_employee 
                SET pro_id=?, pro_module_id=?, emp_id=?, pro_name=?, module_name=?, emp_name=?, updated_at=?
                WHERE pro_module_id=? AND emp_id=?
              `;
              await db.promise().query(updateModuleEmp, [
                pro_id,
                pro_module_id,
                emp_id[i],
                pro_name,
                module_name,
                emp_name[i],
                updated_at,
                pro_module_id,
                emp_id[i]
              ]);
            }
          }
      
          res.status(200).json({ message: "Module data updated successfully" });
        } catch (error) {
          console.error("Error:", error);
          res.status(500).json({ error: "Internal server error" });
        }
      });
            


      router.delete('/delete',(req,res) =>{
        const pro_module_id = req.query.pro_module_id;
        const dltData = "delete from project_modules where pro_module_id = ?";
        db.query(dltData,[pro_module_id],(dltErr,dltRes) =>{
          if(dltErr){
            console.error("Error",dltErr);
            res.status(500).json({dltErr:'Error Module Data is Not Deleted'})
          }
          res.status(200).json({ message: "Module Data is deleted successfully" });
        })
      })



    return router;
}