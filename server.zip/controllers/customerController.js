const express = require("express");
const router = express.Router();
const moment = require("moment");
const multer = require("multer");
const xlsx = require("xlsx");

module.exports = (db) => {
  const storage = multer.memoryStorage();
  const upload = multer({ storage: storage });

  router.get("/", (req, res) => {
    // const getCustomer = 'select cust_id,cust_name,cust_email,cust_mobile,bus_name,bus_category,follow_emp_id,follow_emp_name,follow_up_date,converted_to_customer from customers where converted_to_customer = "no"';
    const getCustomer = `
        SELECT 
        customers.*,
        enteredBy.emp_name as entered_emp_name,
        followedBy.emp_name as followed_by 
        FROM 
        customers 
        JOIN 
        employee as enteredBy ON customers.entered_by = enteredBy.emp_id 
        JOIN 
        employee as followedBy ON customers.follow_emp_id = followedBy.emp_id
        `;
    db.query(getCustomer, (error, results) => {
      if (error) {
        res.status(500).json({ error: "Error retrieving Customers" });
        return;
      }

      const categoryLookup = {
        1: "1st Priority",
        2: "2nd Priority",
        3: "3rd Priority",
        4: "4th Priority",
      };

      const convertData = results.map((cust) => ({
        ...cust,
        category: categoryLookup[cust.category] || null,
        follow_up_date: moment(cust.follow_up_date).format("YYYY-MM-DD"),
        converted_dated: moment(cust.converted_dated).format("YYYY-MM-DD"),
        created_at: moment(cust.created_at).format("YYYY-MM-DD HH:mm:ss"),
        updated_at: moment(cust.updated_at).format("YYYY-MM-DD HH:mm:ss"),
      }));
      res.json(convertData);
    });
  });

  router.get("/converted_customer", (req, res) => {
    getConvertedCustomer = `
    SELECT 
    customers.*,
    enteredBy.emp_name as entered_emp_name,
    followedBy.emp_name as followed_by 
    FROM 
    customers 
    JOIN 
    employee as enteredBy ON customers.entered_by = enteredBy.emp_id 
    JOIN 
    employee as followedBy ON customers.follow_emp_id = followedBy.emp_id where converted_to_customer = 'yes'`;

    db.query(getConvertedCustomer, (customerError, customerResult) => {
      if (customerError) {
        res
          .status(500)
          .json({ customerError: "Error Fetching Converted Customer" });
        return; // Return early to avoid further execution on error
      }

      const categoryLookup = {
        1: "1st Priority",
        2: "2nd Priority",
        3: "3rd Priority",
        4: "4th Priority",
      };

      const convertData = customerResult.map((cust) => ({
        ...cust,
        category: categoryLookup[cust.category] || null,
        follow_up_date: moment(cust.follow_up_date).format("YYYY-MM-DD"),
        converted_dated: moment(cust.converted_dated).format("YYYY-MM-DD"),
        created_at: moment(cust.created_at).format("YYYY-MM-DD HH:mm:ss"),
        updated_at: moment(cust.updated_at).format("YYYY-MM-DD HH:mm:ss"),
      }));

      res.json(convertData);
    });
  });

  router.get("/project_customer", (req, res) => {
    getConvertedCustomer =
      "select cust.cust_id,cust.cust_name,cust.cust_email,cust.cust_mobile,cust.bus_name,cust.bus_category,cust.follow_emp_id,cust.follow_up_date,cust.converted_to_customer,cust.converted_dated,pro.pro_name,cust.cust_amount,cust.payment_status,emp.emp_name as follow_emp_name from customers cust inner join projects pro on cust.cust_id =  pro.cust_id join employee emp on cust.follow_emp_id = emp.emp_id where cust.converted_to_customer = 'yes'";
    db.query(getConvertedCustomer, (customerError, customerResult) => {
      if (customerError) {
        res
          .status(500)
          .json({ customerError: "Error Fetching Converted Customer" });
      }
      res.json(customerResult);
    });
  });

  //  router.post('/' , (req,res) =>{
  //   const {
  //       cust_name,
  //       cust_email,
  //       cust_mobile,
  //       bus_name,
  //       bus_category,
  //       follow_emp_id, // Receive the employee ID
  //       follow_up_date,
  //       converted_to_customer,
  //       converted_dated,
  //       cust_amount,
  //       payment_status,
  //       category,
  //   } = req.body;
  //   // Check for empty or undefined values
  //   const valuesToCheck = [
  //     cust_name,
  //     cust_email,
  //     cust_mobile,
  //     bus_name,
  //     bus_category,
  //     follow_emp_id,
  //     follow_up_date,
  //     converted_to_customer,
  //     converted_dated,
  //     cust_amount,
  //     payment_status,
  //     category,
  // ];

  // if (valuesToCheck.some(value => value === undefined || value === '')) {
  //     return res.status(400).json({ error: "One or more fields are empty" });
  // }
  //   const getEmployee = "select emp_name from employee where emp_id = ?";
  //   db.query(getEmployee , [follow_emp_id] , (error,result) =>{
  //       if(error){
  //           console.error("Error :" , error)
  //           res.status(500).json({error:"Error Fetching Employee "})
  //       }
  //       else{
  //           const follow_emp_name = result[0].emp_name;
  //           const currentTime = moment().format('YYYY-MM-DD HH:mm:ss');
  //           const insertCustomer = "insert into customers (cust_name, cust_email, cust_mobile, bus_name, bus_category, follow_emp_id, follow_emp_name, follow_up_date, converted_to_customer, converted_dated, cust_amount, payment_status,category, created_at) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  //           db.query(insertCustomer , [
  //               cust_name,
  //               cust_email,
  //               cust_mobile,
  //               bus_name,
  //               bus_category,
  //               follow_emp_id,
  //               follow_emp_name, // Include the employee name
  //               follow_up_date,
  //               converted_to_customer,
  //               converted_dated,
  //               cust_amount,
  //               payment_status,
  //               category,
  //               currentTime
  //           ],(error,result) =>{
  //               if (error) {
  //                   console.error('Error:', error);
  //                   res.status(500).json({ error: "Error Adding Customer" });
  //               } else {
  //                   // console.log("Result:", result);
  //                   res.json({ result: "Successfully Added Customer" });
  //               }
  //           }
  //           )
  //       }
  //   })
  //  })

  router.post("/", (req, res) => {
    const {
      cust_name,
      cust_email,
      cust_mobile,
      bus_name,
      bus_category,
      follow_emp_id,
      follow_up_date,
      dist,
      city,
      converted_to_customer,
      converted_dated,
      cust_amount,
      payment_status,
      category,
      entered_by,
    } = req.body;

    if (converted_to_customer === "yes") {
      const valuesToCheck = [
        cust_name,
        cust_email,
        cust_mobile,
        bus_name,
        bus_category,
        follow_emp_id,
        follow_up_date,
        dist,
        city,
        converted_to_customer,
        converted_dated,
        cust_amount,
        payment_status,
        category,
        entered_by,
      ];

      if (valuesToCheck.some((value) => value === undefined || value === "")) {
        return res.status(400).json({ error: "One or more fields are empty" });
      }

      const currentTime = moment().format("YYYY-MM-DD HH:mm:ss");
      const insertCustomer =
        "INSERT INTO customers (cust_name, cust_email, cust_mobile, bus_name, bus_category, follow_emp_id, follow_up_date, dist, city, converted_to_customer,converted_dated,cust_amount,payment_status,category,entered_by, created_at) VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?)";

      db.query(
        insertCustomer,
        [
          cust_name,
          cust_email,
          cust_mobile,
          bus_name,
          bus_category,
          follow_emp_id,
          follow_up_date,
          dist,
          city,
          converted_to_customer,
          converted_dated,
          cust_amount,
          payment_status,
          category,
          entered_by,
          currentTime,
        ],
        (error, result) => {
          if (error) {
            res.status(500).json({ error: "Error Adding Customer" });
            console.log("Error:", error);
          } else {
            res.json({ result: "Successfully Added Customer" });
          }
        }
      );
    } else if (converted_to_customer === "no") {
      const valuesToCheck = [
        cust_name,
        cust_email,
        cust_mobile,
        bus_name,
        bus_category,
        follow_emp_id,
        follow_up_date,
        dist,
        city,
        converted_to_customer,
        entered_by,
      ];

      if (valuesToCheck.some((value) => value === undefined || value === "")) {
        return res.status(400).json({ error: "One or more fields are empty" });
      }

      const currentTime = moment().format("YYYY-MM-DD HH:mm:ss");
      const insertCustomer =
        "INSERT INTO customers (cust_name, cust_email, cust_mobile, bus_name, bus_category, follow_emp_id, follow_up_date, dist, city, converted_to_customer,entered_by, created_at) VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      db.query(
        insertCustomer,
        [
          cust_name,
          cust_email,
          cust_mobile,
          bus_name,
          bus_category,
          follow_emp_id,
          follow_up_date,
          dist,
          city,
          converted_to_customer,
          entered_by,
          currentTime,
        ],
        (error, result) => {
          if (error) {
            res.status(500).json({ error: "Error Adding Customer" });
            console.log("Error:", error);
          } else {
            res.json({ result: "Successfully Added Customer" });
          }
        }
      );
    }
  });

  router.put("/:cust_id", (req, res) => {
    const cust_id = req.params.cust_id;
    const {
        cust_name,
        cust_email,
        cust_mobile,
        bus_name,
        bus_category,
        follow_emp_id,
        follow_up_date,
        dist,
        city,
        converted_to_customer,
        converted_dated,
        cust_amount,
        payment_status,
        category,
        entered_by,
    } = req.body;

    const currentTime = moment().format("YYYY-MM-DD HH:mm:ss");

    // Helper function to check and set value to null if invalid or empty
    const setNullIfInvalid = (value) => {
        return value === "" || value === undefined || value === "Invalid date"
            ? null
            : value;
    };

    let updateCustomerQuery = `UPDATE customers SET 
        cust_name=?, 
        cust_email=?, 
        cust_mobile=?, 
        bus_name=?, 
        bus_category=?, 
        follow_emp_id=?, 
        follow_up_date=?, 
        dist=?, 
        city=?, 
        converted_to_customer=?, 
        converted_dated=?, 
        cust_amount=?, 
        payment_status=?, 
        category=?, 
        entered_by=?, 
        updated_at=? 
        WHERE cust_id = ?`;

    let validatedValues = [cust_name, cust_email, cust_mobile, bus_name, bus_category, follow_emp_id, follow_up_date,
        dist, city, converted_to_customer, converted_dated, cust_amount, payment_status, category, entered_by, currentTime, cust_id];

    // Additional conditions for the update query based on converted_to_customer value
    if (converted_to_customer === "no") {
        // Adjust the update query based on the condition when converted_to_customer is 'no'
        updateCustomerQuery = `UPDATE customers SET 
            cust_name=?, 
            cust_email=?, 
            cust_mobile=?, 
            bus_name=?, 
            bus_category=?, 
            follow_emp_id=?, 
            follow_up_date=?, 
            dist=?, 
            city=?, 
            converted_to_customer=?,
            entered_by=?, 
            updated_at=? 
            WHERE cust_id = ?`;
        validatedValues = [cust_name, cust_email, cust_mobile, bus_name, bus_category, follow_emp_id, follow_up_date,
            dist, city, converted_to_customer, entered_by, currentTime, cust_id];
    }
    

    db.query(updateCustomerQuery, validatedValues, (error, results) => {
        if (error) {
            res.status(500).json({ error: "Error Updating Customer" });
        } else {
            res.status(200).json({ message: "Customer updated successfully" });
        }
    });
});



  router.delete("/:cust_id/delete", (req, res) => {
    const custId = req.params.cust_id;

    const deleteCustomer = "DELETE FROM customers WHERE cust_id = ?";

    db.query(deleteCustomer, [custId], (err, results) => {
      if (err) {
        res.status(500).json({ error: "Error deleting Customer" });
      } else {
        res.status(200).json({ message: "Customer deleted successfully" });
      }
    });
  });

  router.get("/getCustomerByEmpID", (req, res) => {
    const emp_id = req.query.emp_id;
    const getCustData = "select customers.*,emp.emp_name as follow_emp_name from customers join employee emp on customers.follow_emp_id = emp.emp_id where follow_emp_id = ?";
    db.query(getCustData, [emp_id], (getCustErr, getCustRes) => {
      if (getCustErr) {
        res
          .status(500)
          .json({
            getCustErr: "Error Customer data is not fetching using Employee Id",
          });
      }
      const categoryLookup = {
        1: "1st Priority",
        2: "2nd Priority",
        3: "3rd Priority",
        4: "4th Priority",
        // Add more categories if needed
      };
      const custData = getCustRes.map((customer) => ({
        ...customer,
        follow_up_date: moment(customer.follow_up_date).format("YYYY-MM-DD"),
        converted_dated: moment(customer.converted_dated).format("YYYY-MM-DD"),
        category: categoryLookup[customer.category] || null,
      }));

      res.json(custData);
    });
  });

  router.post("/importLeads", upload.single("file"), (req, res) => {
    if (!req.file) {
      return res.status(400).send("No file uploaded");
    } else {
      const workBook = xlsx.read(req.file.buffer, { type: "buffer" });
      const sheetName = workBook.SheetNames[0]; // Corrected to access SheetNames as an array
      const sheet = workBook.Sheets[sheetName];
      const data = xlsx.utils.sheet_to_json(sheet); // Corrected method name to sheet_to_json

      const currentDate = moment().format("YYYY-MM-DD HH:mm:ss");

      const { follow_emp_id, entered_by } = req.body;

      const insertQuery = `INSERT INTO customers (cust_name, cust_email, cust_mobile, bus_name, bus_category, follow_emp_id, follow_up_date, dist, city, entered_by, created_at) VALUES ?`; // Removed parentheses around values placeholder
      const leadsData = data.map((leads) => [
        leads.cust_name,
        leads.cust_email,
        leads.cust_mobile,
        leads.bus_name,
        leads.bus_category,
        follow_emp_id,
        moment(leads.follow_up_date).format("YYYY-MM-DD"),
        leads.dist,
        leads.city,
        entered_by,
        currentDate,
      ]);
      db.query(insertQuery, [leadsData], (err, result) => {
        if (err) {
          console.error("Error inserting leads data:", err);
          res
            .status(500)
            .json({
              message:
                "Internal server Error. Leads data could not be uploaded",
            });
        } else {
          console.log("Leads data inserted successfully:", result);
          res
            .status(200)
            .json({ message: "Leads data uploaded successfully." });
        }
      });
    }
  });

  return router;
};

// router.post('/importLeads', upload.single('file'), (req, res) => {
//   if (!req.file) {
//     return res.status(400).send('No file uploaded');
//   } else {
//     const workBook = xlsx.read(req.file.buffer, { type: 'buffer' });
//     const sheetName = workBook.SheetNames[0]; // Corrected to access SheetNames as an array
//     const sheet = workBook.Sheets[sheetName];
//     const data = xlsx.utils.sheet_to_json(sheet); // Corrected method name to sheet_to_json

//     const currentDate = moment().format('YYYY-MM-DD HH:mm:ss');

//     const insertQuery = `INSERT INTO customers (cust_name, cust_email, cust_mobile, bus_name, bus_category, follow_emp_id, follow_up_date, dist, city, entered_by, created_at) VALUES ?`; // Removed parentheses around values placeholder
//     const leadsData = data.map((leads) => [leads.cust_name, leads.cust_email, leads.cust_mobile, leads.bus_name, leads.bus_category, leads.follow_emp_id, moment(leads.follow_up_date).format('YYYY-MM-DD'), leads.dist, leads.city, leads.entered_by, currentDate]);
//     db.query(insertQuery, [leadsData], (err, result) => {
//       if (err) {
//           console.error("Error inserting leads data:", err);
//           res.status(500).json({ message: "Internal server Error. Leads data could not be uploaded" });
//       } else {
//           console.log("Leads data inserted successfully:", result);
//           res.status(200).json({ message: "Leads data uploaded successfully." });
//       }
//   });

//   }
// });
