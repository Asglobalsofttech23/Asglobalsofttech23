const express = require('express');
const router = express.Router();
const moment = require('moment');

module.exports = (db) => {


  
  router.get('/', (req, res) => {
    const dept_id = req.query.dept_id;
  
    if (!dept_id) {
      return res.status(400).json({ error: 'dept_id is required' });
    }
  
    const getRolesQuery = `SELECT role_id, role FROM role WHERE dept_id = ?`;
  
    db.query(getRolesQuery, [dept_id], (error, results) => {
      if (error) {
        console.error('Error fetching roles:', error);
        return res.status(500).json({ error: 'Error fetching roles' });
      }
  
      res.json(results); // Returning the results directly
    });
  });
  

    return router;

}