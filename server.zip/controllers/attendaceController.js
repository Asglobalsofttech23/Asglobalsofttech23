const express = require('express');
const router = express.Router();
const moment = require('moment');

module.exports = (db) => {
  
  
  router.post('/entry', (req, res) => {
    const { emp_id, emp_name, emp_email } = req.body;
    const currentDate = moment().format('YYYY-MM-DD');
    const currentDateTime = moment().format('YYYY-MM-DD HH:mm:ss');
    const currentTime = moment().format('HH:mm:ss');
    // Check if an entry already exists for the employee on the current date
    const checkEntryQuery = 'SELECT * FROM emp_entry WHERE emp_id = ? AND date = ?';
    db.query(checkEntryQuery, [emp_id, currentDate], (checkEntryError, checkEntryResult) => {
      if (checkEntryError) {
        return res.status(500).json({ error: 'Error checking attendance entry' });
      }
  
      if (checkEntryResult.length > 0) {
        // Entry already exists for the employee on the same date
        console.error('Attendance entry already exists for the employee on the same date');
        return res.status(409).json({ error: 'Duplicate attendance entry' });
      }
  
      // Insert a new attendance entry as no entry exists for the employee on the current date
      const insertDataQuery =
        'INSERT INTO emp_entry (emp_id, emp_name, emp_email, date, login_time, is_in, created_at) VALUES (?, ?, ?, ?, ?, 1, ?)';
      db.query(
        insertDataQuery,
        [emp_id, emp_name, emp_email, currentDate, currentTime,currentDateTime],
        (insertError, insertResult) => {
          if (insertError) {
            console.error('Error:', insertError);
            return res.status(500).json({ error: 'Error adding data' });
          }
  
          // console.log('Result:', insertResult);
          return res.status(200).json({ message: 'Successfully added data' });
        }
      );
    });
  });
  
  



// router.post('/entry', (req, res) => {
//     const { emp_email } = req.body;

//     const getEmployee = 'SELECT * FROM employee WHERE emp_email=?';
//     db.query(getEmployee, [emp_email], (getEmployeeError, getEmployeeResult) => {
//       if (getEmployeeError) {
//         console.error("Error:", getEmployeeError);
//         return res.status(500).json({ getEmployeeError: 'Error Fetching Employee' });
//       }

//       if (getEmployeeResult.length === 0) {
//         // No employee found with the provided email
//         return res.status(404).json({ error: 'Employee not found' });
//       }

//       const { emp_id, emp_name, emp_email } = getEmployeeResult[0];
//       const currentDate = moment().format('YYYY-MM-DD');

//       // Check if an entry already exists for the employee on the current date
//       const checkEntryQuery = 'SELECT * FROM emp_entry WHERE emp_id = ? AND date = ?';
//       db.query(checkEntryQuery, [emp_id, currentDate], (checkEntryError, checkEntryResult) => {
//         if (checkEntryError) {
//           console.error('Error:', checkEntryError);
//           return res.status(500).json({ checkEntryError: 'Error Checking Attendance Entry' });
//         }

//         if (checkEntryResult.length > 0) {
//           // Entry already exists for the employee on the same date
//           console.error('Attendance entry already exists for the employee on the same date');
//           return res.status(409).json({ error: 'Duplicate Attendance Entry' });
//         }

//         // Insert a new attendance entry
//         const insertDataQuery =
//           'INSERT INTO emp_entry (emp_id, emp_name, emp_email, date, login_time, is_in) VALUES (?, ?, ?, ?, NOW(), 1)';
//         db.query(
//           insertDataQuery,
//           [emp_id, emp_name, emp_email, currentDate],
//           (insertError, insertResult) => {
//             if (insertError) {
//               console.error('Error:', insertError);
//               return res.status(500).json({ insertError: 'Error Adding Data' });
//             }

//             console.log('Result:', insertResult);
//             return res.status(200).json({ insertResult: 'Successfully Added Data' });
//           }
//         );
//       });
//     });
//   });




router.put('/exit', (req, res) => {
  const { emp_id } = req.body;
  const currentDate = moment().format('YYYY-MM-DD');
  const currentTime = moment().format('HH:mm:ss');

  // Check if an entry exists for the employee on the current date
  const checkEntryQuery = 'SELECT * FROM emp_entry WHERE emp_id = ? AND date = ? AND is_in = 1';
  db.query(checkEntryQuery, [emp_id, currentDate], (checkEntryError, checkEntryResult) => {
    if (checkEntryError) {
      console.error('Error:', checkEntryError);
      return res.status(500).json({ error: 'Error checking attendance entry' });
    }

    if (checkEntryResult.length === 0) {
      // No entry found for the employee or already exited for the day
      console.error('No entry found or already exited for the day');
      return res.status(404).json({ error: 'No entry found or already exited for the day' });
    }

    // Update the entry with the logout time
    const exitQuery =
      'UPDATE emp_entry SET logout_time = ?, is_in = 0 WHERE emp_id = ? AND date = ? AND is_in = 1';
    db.query(exitQuery, [currentTime, emp_id, currentDate], (exitError, exitResult) => {
      if (exitError) {
        console.error('Error:', exitError);
        return res.status(500).json({ error: 'Error updating exit time' });
      }

      return res.status(200).json({ message: 'Successfully updated exit time' });
    });
  });
});

  


  





  router.get('/',(req,res) =>{
    const getEntryData = "select emp.emp_name,emp.emp_mobile,emp.emp_email,emp.emp_img,entry.date,entry.login_time,entry.is_in from employee emp inner join emp_entry entry on emp.emp_id = entry.emp_id where entry.is_in = '1'";
    db.query(getEntryData , (getEntryError,getEntryResult) =>{
        if(getEntryError){
            console.error("Error :" , getEntryError);
            res.status(500).json({getEntryError:"Error fetch Entry data"})
        }
        const convertImg = getEntryResult.map((img) =>({
          ...img,
          emp_img : img.emp_img.toString('base64')
        }))
        res.json(convertImg)
    })
  })

  return router;
};
