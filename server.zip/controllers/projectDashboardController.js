const express = require("express");
const router = express.Router();
const moment = require("moment");

module.exports = (db) => {


  router.get("/projectCount", (req, res) => {
    const getProCount = `
    SELECT 
    (SELECT COUNT(*) FROM projects) AS total_projects,
    (SELECT COUNT(*) FROM project_employee WHERE progress = 100) AS completed_projects,
    (SELECT COUNT(*) FROM projects p WHERE p.pro_id NOT IN (SELECT pe.pro_id FROM project_employee pe WHERE pe.progress = 100)) AS pending_projects

    `;
    
    db.query(getProCount, (proCountErr, proCountResult) => {
        if (proCountErr) {
            console.error("Error :", proCountErr);
            res.status(500).json({
                proCountErr: "Error fetching the Project Count Data",
            });
        } else {
            // console.log("Result :", proCountResult);
            res.json(proCountResult);
        }
    });
});




  // router.get("/projectCound", (req, res) => {
  //   const getProCound = "CALL GetProjectStats();";
  //   db.query(getProCound, (proCountErr, proCountResult) => {
  //     if (proCountErr) {
  //       console.error("Error :", proCountErr);
  //       res.status(500).json({
  //         proCountErr: "Error the Project Count Data is Not Fetching",
  //       });
  //     }
  //     console.log("Result :", proCountResult);
  //     res.json(proCountResult);
  //   });
  // });

  router.get("/allprojectdashboard", (req, res) => {
    const getAllProject = `SELECT  p.pro_id, p.pro_name, LEAST(IFNULL(SUM(pe.progress) / (COUNT(pe.emp_id) * 100), 0), 1) * 100 AS overall_completion_percentage FROM  projects p LEFT JOIN  project_employee pe ON p.pro_id = pe.pro_id GROUP BY p.pro_id,p.pro_name;`;
    db.query(getAllProject, (proErr, proResult) => {
      if (proErr) {
        console.error("Error :", proErr);
        res.status(500).json({ proErr: "Error Fetching Project Data" });
      }
      // console.log("Result :", proResult);
      res.status(200).json(proResult);
    });
  });

  router.get("/singleprojectEmp", (req, res) => {
    const pro_id = req.query.pro_id;
    const getProjectPercentage = `
      SELECT pe.pro_id,pe.pro_name,pe.emp_id,pe.emp_name,pe.progress,LEAST(SUM(pe.progress) / (COUNT(pe.emp_id) * 100), 1) * 100 AS overall_completion_percentage
        FROM
            project_employee pe
        WHERE
            pe.pro_id = ?
        GROUP BY
            pe.pro_id,
            pe.pro_name,
            pe.emp_id,
            pe.emp_name,
            pe.progress

            `;
    db.query(getProjectPercentage, [pro_id], (proErr, proResult) => {
      if (proErr) {
        console.error("Error :", proErr);
        res
          .status(500)
          .json({ proErr: "Project Completion Percentage is not fetched" });
      }
      // console.log("Result :", proResult);
      res.json(proResult);
    });
  });

  router.get("/singleProjectProgress", (req, res) => {
    const pro_id = req.query.pro_id;
    const getProgress =
      " SELECT  pro_id,pro_name,LEAST(SUM(progress) / (COUNT(emp_id) * 100), 1) * 100 AS overall_completion_percentage FROM project_employee WHERE pro_id = ? GROUP BY pro_id, pro_name";
    db.query(getProgress, [pro_id], (progErr, proResult) => {
      if (progErr) {
        console.error("Error :", progErr);
        res
          .status(500)
          .json({ progErr: "Error Project Progress is not fetching" });
      }
      // console.log("Result :", proResult);
      res.json(proResult);
    });
  });

  router.get("/ProModuleProg", (req, res) => {
    const pro_id = req.query.pro_id;
    const getModuleProg = `
    SELECT 
    pro_id,
    module_name,
    SUM(progress) / (COUNT(emp_id) * 100) * 100 AS module_completion_percentage
    FROM module_employee
    WHERE pro_id = ?
    GROUP BY pro_id, module_name
    `;

    db.query(getModuleProg,[pro_id],(modProErr,modProResult) =>{
      if(modProErr){
        console.error("Error :",modProErr);
        res.status(500).json({modProErr:"Error Module Progress is not fetched"})
      }
      // console.log("Result :",modProResult);
      res.json(modProResult)
    })
  });


  router.get('/submoduleprog',(req,res) =>{
    const pro_id = req.query.pro_id;
    const getSubModuleProg = `
    SELECT 
    pro_id,
    pro_name,
    module_name,
    sub_module_name,
    SUM(progress) / (COUNT(emp_name) * 100) * 100 AS progress
    FROM sub_module_employee
    WHERE pro_id =?
    GROUP BY pro_id,pro_name, module_name, sub_module_name


    `;
    db.query(getSubModuleProg,[pro_id],(subModErr,subModResult) =>{
      if(subModErr){
        console.error("Error :",subModErr)
        res.status(500).json({subModErr:"Error Sub Module Data is not fetching"})
      }
      // console.log(subModResult);
      res.json(subModResult)
    })
  })


  router.get('/taskProg',(req,res) =>{
    const pro_id = req.query.pro_id;
    const getTaskProg = `
    SELECT 
    pro_id,
    pro_name,
    module_name,
    sub_module_name,
    task_name,
    SUM(progress) / (COUNT(emp_name) * 100) * 100 AS progress
    FROM task_employee
    WHERE pro_id = ?
    GROUP BY pro_id, pro_name, module_name, sub_module_name, task_name

    `;
    db.query(getTaskProg,[pro_id],(taskErr,taskResult) =>{
      if(taskErr){
        console.error("Error :",taskErr)
        res.status(500).json({taskErr:"Error Task progress is not fetching"});
      }
      // console.log("Result :",taskResult);
      res.json(taskResult)
    })
  })

  return router;
};
