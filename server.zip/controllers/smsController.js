const express = require('express');
const router = express.Router();
const unirest = require('unirest');

module.exports = (db) => {

  
  router.post('/send-message', (req, res) => {
    const { message, numbers } = req.body;
    const apiKey = 'vJtThOUhD2WudCuGYYyfoR8NJmXLb5NQvVvj6OiX1HuRZ6QrwS7sfPuKLsRr'; // Replace with your Fast2SMS API Key

    const request = unirest('GET', 'https://www.fast2sms.com/dev/bulkV2');
    request.query({
      authorization: apiKey,
      message: message,
      language: 'english',
      route: 'q',
      numbers: numbers,
    });

    

    request.end((response) => {
      if (response.error) {
        console.error('Error sending message:', response.error);
        res.status(500).json({ success: false, message: 'Failed to send message' });
      } else {
        console.log('Message sent successfully:', response.body);
        res.json({ success: true, message: 'Message sent successfully' });
      }
    });
  });

  return router;
};
