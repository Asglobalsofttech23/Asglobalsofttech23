const express = require('express');
const router = express.Router();
const moment = require('moment');

module.exports = (db) =>{

  

  router.post("/postSubmodule", (req, res) => {
    const {
      cust_id,
      pro_id,
      pro_name,
      pro_module_id,
      module_name,
      sub_module_name,
      sub_module_desc,
      start_date,
      end_date,
      selectedEmployee,
    } = req.body;
  
    const currentDate = moment().format("YYYY-MM-DD HH:mm:ss");
    const insertSubModule = `
      INSERT INTO sub_module(pro_module_id, pro_id, pro_name, module_name, sub_module_name, sub_module_desc, start_date, end_date, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    db.query(
      insertSubModule,
      [pro_module_id, pro_id, pro_name, module_name, sub_module_name, sub_module_desc, start_date, end_date, currentDate],
      (insertSubModError, insertSubModResult) => {
        if (insertSubModError) {
          console.error("Error :", insertSubModError);
          return res.status(500).json({ insertSubModError: "Error adding submodule data" });
        }
  
        const sub_mod_id = insertSubModResult.insertId;
        const allocation_date = currentDate;
  
        // Using Promise.all to handle multiple async queries
        Promise.all(selectedEmployee.map(empId =>
          new Promise((resolve, reject) => {
            const getEmployeName = "SELECT * FROM module_employee WHERE emp_id = ?";
            db.query(getEmployeName, [empId], (getEmpError, getEmpResult) => {
              if (getEmpError) {
                console.error("Error :", getEmpError);
                reject({ getEmpError: "Error fetching employee data" });
              } else {
                const emp_name = getEmpResult[0].emp_name;
                const insertSubmodEmp = `
                  INSERT INTO sub_module_employee (pro_id, pro_module_id, sub_mod_id, emp_id, pro_name, module_name, sub_module_name, emp_name, allocation_date, created_at)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `;
                db.query(
                  insertSubmodEmp,
                  [pro_id, pro_module_id, sub_mod_id, empId, pro_name, module_name, sub_module_name, emp_name, allocation_date, currentDate],
                  (insEmpError, insEmpResult) => {
                    if (insEmpError) {
                      console.error("ERROR :", insEmpError);
                      reject({ insEmpError: "Error adding employee submodule data" });
                    } else {
                      resolve(insEmpResult);
                    }
                  }
                );
              }
            });
          })
        ))
          .then(() => {
            res.status(200).json({ message: "Submodule Employee data added successfully" });
          })
          .catch(error => {
            res.status(500).json(error);
          });
      }
    );
  });
  


      router.get('/getSubModuleData',(req,res) =>{
        const getSubModuleData = "select * from sub_module inner join sub_module_employee on sub_module.sub_mod_id = sub_module_employee.sub_mod_id";
        db.query(getSubModuleData,(getSuberr,getSubResult) =>{
            if(getSuberr){
                console.error("Error :",getSuberr);
                res.status(500).json({getSuberr:"Error Sub Module is Not Fetching"})
            }
            else if (getSubResult.length ==0){
                res.status(404).json({Message:"Sub Module Data is Not Found"})
            }
            else{
                res.json(getSubResult);
            }
        })
      })


      router.get('/getSubModuledata/:sub_mod_id',(req,res) =>{
        const sub_mod_id = req.params.sub_mod_id;
        const getSbuModuleData = "select * from sub_module where sub_mod_id=?"
        db.query(getSbuModuleData,[sub_mod_id],(getSubModErr,getSubModRes)=>{
          if(getSubModErr){
            console.error("Error :",getSubModErr);
            res.status(500).json({getSubModErr:"Error Sub Module Data is not fetched"})
          }
          console.log(getSubModRes);
          res.json(getSubModRes)
        })
      })

      router.delete('/delete',(req,res) =>{
        const sub_mod_id = req.query.sub_mod_id;
        const dltData = "delete from sub_module where sub_mod_id =?";
        db.query(dltData,[sub_mod_id],(dltDataErr,dltDataRes) =>{
          if(dltDataErr){
            console.error("Error",dltDataErr);
            res.status(500).json({dltDataErr:"Sub Module Data is Not deleted"})
          }
          res.status(200).json({message:"Sub Module Data is Deleted"})
        })
      })

    return router
}