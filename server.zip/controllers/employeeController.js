const express = require('express');
const router = express.Router();
const app = express();
const multer = require('multer');
const moment = require('moment');
const mysql = require('mysql2/promise');
const fs = require('fs'); // Add this line

// // Configure multer storage
// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, 'uploads/');
//   },
//   filename: function (req, file, cb) {
//     const fileName = `${Date.now()}_${file.originalname}`;
//     cb(null, fileName);
//   },
// });


// const upload = multer({ storage: storage });

// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, 'uploads/');
//   },
//   filename: function (req, file, cb) {
//     const fileName = `${Date.now()}_${file.originalname}`;
//     cb(null, fileName);
//   },
// });

// const upload = multer({ storage: storage });

module.exports = (db) => {
  // db is the database connection passed from server.js
  const storage = multer.memoryStorage(); // Store the file in memory
  const upload = multer({ storage: storage });

  router.get('/', (req, res) => {
    const getEmployee = 
    ` SELECT emp.*, ro.role as emp_role, dept.dept_name
      FROM employee emp
      INNER JOIN role ro ON emp.role_id = ro.role_id
      INNER JOIN department dept ON emp.dept_id = dept.dept_id
    `;
    db.query(getEmployee, (error, results) => {
      if (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Error retrieving users' });
        return;
      }
      const concertedData = results.map((emp)=>({
        ...emp,
        emp_img : emp.emp_img.toString('base64'),
        hire_date: moment(emp.hire_date).format('YYYY-MM-DD'),
        created_at: moment(emp.created_at).format('YYYY-MM-DD HH:mm:ss'),
        updated_at: moment(emp.updated_at).format('YYYY-MM-DD HH:mm:ss')
      }))
      res.status(200).json(concertedData)
    });
  });
  



  

  

  // router.post('/', upload.single('emp_img'), (req, res) => {
  //   const { 
  //     role_id,
  //     dept_id,
  //     emp_name,
  //     emp_email,
  //     emp_mobile,
  //     hire_date,
  //    } = req.body;
  //   const currentTime = moment().format('YYYY-MM-DD HH:mm:ss'); // Get the current timestamp
  //   const emp_img = req.file ? req.file.filename : null;
  // const filePath = req.file ? `/uploads/${req.file.filename}` : null;

  // const insertEmployee = 'INSERT INTO employee (role_id, dept_id, emp_name, emp_email, emp_mobile, emp_img,hire_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
  // db.query(
  //   insertEmployee,
  //   [role_id, dept_id, emp_name, emp_email, emp_mobile, filePath,hire_date, currentTime],
  //   (error, results) => {
  //     if (error) {
  //       console.error('Error:', error);
  
  //       // Check if the error is due to a foreign key constraint
  //       if (error.code === 'ER_NO_REFERENCED_ROW_2') {
  //         res.status(400).json({ error: 'Invalid Role ID' });
  //         return;
  //       }
  
  //       res.status(500).json({ error: 'Error adding employee' });
  //       return;
  //     }
  
  //     // console.log('Added employee:', results);
  //     res.json({ message: 'Employee added successfully' });
  //   }
  // );
  // });
  

  router.post('/', upload.single('emp_img'), (req, res) => {
    const { 
      role_id,
      dept_id,
      emp_name,
      emp_email,
      emp_mobile,
      hire_date,
     } = req.body;
    const currentTime = moment().format('YYYY-MM-DD HH:mm:ss'); // Get the current timestamp
  //   const emp_img = req.file ? req.file.filename : null;
  // const filePath = req.file ? `/uploads/${req.file.filename}` : null;
  const emp_img = req.file.buffer;

  const insertEmployee = 'INSERT INTO employee (role_id, dept_id, emp_name, emp_email, emp_mobile, emp_img,hire_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
  db.query(
    insertEmployee,
    [role_id, dept_id, emp_name, emp_email, emp_mobile, emp_img,hire_date, currentTime],
    (error, results) => {
      if (error) {
        console.error('Error:', error);
  
        // Check if the error is due to a foreign key constraint
        if (error.code === 'ER_NO_REFERENCED_ROW_2') {
          res.status(400).json({ error: 'Invalid Role ID' });
          return;
        }
  
        res.status(500).json({ error: 'Error adding employee' });
        return;
      }
  
      // console.log('Added employee:', results);
      res.json({ message: 'Employee added successfully' });
    }
  );
  });
  






// router.put('/:emp_id', upload.single('emp_img'), (req, res) => {
//   const {
//       role_id,
//       dept_id,
//       emp_name,
//       emp_email,
//       emp_mobile,
//       hire_date,
//   } = req.body;
//   const currentTime = moment().format('YYYY-MM-DD HH:mm:ss'); // Get the current timestamp
//   const emp_id = req.params.emp_id; // Get the emp_id from the URL parameters

//   // Check if emp_img is provided
//   if (req.file) {
//       const emp_img = req.file.filename;
//       const filePath = `/uploads/${req.file.filename}`;

//       const updateEmployeeWithImg = 'UPDATE employee SET role_id=?, dept_id=?, emp_name=?, emp_email=?, emp_mobile=?, emp_img=?,hire_date=?, updated_at=? WHERE emp_id=?';
      
//       db.query(
//           updateEmployeeWithImg,
//           [role_id, dept_id, emp_name, emp_email, emp_mobile, filePath,hire_date, currentTime, emp_id],
//           (error, results) => {
//               if (error) {
//                   console.error('Error:', error);

//                   // Check if the error is due to a foreign key constraint
//                   if (error.code === 'ER_NO_REFERENCED_ROW_2') {
//                       res.status(400).json({ error: 'Invalid Role ID' });
//                       return;
//                   }

//                   res.status(500).json({ error: 'Error updating employee' });
//                   return;
//               }

//               // console.log('Updated employee with image:', results);
//               res.json({ message: 'Employee updated successfully' });
//           }
//       );
//   } else {
//       // If emp_img is not provided, update without it
//       const updateEmployeeWithoutImg = 'UPDATE employee SET role_id=?, dept_id=?, emp_name=?, emp_email=?, emp_mobile=?,hire_date=?, updated_at=? WHERE emp_id=?';

//       db.query(
//           updateEmployeeWithoutImg,
//           [role_id, dept_id, emp_name, emp_email, emp_mobile,hire_date, currentTime, emp_id],
//           (error, results) => {
//               if (error) {
//                   console.error('Error:', error);

//                   // Check if the error is due to a foreign key constraint
//                   if (error.code === 'ER_NO_REFERENCED_ROW_2') {
//                       res.status(400).json({ error: 'Invalid Role ID' });
//                       return;
//                   }

//                   res.status(500).json({ error: 'Error updating employee' });
//                   return;
//               }

//               // console.log('Updated employee without image:', results);
//               res.json({ message: 'Employee updated successfully' });
//           }
//       );
//   }
// });



router.put('/:emp_id', upload.single('emp_img'), (req, res) => {
  const {
      role_id,
      dept_id,
      emp_name,
      emp_email,
      emp_mobile,
      hire_date,
  } = req.body;
  const currentTime = moment().format('YYYY-MM-DD HH:mm:ss'); // Get the current timestamp
  const emp_id = req.params.emp_id; // Get the emp_id from the URL parameters

  // Check if emp_img is provided
  if (req.file) {
      // const emp_img = req.file.filename;
      // const filePath = `/uploads/${req.file.filename}`;
      const emp_img = req.file.buffer;

      const updateEmployeeWithImg = 'UPDATE employee SET role_id=?, dept_id=?, emp_name=?, emp_email=?, emp_mobile=?, emp_img=?,hire_date=?, updated_at=? WHERE emp_id=?';
      
      db.query(
          updateEmployeeWithImg,
          [role_id, dept_id, emp_name, emp_email, emp_mobile, emp_img,hire_date, currentTime, emp_id],
          (error, results) => {
              if (error) {
                  console.error('Error:', error);

                  // Check if the error is due to a foreign key constraint
                  if (error.code === 'ER_NO_REFERENCED_ROW_2') {
                      res.status(400).json({ error: 'Invalid Role ID' });
                      return;
                  }

                  res.status(500).json({ error: 'Error updating employee' });
                  return;
              }

              // console.log('Updated employee with image:', results);
              res.json({ message: 'Employee updated successfully' });
          }
      );
  } else {
      // If emp_img is not provided, update without it
      const updateEmployeeWithoutImg = 'UPDATE employee SET role_id=?, dept_id=?, emp_name=?, emp_email=?, emp_mobile=?,hire_date=?, updated_at=? WHERE emp_id=?';

      db.query(
          updateEmployeeWithoutImg,
          [role_id, dept_id, emp_name, emp_email, emp_mobile,hire_date, currentTime, emp_id],
          (error, results) => {
              if (error) {
                  console.error('Error:', error);

                  // Check if the error is due to a foreign key constraint
                  if (error.code === 'ER_NO_REFERENCED_ROW_2') {
                      res.status(400).json({ error: 'Invalid Role ID' });
                      return;
                  }

                  res.status(500).json({ error: 'Error updating employee' });
                  return;
              }

              // console.log('Updated employee without image:', results);
              res.json({ message: 'Employee updated successfully' });
          }
      );
  }
});








// Get Employee Image using emp_id
router.get('/getEmpDataByEmpID', (req, res) => {
  const emp_id = req.query.emp_id
  const getEmployee = "SELECT * FROM employee where emp_id = ?";
  db.query(getEmployee,[emp_id], (error, results) => {
    if (error) {
      console.error('Error:', error);
      res.status(500).json({ error: 'Error retrieving users' });
      return;
    }
    const convertImg = results.map((img)=>({
      ...img,
      emp_img : img.emp_img.toString('base64')
    }))
    res.json(convertImg);
  });
});















  router.delete('/:emp_id/delete', (req, res) => {
    const empId = req.params.emp_id;

    const deleteEmployeeQuery = 'DELETE FROM employee WHERE emp_id = ?';

    db.query(deleteEmployeeQuery, [empId], (err, results) => {
      if (err) {
        console.error('Error deleting employee:', err);
        res.status(500).json({ error: 'Error deleting employee' });
      } else {
        // console.log('Employee deleted:', results);
        res.status(200).json({ message: 'Employee deleted successfully' });
      }
    });
  });


  return router;
};



