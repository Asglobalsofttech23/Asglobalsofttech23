import { NavLink } from "react-router-dom";
import { FaBars, FaHome, FaLock, FaMoneyBill, FaUser } from "react-icons/fa";
import { MdMessage } from "react-icons/md";
import { BiAnalyse, BiSearch } from "react-icons/bi";
import { BiCog } from "react-icons/bi";
import { AiFillHeart, AiTwotoneFileExclamation } from "react-icons/ai";
import { BsCartCheck } from "react-icons/bs";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import SidebarMenu from "./SidebarMenu";
import './EmployeeSideBar.css'
import img from '../../../images/iconimg.jpg'
import axios from "axios";
import { RxDashboard } from "react-icons/rx";
import {FaUserTie,FaUserPlus } from "react-icons/fa6";
import { GoProjectSymlink} from "react-icons/go";
import { IoFilterSharp } from "react-icons/io5";
import config from "../../../config";
const routes = [
  // {
  //   path: "/",
  //   name: "Dashboard",
  //   icon: <FaHome className="react-icon"/>,
  // },
  // {
  //   path: "/users",
  //   name: "Users",
  //   icon: <FaUser className="react-icon"/>,
  // },
  {
    path: "/",
    name: "Dashboard",
    icon: <RxDashboard />,
  },
  {
    path: "/cust_table",
    name: "Customer Table",
    icon: <FaUserTie  className="react-icon"/>,
  },
  {
    path: "/emp_projects",
    name: "Projects",
    icon: <GoProjectSymlink  className="react-icon"/>,
  },
  {
    path: "/",
    name: "Follow Up",
    icon: <BiAnalyse className="react-icon"/>,
    subRoutes: [
      {
        path: "/customermaintenance",
        name: "Followed Customer ",
        icon: <FaUserPlus className="react-icon"/>,
      },
      {
        path: "/custreport",
        name: "Report",
        icon: <IoFilterSharp className="react-icon"/>,
      },
      // {
      //   path: "/settings/billing",
      //   name: "Billing",
      //   icon: <FaMoneyBill className="react-icon"/>,
      // },
    ],
  },
  // {
  //   path: "/order",
  //   name: "Order",
  //   icon: <BsCartCheck className="react-icon"/>,
  // },
  // {
  //   path: "/settings",
  //   name: "Settings",
  //   icon: <BiCog className="react-icon"/>,
  //   exact: true,
  //   subRoutes: [
  //     {
  //       path: "/settings/profile",
  //       name: "Profile ",
  //       icon: <FaUser className="react-icon"/>,
  //     },
  //     {
  //       path: "/settings/2fa",
  //       name: "2FA",
  //       icon: <FaLock className="react-icon"/>,
  //     },
  //     {
  //       path: "/settings/billing",
  //       name: "Billing",
  //       icon: <FaMoneyBill className="react-icon"/>,
  //     },
  //   ],
  // },
  // {
  //   path: "/saved",
  //   name: "Saved",
  //   icon: <AiFillHeart className="react-icon"/>,
  // },
];

const EmployeeSideBar = ({ children }) => {
  const emp_id = sessionStorage.getItem('emp_id')
  const [isOpen, setIsOpen] = useState(true);
  const toggle = () => setIsOpen(!isOpen);
  const inputAnimation = {
    hidden: {
      width: 0,
      padding: 0,
      transition: {
        duration: 0.2,
      },
    },
    show: {
      width: "140px",
      padding: "5px 15px",
      transition: {
        duration: 0.2,
      },
    },
  };

  const showAnimation = {
    hidden: {
      width: 0,
      opacity: 0,
      transition: {
        duration: 0.5,
      },
    },
    show: {
      opacity: 1,
      width: "auto",
      transition: {
        duration: 0.5,
      },
    },
  };

const [empImg,setEmpImg] = useState()
  useEffect(()=>{
    axios.get(`${config.apiUrl}/employees/getEmpDataByEmpID?emp_id=${emp_id}`)
    .then(response=>{
      setEmpImg(response.data[0].emp_img)
    })
  },[emp_id])


  return (
    <>
      <div className="main-containerr">
        <motion.div
          animate={{
            width: isOpen ? "240px" : "55px",

            transition: {
              duration: 0.5,
              type: "spring",
              damping: 10,
            },
          }}
          className={`sidebarr `}
        >
          <div className="top_sectionn">
          <AnimatePresence>
              {isOpen && (
                <motion.h1
                  variants={showAnimation}
                  initial="hidden"
                  animate="show"
                  exit="hidden"
                  className="logoo mt-2"
                  style={{ fontWeight: 'bold' }}
                >
                 
                </motion.h1>
              )}
            </AnimatePresence>

            <div className={isOpen ? "img-container-open" : "img-container-closed"}>
            
            <img src={`data:image/jpeg;base64,${empImg}`} alt="Your Company Logo" className="rounded-icon" />
          </div>

          <div className={`barss ${isOpen ? '' : 'collapsed'}`}>
  <FaBars onClick={toggle} size={30} />
</div>

          </div>
          {/* <div className="search">
            <div className="search_icon">
              <BiSearch />
            </div>
            <AnimatePresence>
              {isOpen && (
                <motion.input
                  initial="hidden"
                  animate="show"
                  exit="hidden"
                  variants={inputAnimation}
                  type="text"
                  placeholder="Search"
                />
              )}
            </AnimatePresence>
          </div> */}
          <section className="routes">
            {routes.map((route, index) => {
              if (route.subRoutes) {
                return (
                  <SidebarMenu
                    setIsOpen={setIsOpen}
                    route={route}
                    showAnimation={showAnimation}
                    isOpen={isOpen}
                  />
                );
              }

              return (
                <NavLink
                  to={route.path}
                  key={index}
                  className="link"
                  activeClassName="active"
                >
                  <div className="icon">{route.icon}</div>
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        variants={showAnimation}
                        initial="hidden"
                        animate="show"
                        exit="hidden"
                        className="link_text"
                      >
                        {route.name}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </NavLink>
              );
            })}
          </section>
        </motion.div>

        <div className="mainn">
        <main>{children}</main>
        </div>
      </div>
    </>
  );
};

export default EmployeeSideBar;