import React, { useState } from 'react'
import EmployeeTopBar from '../Employee TopNav/EmployeeTopBar'
import EmployeeSideBar from '../SideBar/EmployeeSideBar'
import CustomerReport from './CustomerReport'
import CustomerReportTable from './CustomerReportTable'

function CustomerReportRouter() {
  const [reportData, setReportData] = useState([]);

  const updateReportData = (data) => {
    setReportData(data);
  };

  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchInputChange = (query) => {
    setSearchQuery(query);
  };

  return (
    <div style={{display:'flex',overflow:'hidden'}}>

     
      <EmployeeSideBar />
      
      
     
      <div style={{overflowY:'hidden',flexGrow:'1',marginLeft:'-20px'}}>
        <EmployeeTopBar onSearchInputChange={handleSearchInputChange}/>
        <div style={{marginLeft:'20px',marginRight:'20px'}}>
        <CustomerReport  setReportData={updateReportData} searchQuery={searchQuery}/>
          
            <CustomerReportTable reportData={reportData} searchQuery={searchQuery}/>
        
        </div>
        </div>
        
      </div>
     
      
     
  
  )
}

export default CustomerReportRouter
