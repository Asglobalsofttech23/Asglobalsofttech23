import { Button, Grid, MenuItem, TextField } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import config from "../../../config";

const districtData = [
  "Ariyalur",
  "Chengalpattu",
  "Chennai",
  "Coimbatore",
  "Cuddalore",
  "Dharmapuri",
  "Dindigul",
  "Erode",
  "Kallakurichi",
  "Kanchipuram",
  "Kanyakumari",
  "Karur",
  "Krishnagiri",
  "Madurai",
  "Nagapattinam",
  "Namakkal",
  "Nilgiris",
  "Perambalur",
  "Pudukkottai",
  "Ramanathapuram",
  "Ranipet",
  "Salem",
  "Sivaganga",
  "Tenkasi",
  "Thanjavur",
  "Theni",
  "Thoothukudi",
  "Tiruchirappalli",
  "Tirunelveli",
  "Tirupathur",
  "Tiruppur",
  "Tiruvallur",
  "Tiruvannamalai",
  "Tiruvarur",
  "Vellore",
  "Viluppuram",
  "Virudhunagar",
];

function CustomerReport({ setReportData, searchQuery }) {
  useEffect(() => {
    const highlightColor = "black";
    const unhighlightColor = "initial";
    const highlightBackground = "yellow";
    const unhighlightBackground = "white";

    const tableCells = document.querySelectorAll("td"); // Select all table cells or specific cells where you want to apply the highlight

    tableCells.forEach((cell) => {
      const cellText = cell.textContent;
      const searchQueryLC = searchQuery.toLowerCase();

      // Split the text content of the cell into parts based on the search query
      const parts = cellText.split(new RegExp(`(${searchQueryLC})`, "gi"));

      // Recreate the inner HTML of the cell to highlight the matched parts
      cell.innerHTML = parts
        .map((part) => {
          if (part.toLowerCase() === searchQueryLC) {
            return `<span style="color: ${highlightColor}; background-color: ${highlightBackground}">${part}</span>`;
          } else {
            return part;
          }
        })
        .join("");
    });
  }, [searchQuery]);

  const [selectedcategory, setSelectedCategory] = useState("");
  const [f_date, setF_date] = useState("");
  const [to_date, setTo_date] = useState("");
  const [selectCategory, setSelectCategory] = useState([]);
  const [dist, setDist] = useState();
  const [city, setCity] = useState();

  const emp_id = sessionStorage.getItem("emp_id");

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/custMain/getCustomerByEmpID?emp_id=${emp_id}`)
      .then((response) => {
        setSelectCategory(response.data);
        console.log("Daaata:", response.data);
      })
      .catch((error) => {
        console.error("Category is not fetching");
      });
  }, [emp_id]);

  const handleReport = (e) => {
    e.preventDefault();
    axios
      .get(`${config.apiUrl}/custMain/filter`, {
        params: {
          category: selectedcategory,
          fromDate: f_date,
          toDate: to_date,
          dist: dist,
          city: city,
        },
      })
      .then((response) => {
        setReportData(response.data);
      })
      .catch((error) => {
        console.error("Error Report is not fetched ");
      });
  };

  return (
    <>
      <div>
        <h1 className="text-center">Report</h1>
        <div>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                select
                fullWidth
                label="Select Category"
                name="selectedcategory"
                onChange={(e) => setSelectedCategory(e.target.value)}
                value={selectedcategory}
              >
                {/* {selectCategory.map((category, index) => (
              <MenuItem key={index} value={4}>
                {category.category}
              </MenuItem>
            ))} */}
                <MenuItem value="1">1st Priority</MenuItem>
                <MenuItem value="2">2nd Priority</MenuItem>
                <MenuItem value="3">3rd Priority</MenuItem>
                <MenuItem value="4">4th Priority</MenuItem>
              </TextField>
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="From Date"
                name="f_name"
                type="date"
                onChange={(e) => setF_date(e.target.value)}
                value={f_date}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="To Date"
                name="to_date"
                type="date"
                onChange={(e) => setTo_date(e.target.value)}
                value={to_date}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                select
                name="dist"
                label="Select District"
                onChange={(e) => setDist(e.target.value)}
                value={dist}
              >
                {districtData.map((dist, index) => (
                  <MenuItem key={index} value={dist}>
                    {dist}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                select
                name="city"
                label="Select City"
                onChange={(e) => setCity(e.target.value)}
                value={city}
              >
                {selectCategory.map((city, index) => (
                  <MenuItem key={index} value={city.city}>
                    {city.city}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
          </Grid>
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            marginTop: "10px",
          }}
        >
          <Button variant="contained" onClick={handleReport}>
            Generate Report
          </Button>
        </div>
      </div>
    </>
  );
}

export default CustomerReport;
