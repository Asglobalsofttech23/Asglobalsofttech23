
import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Button,
  Checkbox,
  Menu,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import * as XLSX from "xlsx";
import EditIcon from "@mui/icons-material/Edit";
import ReactPaginate from "react-paginate";
import config from "../../../config";
function ProjectTable({searchQuery}) {


  useEffect(() => {
    const highlightColor = 'black';
    const unhighlightColor = 'initial';
    const highlightBackground = 'yellow';
    const unhighlightBackground = 'white';
  
    const tableCells = document.querySelectorAll('td'); // Select all table cells or specific cells where you want to apply the highlight
  
    tableCells.forEach((cell) => {
      const cellText = cell.textContent;
      const searchQueryLC = searchQuery.toLowerCase();
      
      // Split the text content of the cell into parts based on the search query
      const parts = cellText.split(new RegExp(`(${searchQueryLC})`, 'gi'));
      
      // Recreate the inner HTML of the cell to highlight the matched parts
      cell.innerHTML = parts.map(part => {
        if (part.toLowerCase() === searchQueryLC) {
          return `<span style="color: ${highlightColor}; background-color: ${highlightBackground}">${part}</span>`;
        } else {
          return part;
        }
      }).join('');
    });
  }, [searchQuery]);


  const empId = sessionStorage.getItem("emp_id");

  const [projects, setProjects] = useState([]);

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/project/getProjectEmployeeByEmpId?emp_id=${empId}`)
      .then((res) => {
        setProjects(res.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  });

  const [itemPerPage, setItemPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  const handleItemPerPageChange = (e) => {
    const newItemPerPage = parseInt(e.target.value, 10);

    if (newItemPerPage === 0) {
      setItemPerPage(projects.length);
      setCurrentPage(1);
    } else {
      setItemPerPage(newItemPerPage);
      setCurrentPage(1);
    }
  };

  const indexOfLastItem = currentPage * itemPerPage;
  const indexOfFirstItem = indexOfLastItem - itemPerPage;
  const currentItem = projects.slice(indexOfFirstItem, indexOfLastItem);

  const [searchedVal, setSearchedVal] = useState("");

  const filterData = (pro) => {
    const searchValue = searchedVal.toLocaleLowerCase();
    return Object.values(pro).some(
      (value) => value && value.toString().toLowerCase().includes(searchValue)
    );
  };

  const [selectedProject, setSelectedProject] = useState([]);
  const [selectAll, setSelectAll] = useState(false);

  const handleCheckboxChange = (pro) => {
    const selectedProjectIds = [...selectedProject];
    if (selectedProjectIds.includes(pro)) {
      const index = selectedProjectIds.indexOf(pro);
      selectedProjectIds.splice(index, 1);
    } else {
      selectedProjectIds.push(pro);
    }
    setSelectedProject(selectedProjectIds);
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedProject([]);
    } else {
      const allproIds = projects.map((pro) => pro.pro_emp_id);
      setSelectedProject(allproIds);
    }
    setSelectAll(!selectAll);
  };

  const [anchorEl, setAnchorEl] = useState(null);

  const handleExport = (format) => {
    if (projects.length === 0) {
      console.log("No Project selected for export");
      return;
    }

    switch (format) {
      case "CSV":
        exportToCSV();
        break;
      case "Excel":
        exportToExcel();
        break;
      case "JSON":
        exportToJSON();
        break;
      default:
        break;
    }
  };

  const exportToCSV = () => {
    if (projects.length === 0) {
      console.log("No Projects selected for export");
      return;
    }

    const selectedProjectData = projects.filter((pro) =>
      selectedProject.includes(pro.pro_emp_id)
    );

    // Create CSV content
    const header = Object.keys(selectedProjectData[0]).join(",");
    const csv = [
      header,
      ...selectedProjectData.map((pro) =>
        Object.values(pro)
          .map((value) => `"${value}"`)
          .join(",")
      ),
    ].join("\n");

    // Create Blob for CSV file
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);

    // Download CSV file
    const a = document.createElement("a");
    a.href = url;
    a.download = "project.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportToExcel = () => {
    const selectedProjectData = projects.filter((pro) =>
      selectedProject.includes(pro.pro_emp_id)
    );
    const worksheet = XLSX.utils.json_to_sheet(selectedProjectData);

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Projects");
    XLSX.writeFile(workbook, "Project.xlsx");
  };

  const exportToJSON = () => {
    const selectedProjectData = projects.filter((pro) =>
      selectedProject.includes(pro.pro_emp_id)
    );

    const jsonData = JSON.stringify(selectedProjectData, null, 2);
    const blob = new Blob([jsonData], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "Project.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const [isEditing, setIsEditing] = useState(null); // State to manage editing mode
  const [progressValue, setProgressValue] = useState("");
  const [prevProgress, setPrevProgress] = useState("");
  const [error, setError] = useState("");

  const handleEditClick = (index, progress) => {
    setIsEditing(index);
    setPrevProgress(progress);
    setProgressValue(progress);
    setError("");
  };

  const handleUpdate = (proEmpId) => {
    if (!progressValue || isNaN(progressValue)) {
      setError("Progress value Required");
      return;
    }
  
    if (parseInt(progressValue) > 100) {
      setError("Maximum progress value is 100");
      return;
    }
  
    axios
      .put(`${config.apiUrl}/project/updateprogress/${proEmpId}`, {progress: progressValue,})
      .then((response) => {
        console.log("Progress Value Updated Successfully", response.data);
        setIsEditing(null);
        setError("");
      })
      .catch((error) => {
        console.error("Project Data Not Updated", error);
      });
  };
  

  return (
    <div style={{minHeight:'590px'}}>
      <div style={{marginLeft:'100px'}}>
      <div className="row mt-5">
        <div className="col-lg-4 col-md-3 col-sm-12">
          <Button
            style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}
            onClick={(e) => setAnchorEl(e.currentTarget)}
          >
            Export data
          </Button>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={() => setAnchorEl(null)}
          >
            <MenuItem onClick={() => handleExport("CSV")}>
              Export as CSV
            </MenuItem>
            <MenuItem onClick={() => handleExport("Excel")}>
              Export as Excel
            </MenuItem>
            <MenuItem onClick={() => handleExport("JSON")}>
              Export as JSON
            </MenuItem>
          </Menu>
        </div>
        <div className="col-lg-4 col-md-3 col-sm-12">
          <TextField
            label="Search"
            onChange={(e) => setSearchedVal(e.target.value)}
          />
        </div>
        <div className="col-lg-3 col-md-3 col-sm-12">
          <select
            value={itemPerPage}
            onChange={handleItemPerPageChange}
            style={{
              padding: "5px 10px",
              margin: "0 5px",
              border: "1px solid #007bff",
              borderRadius: "4px",
              cursor: "pointer",
              backgroundColor: "#fff",
              color: "#007bff",
              textDecoration: "none",
              transition: "background-color 0.3s, color 0.3s",
            }}
          >
            <option value="5">5 Per Page</option>
            <option value="10">10 Per Page</option>
            <option value="15">15 Per Page</option>
            <option value="0">All Per Page</option>
          </select>
        </div>
        {/* <div className="col-lg-4 col-md-3 col-sm-3">
          <Button
            //  onClick={addNewEmp}
            style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}
          >
            Add New Employee
          </Button>
        </div> */}
      </div>
      </div>
      {projects.length > 0 ? (
        <>
          <TableContainer
            component={Paper}
            className="mt-4"
            style={{
              overflowX: "auto",
              maxWidth: "100%",
              width: "100%",
              display: "block",
            }}
          >
            <Table>
              <TableHead style={{ backgroundColor: "#1B9C85" }}>
                <TableRow>
                  <TableCell>
                    <Checkbox checked={selectAll} onChange={handleSelectAll} />
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    S.No
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Name
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Mobile
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Email
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Project Name
                  </TableCell>
                  {/* <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Project Description
                  </TableCell> */}
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Start Date
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    End Date
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Employee Name
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Progress
                  </TableCell>
                  
                </TableRow>
              </TableHead>
              <TableBody>
                {currentItem.filter(filterData).map((pro, index) => (
                  <>
                    <TableRow key={index + 1}>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        <Checkbox
                          checked={selectedProject.includes(pro.pro_emp_id)}
                          onChange={() => handleCheckboxChange(pro.pro_emp_id)}
                        ></Checkbox>
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {index + 1}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {pro.cust_name}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {pro.cust_mobile}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {pro.cust_email}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {pro.pro_name}
                      </TableCell>
                      {/* <TableCell style={{ border: "1px solid #ddd" }}>
                        {pro.pro_desc}
                      </TableCell> */}
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {pro.start_date}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {pro.end_date}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {pro.emp_name}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {isEditing === index ? (
                          // If in edit mode, show text field and update button
                          <>
                            <TextField
                              type="number"
                              value={progressValue}
                              onChange={(e) => {
                                setProgressValue(e.target.value);
                                setError("");
                              }}
                              error={Boolean(error)}
                              helperText={error || ""}
                            />
                            <Button
                              onClick={() => handleUpdate(pro.pro_emp_id)}
                            >
                              Update
                            </Button>
                          </>
                        ) : (
                          // Otherwise, display progress value and edit icon
                          <>
                            {pro.progress}
                            <EditIcon
                            style={{color:'rgb(25,118,210)'}}
                              onClick={() =>
                                handleEditClick(index, pro.progress)
                              }
                            />
                          </>
                        )}
                      </TableCell>
                    </TableRow>
                  </>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <nav aria-label="Page navigation" className="text-center">
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
          <ReactPaginate
            previousLabel={
              <span
                style={{
                  padding: '5px 10px',
                  margin: '0 5px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: '#152445',
                  color: 'white',
                  textDecoration: 'underline',
                  textDecorationColor: '#152445',
                }}
              >
                Previous
              </span>
            }
            nextLabel={
              <span
                style={{
                  padding: '5px 10px',
                  margin: '0 5px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: '#152445',
                  color: 'white',
                  textDecoration: 'underline',
                  textDecorationColor: '#152445',
                }}
              >
                Next
              </span>
            }
            breakLabel={
              <span
                style={{
                  padding: '5px 10px',
                  margin: '0 5px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: '#fff',
                  color: '#333',
                  textDecoration: 'none',
                }}
              >
                ...
              </span>
            }
            pageCount={Math.ceil(projects.filter(filterData).length / itemPerPage)} // Use 'customers' instead of 'filteredCustomers'
            marginPagesDisplayed={2}
            pageRangeDisplayed={4}
            onPageChange={({ selected }) => setCurrentPage(selected + 1)}
            containerClassName={"pagination justify-content-center"}
            subContainerClassName={"pages pagination"}
            activeClassName={"active"}
          />
        </div>
      </nav>
        </>
      ) : (
        <>
          <p>Project Data is Not Available</p>
        </>
      )}
    </div>
  );
}

export default ProjectTable;
