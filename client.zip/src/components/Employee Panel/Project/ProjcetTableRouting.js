import React, { useState } from 'react'
import EmployeeSideBar from '../SideBar/EmployeeSideBar'
import EmployeeTopBar from '../Employee TopNav/EmployeeTopBar'
import ProjectTable from './ProjectTable'

function ProjcetTableRouting() {

  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchInputChange = (query) => {
    setSearchQuery(query);
  };

  return (
      <div style={{display:'flex',overflow:'hidden'}}>
<EmployeeSideBar/>
      
     
      
      
     
      <div style={{overflowY:'hidden',flexGrow:'1',marginLeft:'-20px'}}>
        <EmployeeTopBar onSearchInputChange={handleSearchInputChange}/>
        <div style={{marginRight:'20px',marginLeft:'20px'}}>
          <ProjectTable searchQuery={searchQuery}/>
        </div>
        </div>
    </div>
  )
}

export default ProjcetTableRouting
