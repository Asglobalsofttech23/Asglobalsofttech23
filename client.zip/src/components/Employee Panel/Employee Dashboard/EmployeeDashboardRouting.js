import React, { useEffect, useState } from 'react';
import EmployeeTopBar from '../Employee TopNav/EmployeeTopBar';
import EmployeeSideBar from '../SideBar/EmployeeSideBar';
import EmpDashboard from './EmpDashboard';
import axios from 'axios';
import config from '../../../config';
function EmployeeDashboardRouting() {
  const emp_id = sessionStorage.getItem('emp_id');
  const [reminder, setReminder] = useState([]);
  const [consoleData, setConsoleData] = useState([]);

  useEffect(() => {axios.get(`${config.apiUrl}/custMain/reminder?emp_id=${emp_id}`)
      .then(response => {
        setReminder(response.data);
        console.log('Reminder Data is:', response.data);

        // Check reminders for each customer
        const consoleLogData = checkReminder(response.data);
        setConsoleData(consoleLogData);
      })
      .catch(error => {
        console.error('Error fetching reminder data:', error);
      });
  }, []);

  const calculateReminderDate = (category, cust_avail_date, cur_follow_up_date) => {
    const today = new Date();

    let reminderDays;
    if (category === 1) {
      reminderDays = 15;
    } else if (category === 2) {
      reminderDays = 30;
    } else if (category === 3) {
      reminderDays = 45;
    } else if (category === 4) {
      reminderDays = 60;
    } else {
      // Set a default reminder days here if needed
      reminderDays = 30;
    }

    const dateToCheck = (cust_avail_date !== 'Invalid date') ? new Date(cust_avail_date) : new Date(cur_follow_up_date);
    const reminderDate = new Date(dateToCheck.getTime() + reminderDays * 24 * 60 * 60 * 1000);

    return reminderDate.toLocaleDateString();
  };

  const checkReminder = (data) => {
    const consoleData = [];
    data.forEach((item) => {
      if (item.category >= 1 && item.category <= 4) {
        if (item.cust_available === 'yes' && item.cus_avail_date !== 'Invalid date') {
          const reminderDate = calculateReminderDate(item.category, item.cus_avail_date, item.cur_follow_up_date);
          consoleData.push(`reminder for ${item.cust_name} on ${reminderDate}`);
        } else if (item.cust_available === 'no' && item.cur_follow_up_date !== 'Invalid date') {
          const reminderDate = calculateReminderDate(item.category, item.cus_avail_date, item.cur_follow_up_date);
          consoleData.push(`reminder for ${item.cust_name} on ${reminderDate}`);
        }
      }
    });
    return consoleData;
  };



  useEffect(() => {
    if (consoleData && consoleData.length > 0) {
      const sessionData = JSON.stringify(consoleData);
      sessionStorage.setItem('consoleData', sessionData);
      console.log('Session data set:', consoleData);
    }
  }, [consoleData]);


  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchInputChange = (query) => {
    setSearchQuery(query);
  };


  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <EmployeeSideBar />
      <div style={{ overflowY: 'hidden', flexGrow: '1', marginLeft: '-20px' }}>
        <EmployeeTopBar consoleData={consoleData} onSearchInputChange={handleSearchInputChange} />
        <div style={{ marginLeft: '20px', marginRight: '20px' }}>
          <EmpDashboard searchQuery={searchQuery}/>
        </div>
      </div>
    </div>
  );
}

export default EmployeeDashboardRouting;
