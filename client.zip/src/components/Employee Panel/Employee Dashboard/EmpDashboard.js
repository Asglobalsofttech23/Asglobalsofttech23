import { Card, CardContent, Grid, Paper, Typography } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import Entry from "../../Admin Panel/Attendance/Entry";
import "./EmployeeDashboard.css";
import { FaUserLarge} from "react-icons/fa6";
import { AiOutlineLogin } from "react-icons/ai";
import { GoProjectSymlink } from "react-icons/go";
import { RiLogoutCircleRLine } from "react-icons/ri";
import Exit from "../../Admin Panel/Attendance/Exit";
import config from "../../../config";
function EmpDashboard({searchQuery}) {

  useEffect(() => {
    const highlightColor = 'black';
    const unhighlightColor = 'initial';
    const highlightBackground = 'yellow';
    const unhighlightBackground = 'white';
  
    const tableCells = document.querySelectorAll('td'); // Select all table cells or specific cells where you want to apply the highlight
  
    tableCells.forEach((cell) => {
      const cellText = cell.textContent;
      const searchQueryLC = searchQuery.toLowerCase();
      
      // Split the text content of the cell into parts based on the search query
      const parts = cellText.split(new RegExp(`(${searchQueryLC})`, 'gi'));
      
      // Recreate the inner HTML of the cell to highlight the matched parts
      cell.innerHTML = parts.map(part => {
        if (part.toLowerCase() === searchQueryLC) {
          return `<span style="color: ${highlightColor}; background-color: ${highlightBackground}">${part}</span>`;
        } else {
          return part;
        }
      }).join('');
    });
  }, [searchQuery]);


  const emp_id = sessionStorage.getItem("emp_id");
  const [customerCount, setCustomerCount] = useState(0);
  useEffect(() => {
    axios
      .get(`${config.apiUrl}/customers/getCustomerByEmpID?emp_id=${emp_id}`)
      .then((response) => {
        setCustomerCount(response.data.length);
      })
      .catch((error)=>{
        console.log("Error :",error)
      })
  });

 
 

  return (
    <div style={{marginTop:'20px'}}>
      <div>
        <Grid container spacing={3}>
          <Grid item xs={3}>
            <Card component={Paper} className="card">
              <a class="card1" href="#">
                <div className="row">
                  <div className="col-8">
                    <CardContent>
                      <Typography
                        variant="h5"
                        component="div"
                        className="text-center card-content"
                        style={{ fontWeight: "bold" }}
                      >
                        Customer
                      </Typography>
                      <Typography
                        className="text-center "
                        style={{ fontWeight: "bold", fontSize: "30px" }}
                      >
                        {customerCount}
                      </Typography>
                    </CardContent>
                  </div>
                  <div className="col-3">
                  <div style={{marginRight:'10px',marginTop:'20px'}}>
                    <FaUserLarge size={60} />
                    </div>
                  </div>
                </div>
              </a>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </Card>
          </Grid>
          <Grid item xs={3}>
            <Card component={Paper} className="card">
              <a class="card1" href="#">
                <div className="row">
                  <div className="col-8">
                    <CardContent>
                      <Typography
                        variant="h5"
                        component="div"
                        className="text-center card-content"
                        style={{ fontWeight: "bold" }}
                      >
                        Projects
                      </Typography>
                      <Typography
                        className="text-center card-content"
                        style={{ fontWeight: "bold", fontSize: "30px" }}
                      >
                        {customerCount}
                      </Typography>
                    </CardContent>
                  </div>
                  <div className="col-4 mt-3">
                  <div style={{marginRight:'10px',marginTop:'20px'}}>
                    <GoProjectSymlink size={70} />
                    </div>
                  </div>
                </div>
              </a>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </Card>
          </Grid>
          <Grid item xs={3}>
            <Card component={Paper} className="card">
              <a class="card1" href="#">
                <div className="row">
                  <div className="col-8">
                  <CardContent>
                    <Typography variant="h6"
                     component="div"
                     className="text-center card-content"
                     style={{ fontWeight: "bold" }}
                     >
                      Clock In
                    </Typography>
                    <Typography
                      className="text-center card-content"
                      style={{ fontWeight: "bold", fontSize: "30px" }}
                    >
                      <Entry />
                    </Typography>
                  </CardContent>
                  </div>
                  <div className="col-4">
                  <div style={{marginRight:'10px',marginTop:'20px'}}>
                  <AiOutlineLogin size={70}/>
                  </div>
                  </div>
                </div>
              </a>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </Card>
          </Grid>
          <Grid item xs={3}>
            <Card component={Paper} className="card">
              <a class="card1" href="#">
                <div className="row">
                 <div className="col-8">
                 <CardContent>
                    <Typography variant="h6" component="div"
                     className="text-center card-content"
                     style={{fontWeight:'bold'}}
                     >
                      Clock Out
                    </Typography>
                    <Typography
                      className="text-center "
                      style={{ fontWeight: "bold", fontSize: "30px" }}
                    >
                      <Exit/>
                    </Typography>
                  </CardContent>
                 </div>
                 <div className="col-4">
                 <div style={{marginRight:'10px',marginTop:'20px'}}>
                 <RiLogoutCircleRLine size={70}/>
                 </div>
                 </div>
                </div>
              </a>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </Card>
          </Grid>
        </Grid>
      </div>
    </div>
  );
}

export default EmpDashboard;
