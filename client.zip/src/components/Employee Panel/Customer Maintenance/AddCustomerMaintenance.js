import { Button, Dialog, DialogActions, DialogContent, Grid, MenuItem, TextField } from '@mui/material'
import axios from 'axios'
import moment from 'moment'
import React, { useEffect, useState } from 'react'
import { toast } from 'react-toastify';
import config from '../../../config';
function AddCustomerMaintenance({ emp_id,onClose }) {
  const [formData, setFormData] = useState({
    cust_id: "",
    follow_emp_id: "",
    follow_emp_name: "",
    cust_name: "",
    cust_email: "",
    bus_name: "",
    bus_category: "",
    category: "",
    notes: "",
    cur_date: moment().format("YYYY-MM-DD"),
    cust_available:"",
    cust_avail_date: "",
  });

  const [errors, setErrors] = useState({
    cust_email: "",
    cur_date: "",
    notes: "",
    cust_available:"",
    cust_avail_date: "",
  });

  const ValidateField = (value, name,custAvailable) => {
    let errorMsg = "";
    const trimmedValue = value && typeof value === "string" ? value.trim() : value;

    switch (name) {
      case "cust_email":
        if (!trimmedValue) {
          errorMsg = "Please Select Customer";
        }
        break;
      case "cur_date":
        if (!trimmedValue) {
          errorMsg = "Current Date can't be empty";
        }
        break;
      case "notes":
        if (!trimmedValue) {
          errorMsg = "Notes can't be empty";
        }
        break;
      case "cust_available":
        if (!trimmedValue) {
          errorMsg = "Customer Available Field can't be empty";
        }
        break;
        case "cust_avail_date":
          if (custAvailable === 'yes' && !trimmedValue) {
            errorMsg = "Customer Available Date can't be empty";
          }
          break;
      default:
        break;
    }
    return errorMsg;
  };

  const [empEmail, setEmpEmail] = useState([]);
  
  useEffect(() => {
    axios.get(`${config.apiUrl}/customers/getCustomerByEmpID?emp_id=${emp_id}`)
      .then(response => {
        setEmpEmail(response.data);
        console.log(response.data);
      });
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    // let errorMsg = ValidateField(value, name);
    let errorMsg = ValidateField(value, name, formData.cust_available);
    const selectedCustomer = empEmail.find((cust) => cust.cust_email === value);
  
    const categoryLookup = {
      "1st Priority": 1,
      "2nd Priority": 2,
      "3rd Priority": 3,
      "4th Priority": 4,
    };
  
    if (selectedCustomer) {
      const {
        cust_id,
        follow_emp_id,
        follow_emp_name,
        cust_name,
        bus_name,
        bus_category,
        category,
      } = selectedCustomer;
  
      setFormData({
        ...formData,
        [name]: value,
        cust_id,
        follow_emp_id,
        follow_emp_name,
        cust_name,
        bus_name,
        bus_category,
        category: categoryLookup[category], // Set category based on lookup
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
    setErrors({ ...errors, [name]: errorMsg });
  };
  
  

  const handleValidation = () => {
    let newErrors = {
      cust_email: ValidateField(formData.cust_email, 'cust_email'),
      cur_date: ValidateField(formData.cur_date, 'cur_date'),
      notes: ValidateField(formData.notes, 'notes'),
      cust_available: ValidateField(formData.cust_available, 'cust_available'),
    cust_avail_date: ValidateField(formData.cust_avail_date, 'cust_avail_date', formData.cust_available), // Pass cust_available
    };

    setErrors(newErrors);

    return Object.values(newErrors).some((error) => error !== '');
  };

  const [successMsg, setSuccessMsg] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (handleValidation()) {
      console.error('Form has errors. Cannot submit.');
      return;
    }

    console.log("Form Data :", formData);

    axios.post(`${config.apiUrl}/custMain/postCustMainData`, formData)
      .then(response => {
        console.log("Data Added Successfully");
        setSuccessMsg('Data added successfully!');
        toast.success('Customer added successfully!', {
          position: toast.POSITION.TOP_CENTER,
          autoClose: 3000, // Close after 3 seconds
        });
        onClose(); // Close the form
      })
      .catch(error => {
        console.error("Error adding data:", error);
      });
  };
    
  return (
    <div>
      <Grid container spacing={3}>
        <Grid item xs={6}>
            <TextField
            select
            fullWidth
            label="Select Customer"
            name='cust_email'
            value={formData.cust_email}
            onChange={handleInputChange}
            error={!!errors.cust_email}
            helperText={errors.cust_email}
            >
            {empEmail.map((emp,index)=>(
                <MenuItem key={index} value={emp.cust_email}>{emp.cust_email}</MenuItem>
            ))}
            </TextField>
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            type='date'
            label="Current Follow Up Date"
            name="cur_date"
            value={formData.cur_date}
            onChange={handleInputChange}
            error={!!errors.cur_date}
            helperText={errors.cur_date}
            />
        </Grid>
        <Grid item xs={6}>
          <TextField
          fullWidth
          label="Notes"
          name="notes"
          value={formData.notes}
          onChange={handleInputChange}
          error={!!errors.notes}
            helperText={errors.notes}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
          fullWidth
          select
          label="Customer Available"
          name="cust_available"
          value={formData.cust_available}
          onChange={handleInputChange}
          error={!!errors.cust_available}
            helperText={errors.cust_available}>
              <MenuItem value="yes">Yes</MenuItem>
              <MenuItem value="no">No</MenuItem>
              </TextField>
        </Grid>
        {formData.cust_available === 'yes' && (
          <Grid item xs={6}>
          <TextField
          fullWidth
          label="Customer Available Date"
          name="cust_avail_date"
          type='date'
          InputLabelProps={{shrink:true}}
          onChange={handleInputChange}
          value={formData.cust_avail_date}
          helperText={!!errors.cust_avail_date}
          error={errors.cust_avail_date}
          />
        </Grid>
        )}
      </Grid>
      <div style={{display:'flex',justifyContent:'center',marginTop:'20px'}}>
      <Button style={{backgroundColor:'#1B9C85',color:'whitesmoke'}} onClick={handleSubmit}>Submit</Button>
      </div>


      {successMsg && (
        <Dialog open={true} onClose={() => setSuccessMsg('')}>
          <DialogContent>
            <div>
              <p>{successMsg}</p>
            </div>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => { setSuccessMsg(''); onClose(); }}>Close</Button>
          </DialogActions>
        </Dialog>
      )}
    </div>
  )
}

export default AddCustomerMaintenance
