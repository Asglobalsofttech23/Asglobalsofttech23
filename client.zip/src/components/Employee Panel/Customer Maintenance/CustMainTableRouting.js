// import React from 'react'
// import EmployeeTopBar from '../Employee TopNav/EmployeeTopBar'
// import EmployeeSideBar from '../SideBar/EmployeeSideBar'
// import CustMaintenance from './CustMaintenance'


// function CustMainTableRouting({emp_id}) {
//   return (
//     <div>

//       <EmployeeTopBar/>
     
      
      
//       <div className='row'>
//       <div className='col-3'>
//       <EmployeeSideBar/>
//       </div>
//       <div className='col-9'>
//       <CustMaintenance emp_id={emp_id}/>
//       </div>
//       </div>
     
      
     
//     </div>
//   )
// }

// export default CustMainTableRouting


import React, { useEffect, useState } from 'react'
import EmployeeTopBar from '../Employee TopNav/EmployeeTopBar'
import EmployeeSideBar from '../SideBar/EmployeeSideBar'
import CustMaintenance from './CustMaintenance'
import axios from 'axios'
import moment from 'moment'
import config from '../../../config'
function CustMainTableRouting() {

  const emp_id = sessionStorage.getItem('emp_id');

  const [customerdata,setCustomerData] = useState([])
  const [notificationdate,setNotificationDate] = useState([])

  useEffect(()=>{
    axios.get(`${config.apiUrl}/custMain/getCustomerByEmpID?emp_id=${emp_id}`)
  .then(res=>{
    setCustomerData(res.data)
    console.log("Customer Data :",res.data)
  })
  },[])

  useEffect(()=>{
    if(customerdata.length > 0){
      const dates = customerdata.map((cust)=>cust.cur_follow_up_date);
      setNotificationDate(dates)
    }
  },[customerdata])




  useEffect(() => {
    if (notificationdate.length > 0) {
      const noti_date = moment(notificationdate[0],'YYYY-MM-DD');
      console.log("Noti Date :",noti_date.format('YYYY-MM-DD'));
      const afterOnerDay = noti_date.clone().add(2,'days');
      console.log("After One Day :",afterOnerDay.format('YYYY-MM-DD'))
      
    }
  }, [notificationdate]);

  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchInputChange = (query) => {
    setSearchQuery(query);
  };

  return (
    <div style={{display:'flex',overflow:'hidden'}}>
<EmployeeSideBar />
      
     
      
      
     
      <div style={{overflowY:'hidden',flexGrow:'1',marginLeft:'-20px'}}>
        <EmployeeTopBar onSearchInputChange={handleSearchInputChange}/>
        <div style={{marginRight:'20px',marginLeft:'20px'}}>
          <CustMaintenance searchQuery={searchQuery}/>
        </div>
        </div>
       
    
     
      
     
    </div>
  )
}

export default CustMainTableRouting
