// import React from 'react'
// import EmployeeTopBar from '../Employee TopNav/EmployeeTopBar'
// import CustomerTable from './CustomerTable'
// import EmployeeSideBar from '../SideBar/EmployeeSideBar'

// function CustomerTableRouting({emp_id}) {
//   return (
//     <div>

//       <EmployeeTopBar/>

//       <EmployeeSideBar>
//       <CustomerTable emp_id={emp_id}/>
//       </EmployeeSideBar>
      
//       {/* <div className='row'>
//       <div className='col-3'>
//       <EmployeeSideBar/>
//       </div>
//       <div className='col-9'>
//       <CustomerTable emp_id={emp_id}/>
//       </div>
//       </div> */}
     
      
     
//     </div>
//   )
// }

// export default CustomerTableRouting


import React, { useState } from 'react';
import EmployeeTopBar from '../Employee TopNav/EmployeeTopBar';
import CustomerTable from './CustomerTable';
import EmployeeSideBar from '../SideBar/EmployeeSideBar';

function CustomerTableRouting() {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchInputChange = (query) => {
    setSearchQuery(query);
  };
  return (
    <div style={{ display: 'flex', height: '100vh',overflow:'hidden' }}>
      
      <EmployeeSideBar />

      
     
        
        <div style={{overflowY:'hidden',flexGrow:'1',marginLeft:'-20px'}}>
        <EmployeeTopBar onSearchInputChange={handleSearchInputChange} />


        <div style={{marginRight:'20px',marginLeft:'20px'}}>
          <CustomerTable searchQuery={searchQuery}/>
        </div>

        </div>

       
        
      </div>
   
  );
}

export default CustomerTableRouting;
