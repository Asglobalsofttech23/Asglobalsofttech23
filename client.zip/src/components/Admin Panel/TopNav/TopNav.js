import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Badge from "@mui/material/Badge";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import NotificationsIcon from "@mui/icons-material/Notifications";
import { styled, alpha } from "@mui/material/styles";
import SearchIcon from "@mui/icons-material/Search";
import InputBase from "@mui/material/InputBase";
import AccountCircle from "@mui/icons-material/AccountCircle";
import MoreIcon from "@mui/icons-material/MoreVert";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import { DialogActions } from "@mui/material";
import { useNavigate } from "react-router-dom";
import logo from "../../../images/AS global white.png";
import NotificationsActiveIcon from "@mui/icons-material/NotificationsActive";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";


const Search = styled("div")(({ theme}) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  "&:hover": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginRight: theme.spacing(2),
  marginLeft: 0,
  width: "100%",
  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(3),
    width: "auto",
  },
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("md")]: {
      width: "20ch",
    },
  },
  "& input::selection": {
    background: "#008000", // Adjust the background color as needed
  },
}));

export default function TopNav({onSearchInputChange }) {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [mobileMoreAnchorEl, setMobileMoreAnchorEl] = React.useState(null);
  const [openDialog, setOpenDialog] = React.useState(false);
  const [notifications, setNotifications] = React.useState([
    { id: 1, message: "Hi! I am Notification 1" },
    { id: 2, message: "Hello! I am Notification 2" },
  ]);

  React.useEffect(() => {
    const sessionData = sessionStorage.getItem('pendingProjects');
    const pendingProjects = `Pending Projects: ${sessionData}`;
    const completedProjects = sessionStorage.getItem('completedProjects'); // Replace with actual count
    const totalProjects = sessionStorage.getItem('totalProjects'); // Replace with actual count
    
    const notifications = `${pendingProjects}\nCompleted Projects: ${completedProjects}\nTotal Projects: ${totalProjects}`;
    setNotifications(notifications);
  }, []);
  
  

  const navigate = useNavigate();

  const isMenuOpen = Boolean(anchorEl);
  const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);

  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMobileMenuClose = () => {
    setMobileMoreAnchorEl(null);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    handleMobileMenuClose();
  };

  const handleMobileMenuOpen = (event) => {
    setMobileMoreAnchorEl(event.currentTarget);
  };

  const handleNotificationsClick = () => {
    setOpenDialog(true);
  };

  const handleDialogClose = () => {
    setOpenDialog(false);
  };

  const handleClearNotification = (id) => {
    const updatedNotifications = notifications.filter(
      (notification) => notification.id !== id
    );
    setNotifications(updatedNotifications);
  };

  const renderNotificationsDialog = (
    <Dialog open={openDialog} onClose={handleDialogClose}>
      <DialogTitle>Notifications</DialogTitle>
      <DialogContent>
        <Typography variant="body1" style={{ whiteSpace: 'pre-line' }}>
          {notifications}
        </Typography>
        <Button onClick={handleDialogClose}>Close</Button>
      </DialogContent>
    </Dialog>
  );
  

  const [logoutModal, setLogoutModal] = React.useState(false);

  const handleOpenLogout = () => {
    setLogoutModal(true);
  };

  const handleCloseLogout = () => {
    setLogoutModal(false);
  };
  const handleLogout = () => {
    sessionStorage.clear();
    window.location.href = "http://rajatech.free.nf/";
    // window.location.href = 'http://localhost:3000/';
  };

  const renderProfileMenu = (
    <Menu
      anchorEl={anchorEl}
      anchorOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      id="primary-search-account-menu"
      keepMounted
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      open={isMenuOpen}
      onClose={handleMenuClose}
      style={{ marginTop: "50px" }}
    >
      <MenuItem onClick={handleMenuClose}>Profile</MenuItem>
      <MenuItem onClick={handleOpenLogout}>Logout</MenuItem>
    </Menu>
  );

  const [searchQuery, setSearchQuery] = React.useState('');

  const handleSearchInputChange = (e) => {
    setSearchQuery(e.target.value);
    onSearchInputChange(e.target.value);
  };
  

 


  return (
    <>
      <Box sx={{ flexGrow: 1 }}>
        <AppBar position="static">
          <Toolbar>
            <img src={logo} height="40" width="60" />
            <Typography
              variant="h6"
              noWrap
              component="div"
              sx={{
                display: { xs: "none", sm: "block" },
                fontWeight: "bold",
                marginLeft: "20px",
              }}
            >
              AS Global Soft Tech
            </Typography>
            <Box sx={{ flexGrow: 1 }} />
            <Tooltip title={notifications.length > 0 ? "Notifications available" : "No notifications"}>
  {notifications.length > 0 ? (
    <IconButton
      size="large"
      aria-label="show notifications"
      color="inherit"
      onClick={handleNotificationsClick}
    >
      <NotificationsActiveIcon color="white" />
    </IconButton>
  ) : (
    <IconButton
      size="large"
      aria-label="no notifications"
      color="inherit"
      onClick={handleNotificationsClick}
    >
      <NotificationsNoneIcon color="disabled" />
    </IconButton>
  )}
</Tooltip>

            <Search>
        <SearchIconWrapper>
          <SearchIcon />
        </SearchIconWrapper>
        <StyledInputBase
          placeholder="Search…"
          inputProps={{ "aria-label": "search" }}
          value={searchQuery}
          onChange={handleSearchInputChange}
        />
      </Search>
            <IconButton
              size="large"
              edge="end"
              aria-label="account of current user"
              aria-controls="primary-search-account-menu"
              aria-haspopup="true"
              onClick={handleProfileMenuOpen}
              color="inherit"
            >
              <AccountCircle />
            </IconButton>
            <Box sx={{ display: { xs: "flex", md: "none" } }}>
              <IconButton
                size="large"
                aria-label="show more"
                aria-controls="primary-search-account-menu-mobile"
                aria-haspopup="true"
                onClick={handleMobileMenuOpen}
                color="inherit"
              >
                <MoreIcon />
              </IconButton>
            </Box>
          </Toolbar>
        </AppBar>
        {renderProfileMenu}
        {renderNotificationsDialog}
      </Box>
      <Dialog open={logoutModal} onClose={handleCloseLogout}>
        <DialogContent>
          <p>Are you sure do you want to logout</p>
        </DialogContent>
        <DialogActions>
          <Button
            style={{ backgroundColor: "red", color: "white" }}
            onClick={handleLogout}
          >
            Logout
          </Button>
          <Button onClick={handleCloseLogout}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
