import React, { useEffect, useState } from 'react';
import axios from 'axios';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import { Card, Paper } from '@mui/material';
import { format } from 'date-fns';
import config from '../../../config';
function EntryList() {
  const [entryData, setEntryData] = useState([]);
  const initialDisplayCount = 7;

  useEffect(() => {
    axios.get(`${config.apiUrl}/attendance`)
      .then(response => {
        setEntryData(response.data);
      })
      .catch(error => {
        console.error("Error:", error);
      });
  }, []);

  const visibleEntries = entryData.slice(0, initialDisplayCount);
  const remainingEntries = entryData.slice(initialDisplayCount);

  return (
    <div>
      <Card component={Paper}>
        <List sx={{ bgcolor: 'background.paper', maxHeight: '350px', overflowY: 'scroll' }}>
          {visibleEntries.map((entry) => (
            <ListItem key={entry.id}>
              <ListItemAvatar>
                <Avatar>
                  {entry.emp_img && ( // Ensure emp_img exists
                    <img
                      src={`data:image/jpeg;base64,${entry.emp_img}`}
                      style={{ maxWidth: '80px', maxHeight: '100px' }}
                      alt={`Employee ${entry.id}`}
                    />
                  )}
                </Avatar>
              </ListItemAvatar>
              <ListItemText primary={entry.emp_name} />
              <ListItemText primary={entry.emp_email} />
              <ListItemText primary={format(new Date(entry.date), 'yyyy-MM-dd')} />
              <ListItemText primary={entry.login_time} />
            </ListItem>
          ))}
          {remainingEntries.map((entry) => (
            <ListItem key={entry.id}>
              <ListItemAvatar>
                <Avatar>
                  {entry.emp_img && ( // Ensure emp_img exists
                    <img
                      src={`${config.apiUrl}${entry.emp_img}`}
                      style={{ maxWidth: '80px', maxHeight: '100px' }}
                      alt={`Employee ${entry.id}`}
                    />
                  )}
                </Avatar>
              </ListItemAvatar>

              <ListItemText primary={entry.emp_name} />
              <ListItemText primary={entry.emp_email} />
              <ListItemText primary={format(new Date(entry.date), 'yyyy-MM-dd')} />
              <ListItemText primary={entry.login_time} />
            </ListItem>
          ))}
        </List>
      </Card>
    </div>
  );
}

export default EntryList;
