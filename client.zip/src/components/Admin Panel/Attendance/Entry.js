// import React, { useState } from 'react';
// import { TextField, Button, Modal, Dialog, DialogContent, DialogActions, Grid } from '@mui/material';
// import axios from 'axios';

// function Entry() {
//   const [formData, setFormData] = useState({
//     emp_email: '',
//   });

  // const [message, setMessage] = useState(null);
  // const [error, setError] = useState(null);
  // const [modalIsOpen, setModalIsOpen] = useState(false);

  // const openModal = () => {
  //   setModalIsOpen(true);
  // };

  // const closeModal = () => {
  //   setModalIsOpen(false);
  // };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     axios
//     // .post('https://crm-7yz5.onrender.com/attendance/entry', formData)
//       .post('http://localhost:3001/attendance/entry', formData)
//       .then((response) => {
//         console.log('Employee Logged In Successfully');
        // setMessage('Employee Logged In Successfully');
        // openModal();
//       })
      // .catch((error) => {
      //   console.error('Error Adding Employee', error);
      //   if (error.response && error.response.status === 404) {
      //     setError('Employee not found');
      //   } else if (error.response && error.response.status === 409) {
      //     setError('Attendance entry already exists for the employee on the same date');
      //   } else {
      //     setError('An error occurred');
      //   }
      //   openModal();
      // });
//   };

//   return (
//     <div>
//         <h1 className='text-center'>Entry Form</h1>
//       <Grid container spacing={1}>
//       <Grid item xs={12}>
//       <TextField
//         label="Employee Email"
//         name="emp_email"
//         value={formData.emp_email}
//         onChange={(e) => setFormData({ ...formData, emp_email: e.target.value })}
//       />
//       </Grid>
      
//       </Grid>

//       <div style={{ display: 'flex', justifyContent: 'center', marginTop: '25px' }}>
//                 <Button
//                     onClick={handleSubmit}
//                     style={{ backgroundColor: '#1B9C85', borderColor: '#1B9C85', color: 'white' }}
//                     className="action-button3"
//                 >
//                     Submit
//                 </Button>
//             </div>

      


      // <Dialog open={modalIsOpen} onClose={closeModal}>
      //   <DialogContent>
      //   {message ? <p>{message}</p> : null}
      //     {error ? <p>{error}</p> : null}
      //   </DialogContent>
      //   <DialogActions>
      //   <Button onClick={closeModal}>Close</Button>
      //   </DialogActions>

      // </Dialog>
//     </div>
//   );
// }

// export default Entry;








import { Button, Dialog, DialogActions, DialogContent } from '@mui/material'
import axios from 'axios';
import React, { useEffect, useState } from 'react'
import config from '../../../config';
function Entry() {
  
  const emp_id = sessionStorage.getItem('emp_id');
  const [empDetails ,setEmpDetails] = useState([]);
  const [isHovered, setIsHovered] = useState(false);

  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);
  const [modalIsOpen, setModalIsOpen] = useState(false);

  const openModal = () => {
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  useEffect(()=>{
    axios.get(`${config.apiUrl}/employees/getEmpDataByEmpID?emp_id=${emp_id}`)
    .then(response =>{
      setEmpDetails(response.data[0])
    })
  },[emp_id])
  const empEntryData = {
    emp_id:emp_id,
    emp_name:empDetails.emp_name,
    emp_email:empDetails.emp_email
  }
  
  const handleClockin = (e) =>{
    e.preventDefault();
    axios.post(`${config.apiUrl}/attendance/entry`,empEntryData)
    .then(response =>{
      setMessage('Employee Logged In Successfully');
        openModal();
    })
    .catch((error) =>{
      if(error.response && error.response.status === 409){
        setError('Attendance entry already exists for the employee on the same date');
      }else{
        setError('An error occurred');
      }
      openModal();
    })
  }
  return (
    <div>
      <Button 
      onClick={handleClockin}
      style={{
        backgroundColor: isHovered ? 'blue' : '#1B9C85',
        color: isHovered ? 'whitesmoke' : 'white'
      }}
      onMouseEnter={()=>setIsHovered(true)}
      onMouseLeave={()=>setIsHovered(false)}
      >
        Clock In
        </Button>

        <Dialog open={modalIsOpen} onClose={closeModal}>
        <DialogContent>
        {message ? <p>{message}</p> : null}
          {error ? <p>{error}</p> : null}
        </DialogContent>
        <DialogActions>
        <Button onClick={closeModal}>Close</Button>
        </DialogActions>

      </Dialog>
    </div>
  )
}

export default Entry
