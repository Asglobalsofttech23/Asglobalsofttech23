import { Button, Grid, MenuItem, TextField } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import config from "../../../config";
function AdminCustMainUpdate({ custData,onClose }) {
  const emp_id = sessionStorage.getItem("emp_id");
  const [updateData, setUpdateData] = useState({
    cust_main_id:custData ? custData.cust_main_id:"",
    cust_id: custData ? custData.cust_id : "",
    emp_id: custData ? custData.emp_id : "",
    emp_name: custData ? custData.emp_name : "",
    cust_name: custData ? custData.cust_name : "",
    cust_email: custData ? custData.cust_email : "",
    bus_name: custData ? custData.bus_name : "",
    bus_category: custData ? custData.bus_category : "",
    category: custData ? custData.category : "",
    notes: custData ? custData.notes : "",
    cur_follow_up_date: custData ? custData.cur_follow_up_date : "",
    cus_avail_date: custData ? custData.cus_avail_date : "",
  });
  useEffect(() => {
    console.log("Updated Data is :",updateData);
  }, [updateData]);

  const [empEmail, setEmpEmail] = useState([]);

  useEffect(() => {
    axios.get(`${config.apiUrl}/custMain/getCustMainDataAdmin`)
      .then((response) => {
        setEmpEmail(response.data);
        // console.log(response.data);
      });
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    let errorMsg = validateField(name, value);
    const selectedCustomer = empEmail.find((cust) => cust.cust_email === value);
  
    if (selectedCustomer) {
      const {
        cust_id,
        emp_id,
        emp_name,
        cust_name,
        bus_name,
        bus_category,
        category,
      } = selectedCustomer;
  
      setUpdateData({
        ...updateData,
        [name]: value,
        cust_id,
        emp_id,
        emp_name,
        cust_name,
        bus_name,
        bus_category,
        category,
      });
    } else {
      setUpdateData({
        ...updateData,
        [name]: value,
      });
    }
    setErrors({ ...errors, [name]: errorMsg });
  };
  


  const [errors, setErrors] = useState({
    cust_email: "",
    cur_follow_up_date: "",
    notes: "",
    cus_avail_date: "",
  });

  const validateField = (name,value) =>{
    let errorMsg = "";

    const trimmedValue = value && typeof value === "string" ? value.trim() : value ;

    switch(name){
      case "cust_email":
          if(!trimmedValue){
            errorMsg = "Please Select Customer";
          }
          break
      case "cur_follow_up_date":
        if(!trimmedValue){
          errorMsg = "Current Date can't be empty";
        }
        break
      case "cus_avail_date":
        if(!trimmedValue){
          errorMsg = "Customer Available Date  can't be empty";
        }
        break
      case "notes":
        if(!trimmedValue){
          errorMsg = "Notes can't be empty";
        }
        break
      default:
        break
       
    }
    return errorMsg
  }


  const handleValidation = () => {
    let newError = {
      cust_email: validateField("cust_email", updateData.cust_email),
      cur_follow_up_date: validateField("cur_follow_up_date", updateData.cur_follow_up_date),
      cus_avail_date: validateField("cus_avail_date", updateData.cus_avail_date),
      notes: validateField("notes", updateData.notes)
    };
  
    setErrors(newError);
    return Object.values(newError).some((error) => error !== "");
  };
  


  const handleUpdate = (e) =>{
    e.preventDefault();

    if(handleValidation()){
      console.error('Form has errors. Cannot submit.');
      return;
    }

    axios.put(`${config.apiUrl}/custMain/${updateData.cust_main_id}`,updateData)
    .then(response =>{
      console.log("Customer  Maintenance Data Is Updated Successfully")
      onClose()
    })
    .catch((error) =>{
      console.error("Error Customer Data Updated",error)
    })
  }

  return (
    <div>
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <TextField
          fullWidth
          select
            label="Customer Email"
            name="cust_email"
            value={updateData.cust_email}
            onChange={handleInputChange}
            error={!!errors.cust_email}
            helperText={errors.cust_email}
            disabled
          >
            {empEmail.map((emp, index) => (
              <MenuItem key={index} value={emp.cust_email}>
                {emp.cust_email}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            label="Current Follow Up Date"
            name="cur_follow_up_date"
            value={updateData.cur_follow_up_date}
            onChange={handleInputChange}
            error={!!errors.cur_follow_up_date}
            helperText={errors.cur_follow_up_date}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            label="Customer Available Date"
            name="cus_avail_date"
            value={updateData.cus_avail_date}
            onChange={handleInputChange}
            error={!!errors.cus_avail_date}
            helperText={errors.cus_avail_date}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            label="Notes"
            name="notes"
            value={updateData.notes}
            onChange={handleInputChange}
            error={!!errors.notes}
            helperText={errors.notes}
          />
        </Grid>
      </Grid>
      <Button onClick={handleUpdate}>Update</Button>
    </div>
  );
}

export default AdminCustMainUpdate;
