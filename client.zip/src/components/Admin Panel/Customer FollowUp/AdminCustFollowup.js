import {
    Checkbox,
    Paper,
    Table,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TableBody,
    TextField,
    Button,
    Dialog,
    DialogContent,
    DialogActions,
    Menu,
    MenuItem,
  } from '@mui/material';
  import axios from 'axios';
  import React, { useEffect, useState } from 'react';
  import ReactPaginate from 'react-paginate';
  import { ToastContainer, toast } from 'react-toastify';
  import 'react-toastify/dist/ReactToastify.css';
  import EditIcon from "@mui/icons-material/Edit";
  import DeleteIcon from "@mui/icons-material/Delete";
  import * as XLSX from 'xlsx';
// import AddCustomerMaintenance from './AddCustomerMaintenance';
import AdminCustMainUpdate from './AdminCustMainUpdate';
  import config from '../../../config';
  function AdminCustFollowup({searchQuery}) {

    
    useEffect(() => {
      const highlightColor = 'black';
      const unhighlightColor = 'initial';
      const highlightBackground = 'yellow';
      const unhighlightBackground = 'white';
    
      const tableCells = document.querySelectorAll('td'); // Select all table cells or specific cells where you want to apply the highlight
    
      tableCells.forEach((cell) => {
        const cellText = cell.textContent;
        const searchQueryLC = searchQuery.toLowerCase();
        
        // Split the text content of the cell into parts based on the search query
        const parts = cellText.split(new RegExp(`(${searchQueryLC})`, 'gi'));
        
        // Recreate the inner HTML of the cell to highlight the matched parts
        cell.innerHTML = parts.map(part => {
          if (part.toLowerCase() === searchQueryLC) {
            return `<span style="color: ${highlightColor}; background-color: ${highlightBackground}">${part}</span>`;
          } else {
            return part;
          }
        }).join('');
      });
    }, [searchQuery]);

    const emp_id = sessionStorage.getItem('emp_id');
   
    const [customers, setCustomers] = useState([]);
  
    const [searchedVal, setSearchedVal] = useState("");   
  
  // Export data 
  const [selectedRows, setSelectedRows] = useState([]);
  
  const [selectAll, setSelectAll] = useState(false);
  
  
  // Pagination
  const [itemsPerPage, setItemsPerPage] = useState(5); // Change the default value to 5
  const [currentPage, setCurrentPage] = useState(1);
  
  const handleItemsPerPageChange = (event) => {
    const newItemsPerPage = parseInt(event.target.value, 10);
    if(newItemsPerPage === 0){
      setItemsPerPage(customers.length)
    }else{
      setItemsPerPage(newItemsPerPage);
    setCurrentPage(1);
    }
  };
  
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = customers.slice(indexOfFirstItem, indexOfLastItem);
  
  
    useEffect(() => {
      axios.get(`${config.apiUrl}/custMain/getCustMainDataAdmin`)
        .then((response) => {
          setCustomers(response.data);
        })
        .catch((error) => {
          console.error('Error fetching data:', error);
        });
    }, [customers]); // The empty dependency array ensures the effect runs only once
  
  
    const handleRowSelect = (cust_id) => {
      const selectedIndex = selectedRows.indexOf(cust_id);
      let newSelected = [];
  
      if (selectedIndex === -1) {
        newSelected = newSelected.concat(selectedRows, cust_id);
      } else if (selectedIndex === 0) {
        newSelected = newSelected.concat(selectedRows.slice(1));
      } else if (selectedIndex === selectedRows.length - 1) {
        newSelected = newSelected.concat(selectedRows.slice(0, -1));
      } else if (selectedIndex > 0) {
        newSelected = newSelected.concat(
          selectedRows.slice(0, selectedIndex),
          selectedRows.slice(selectedIndex + 1)
        );
      }
  
      setSelectedRows(newSelected);
    };
  
  
  
  
    const handleSelectAll = () => {
      if (selectAll) {
        setSelectedRows([]);
      } else {
        const allCustIds = customers.map((cust) => cust.cust_id);
        setSelectedRows(allCustIds);
      }
      setSelectAll(!selectAll);
    };
  
  
  
    const [anchorEl, setAnchorEl] = useState(null);
  
  
      const handleClick = (event) => {
          setAnchorEl(event.currentTarget);
      };
  
      const handleClose = () => {
          setAnchorEl(null);
      };
  
    // Export CSV
  
    const exportDataToCSV = () => {
      const selectedData = customers.filter((cust) => selectedRows.includes(cust.cust_id));
  
      const csvData = selectedData.map((cust, index) => ({
        'Customer ID': cust.cust_id,
        'Employee ID': cust.emp_id,
        'Employee Name': cust.emp_name,
        'Customer Name': cust.cust_name,
        'Customer Email': cust.cust_email,
        // 'Customer Mobile': cust.cust_mobile,
        'Bussiness Name': cust.bus_name,
        'Bussiness Category': cust.bus_category,
        'Priority' : cust.category,
        'District' : cust.dist,
        'City' : cust.city,
        'Notes' : cust.notes,
        'Last Follow Up Date': cust.cur_follow_up_date,
        'Customer Available Date': cust.cus_avail_date,
       
      }));
  
      const csvString = 'Customer ID,Employee ID,Employee Name,Customer Name,Customer Email,Bussiness Name,Bussiness Category,Priority ,District,City,Notes, Last Follow Up Date,Customer Available Date\n' +
        csvData.map(row => Object.values(row).join(',')).join('\n');
  
      const blob = new Blob([csvString], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
  
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = 'selected_data.csv';
  
      document.body.appendChild(a);
      a.click();
  
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    };
  
  
  
    const handleExcelExport = () => {
      const excelData = customers.map(({cust_id,emp_id,emp_name,cust_name,cust_email,bus_name,bus_category,category,dist,city,notes,cur_follow_up_date,cus_avail_date}, index) => [
          index + 1,
          emp_id,
          emp_name,
          cust_name,
          cust_email,
          bus_name,
          bus_category,
          category,
          dist,
          city,
          notes,
          cur_follow_up_date,
          cus_avail_date
   
      ]);
  
      const ws = XLSX.utils.aoa_to_sheet([['S.no', 'Employee ID', 'Employee Name', 'Customer Name','Customer Email', 'Customer Bussiness Name','Customer Business Category', 'Priority','District','City','Notes', 'Last Follow Up Date' , 'Customer Available Date'], ...excelData]);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Sheet 1');
      XLSX.writeFile(wb, 'project_data.xlsx');
  };
  
  const handleJSONExport = () => {
      const jsonData = JSON.stringify(customers, null, 2); // The '2' parameter adds indentation for better readability
      const blob = new Blob([jsonData], { type: 'application/json' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'project_data.json';
      link.click();
  };
  
  
  
  
    // Pagination
  
  
  
  
    const filterCustomers = (customer) => {
      const searchValue = searchedVal.toLowerCase();
      return (
        !searchedVal ||
        (customer.emp_name && customer.emp_name.toString().toLowerCase().includes(searchValue)) ||
        (customer.cust_name && customer.cust_name.toString().toLowerCase().includes(searchValue)) ||
        (customer.cust_email && customer.cust_email.toString().toLowerCase().includes(searchValue)) ||
        (customer.bus_name && customer.bus_name.toString().toLowerCase().includes(searchValue)) ||
        (customer.bus_category && customer.bus_category.toString().toLowerCase().includes(searchValue)) ||
        (customer.category && customer.category.toString().toLowerCase().includes(searchValue)) ||
        (customer.notes && customer.notes.toString().toLowerCase().includes(searchValue)) ||
        (customer.cur_follow_up_date && customer.cur_follow_up_date.toString().toLowerCase().includes(searchValue)) ||
        (customer.dist && customer.dist.toString().toLowerCase().includes(searchValue)) ||
        (customer.city && customer.city.toString().toLowerCase().includes(searchValue)) ||
        (customer.cus_avail_date && customer.cus_avail_date.toString().toLowerCase().includes(searchValue)) 
       
      );
    };
  
  
  // add new customer modal
  const [addCustomerDialog , setAddCustomerDialog] = useState(false)

  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  
  const handleOpenAddCustDialog = () =>{
    setAddCustomerDialog(true)
  }
  
  
  const handleCloseAddCustDialog = (success = false) =>{
    setAddCustomerDialog(false)

    if (success) {
      // Show a toast message for success
      toast.success('Customer added successfully!', {
        position: toast.POSITION.TOP_CENTER,
        autoClose: 3000, // Close after 3 seconds
      });
    }
  };
  
  
  
  // Edit Customer Data
  const [selectedCustomerData, setSelectedCustomerData] = useState(null);
    const [openEditDialog, setOpenEditDialog] = useState(false);
  
  
 
  
  
  const handleOpenEditDialog = (cust_main_id) => {
    const selectedCustomer = customers.find((cust) => cust.cust_main_id === cust_main_id);
  
    if (selectedCustomer) {
      setSelectedCustomerData(selectedCustomer);
      setOpenEditDialog(true);
    }
  }
  
  const handleCloseEditDialog = () => {
    setSelectedCustomerData(null);
    setOpenEditDialog(false);
  }
  
  
  
  // Delete
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [customerToDelete, setCustomerToDelete] = useState(null);
  
  
  const handleDeleteCustomer = (cust_main_id) => {
    const selectedCustomer = customers.find((cust) => cust.cust_main_id === cust_main_id);
  
    if (selectedCustomer) {
      setCustomerToDelete(selectedCustomer);
      setOpenDeleteDialog(true);
    }
  };
  
  const confirmDelete = () => {
    if (customerToDelete) {
      axios.delete(`${config.apiUrl}/custMain/${customerToDelete.cust_main_id}/delete`)
        .then((response) => {
          console.log('Customer deleted successfully:', response.data);
  
          // You may want to fetch the updated data again
         
          setOpenDeleteDialog(false); // Close the confirmation dialog
        })
        .catch((error) => {
          console.error('Error deleting employee:', error);
        });
    }
  };
  
  const [showNotes,setShowNotes] = useState('');
  const [openNotesDialog,setNotesDialog] = useState(false);
  
  const handleOpenNotes = (notes) =>{
    setShowNotes(notes)
    setNotesDialog(true)
  }
  
  
    return (
      <div>
        <h1 className='text-center'>Customer Index</h1>
  
        <div className='row'>
            <div className='col-3'>
            <Button
        style={{ backgroundColor: '#1B9C85', borderColor: '#1B9C85', color: 'white' }}
        onClick={handleClick}
        onMouseEnter={handleClick}
      >
        Export data
      </Button>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleClose}
         // Close the menu on mouse leave
      >
        <MenuItem onClick={exportDataToCSV} >Export as CSV</MenuItem>
        <MenuItem onClick={handleExcelExport} >Export as Excel</MenuItem>
        <MenuItem onClick={handleJSONExport} onMouseOut={handleClose}>Export as JSON</MenuItem>
      </Menu>
            
            </div>
            <div className='col-3'>
            <TextField onChange={(e) => setSearchedVal(e.target.value)}
            label = "Search"
            
            />
            </div>
            <div className='col-3'>
            <div style={{ marginBottom: '20px', marginLeft: '100px' }}>
             
  
              <select
                value={itemsPerPage} onChange={handleItemsPerPageChange}
                style={{
                  padding: '5px 10px',
                  margin: '0 5px',
                  border: '1px solid #007bff',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: '#fff',
                  color: '#007bff',
                  textDecoration: 'none',
                  transition: 'background-color 0.3s, color 0.3s',
                }}
              >
                <option value="5">5 Per Page</option>
                <option value="10">10  Per Page</option>
                <option value="15">15  Per Page</option>
                <option value="0">All  Per Page</option>
              </select>
            </div>
            </div>
            <div className='col-3'>
              <Button onClick={handleOpenAddCustDialog}
                style={{ backgroundColor: '#1B9C85', borderColor: '#1B9C85', color: 'white' }} >Add New Customer</Button>
            </div>
          </div>
        
        
              
        <TableContainer component={Paper} className='mt-2'>
          <Table style={{ borderCollapse: 'collapse' }}>
            <TableHead style={{backgroundColor:'#1B9C85'}}>
              <TableRow>
                <TableCell style={{ border: '1px solid #ddd' }}>
                <Checkbox
                        checked={selectAll}
                        onChange={handleSelectAll}
                      />
                </TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>S.No</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Employee Name</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Customer Name</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Customer Email</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Bussiness Name</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Bussiness Category</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Priority</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>District</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>City</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Notes</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Current FollowUp Date</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Customer Avilable Date</TableCell>
                
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
            {currentItems.filter(filterCustomers).map((cust, index) => (
                    <TableRow key={cust.cust_id + '_' + index} style={{ backgroundColor: index % 2 === 0 ? '#f2f2f2' : 'white' }}>
  
                      <TableCell style={{ border: '1px solid #ddd' }}>
                      <Checkbox
                          checked={selectedRows.includes(cust.cust_id)}
                          onChange={() => handleRowSelect(cust.cust_id)}
                        />
                      </TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{index + 1}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.emp_name}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.cust_name}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.cust_email}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.bus_name}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.bus_category}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.category}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.dist}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.city}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }} >
                        <Button onClick={()=>handleOpenNotes(cust.notes)}>Show Notes</Button>
                        </TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.cur_follow_up_date}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.cus_avail_date}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>
                      <Button onClick={() => handleOpenEditDialog(cust.cust_main_id)}>
                        <EditIcon/>
                        Edit
                      </Button>
                      <Button onClick={() => handleDeleteCustomer(cust.cust_id)}>
                         <DeleteIcon style={{color:'red'}}/>
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
            </TableBody>
          </Table>
        </TableContainer>
        {/* Pagination */}
        <nav aria-label="Page navigation" className="text-center">
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
            <ReactPaginate
              previousLabel={
                <span
                  style={{
                    padding: '5px 10px',
                    margin: '0 5px',
                    border: '1px solid #ccc',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    backgroundColor: '#152445',
                    color: 'white',
                    textDecoration: 'underline',
                    textDecorationColor: '#152445',
                  }}
                >
                  Previous
                </span>
              }
              nextLabel={
                <span
                  style={{
                    padding: '5px 10px',
                    margin: '0 5px',
                    border: '1px solid #ccc',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    backgroundColor: '#152445',
                    color: 'white',
                    textDecoration: 'underline',
                    textDecorationColor: '#152445',
                  }}
                >
                  Next
                </span>
              }
              breakLabel={
                <span
                  style={{
                    padding: '5px 10px',
                    margin: '0 5px',
                    border: '1px solid #ccc',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    backgroundColor: '#fff',
                    color: '#333',
                    textDecoration: 'none',
                  }}
                >
                  ...
                </span>
              }
              pageCount={Math.ceil(customers.filter(filterCustomers).length / itemsPerPage)} // Use 'customers' instead of 'filteredCustomers'
              marginPagesDisplayed={2}
              pageRangeDisplayed={4}
              onPageChange={({ selected }) => setCurrentPage(selected + 1)}
              containerClassName={"pagination justify-content-center"}
              subContainerClassName={"pages pagination"}
              activeClassName={"active"}
            />
          </div>
        </nav>
  
        {/* <Dialog open={addCustomerDialog} onClose={handleCloseAddCustDialog} maxWidth="md" fullWidth>
          <DialogContent>
            <AddCustomerMaintenance onClose={handleCloseAddCustDialog} emp_id={emp_id}/>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseAddCustDialog}>Close</Button>
          </DialogActions>
        </Dialog>
   */}
  
  
        {/* Edit Dialog */}
  
        <Dialog open={openEditDialog} onClose={handleCloseEditDialog}>
          <DialogContent>
            <AdminCustMainUpdate custData={selectedCustomerData}  onClose={handleCloseEditDialog} />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseEditDialog}>Close</Button>
          </DialogActions>
        </Dialog>
  
  
  
  {/* Delete */}
  
  
          
  <Dialog open={openDeleteDialog} onClose={() => setOpenDeleteDialog(false)}>
    <DialogContent>
      <div>
        <p>Are you sure you want to delete this employee?</p>
      </div>
    </DialogContent>
    <DialogActions>
      <Button
        variant="contained"
        onClick={confirmDelete}
        style={{ backgroundColor: '#DC143C', color: 'white' }}
      >
        OK
      </Button>
      <Button
        variant="contained"
        onClick={() => setOpenDeleteDialog(false)}
        style={{ backgroundColor: '#1B9C85', color: 'white' }}
      >
        Cancel
      </Button>
    </DialogActions>
  </Dialog>


  <Dialog open={openNotesDialog} onClose={()=>setNotesDialog(false)} maxWidth='md'>
          <DialogContent>
            <p>{showNotes}</p>
          </DialogContent>
          <DialogActions>
            <Button onClick={()=>setNotesDialog(false)}>Close</Button>
          </DialogActions>
        </Dialog>

  {/* Success Msg */}
  {/* <Dialog open={showSuccessDialog} onClose={() => setShowSuccessDialog(false)}>
        <DialogContent>
          <div>
            <p>{successMessage}</p>
          </div>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowSuccessDialog(false)}>Close</Button>
        </DialogActions>
      </Dialog> */}
  
  <ToastContainer />
  
      </div>
    );
  }
  
  export default AdminCustFollowup;
  



