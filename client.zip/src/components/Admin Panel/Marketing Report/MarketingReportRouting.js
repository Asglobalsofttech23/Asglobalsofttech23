import React , {useState} from 'react'
import SideNav from '../SideNav/SideNav'
import TopNav from '../TopNav/TopNav'
import MarketingReportForm from './MarketingReportForm'

function MarketingReportRouting() {
    const [searchQuery, setSearchQuery] = useState('');

  const handleSearchInputChange = (query) => {
    setSearchQuery(query);
  };
  return (
    <div style={{display:'flex',overflow:'hidden',minHeight:'700px'}}>
      <SideNav/>
      <div style={{flexGrow:'1',overflowY:'hidden',marginLeft:'-20px'}}>
        <TopNav onSearchInputChange={handleSearchInputChange}/>
        <div style={{marginLeft:'20px',marginRight:'20px'}}>
            <MarketingReportForm searchQuery={searchQuery}/>
        </div>
      </div>
    </div>
  )
}

export default MarketingReportRouting
