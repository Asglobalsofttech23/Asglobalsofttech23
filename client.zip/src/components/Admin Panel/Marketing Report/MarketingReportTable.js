import React , {useState,useEffect} from 'react'
import {
    Button,
    Checkbox,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    Menu,
    MenuItem,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TextField,
  } from "@mui/material";
import * as XLSX from 'xlsx'
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import ReactPaginate from 'react-paginate';

function MarketingReportTable({reportData , searchQuery}) {

  useEffect(() => {
    const highlightColor = 'black';
    const unhighlightColor = 'initial';
    const highlightBackground = 'yellow';
    const unhighlightBackground = 'white';
  
    const tableCells = document.querySelectorAll('td'); // Select all table cells or specific cells where you want to apply the highlight
  
    tableCells.forEach((cell) => {
      const cellText = cell.textContent;
      const searchQueryLC = searchQuery.toLowerCase();
      
      // Split the text content of the cell into parts based on the search query
      const parts = cellText.split(new RegExp(`(${searchQueryLC})`, 'gi'));
      
      // Recreate the inner HTML of the cell to highlight the matched parts
      cell.innerHTML = parts.map(part => {
        if (part.toLowerCase() === searchQueryLC) {
          return `<span style="color: ${highlightColor}; background-color: ${highlightBackground}">${part}</span>`;
        } else {
          return part;
        }
      }).join('');
    });
  }, [searchQuery]);

    const [itemsPerPage, setItemsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  const handleChangeItemPerPage = (e) => {
    const newItemsPerPage = parseInt(e.target.value, 10);
    if (newItemsPerPage === 0) {
      setItemsPerPage(reportData.length);
      setCurrentPage(1);
    } else {
      setItemsPerPage(newItemsPerPage);
      setCurrentPage(1);
    }
  };
  

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = itemsPerPage - indexOfLastItem;
  const currentItems = reportData.slice(
    indexOfFirstItem,
    indexOfLastItem
  );

    const [searchedVal, setSearchedVal] = useState("");

    const filterData = (report) => {
      const searchValue = searchedVal.toLocaleLowerCase();
      return Object.values(report).some(
        (value) => value && value.toString().toLowerCase().includes(searchValue)
      );
    };


    
    const [selectedReport, setSelectedReport] = useState([]);

  const [selectAll, setSelectAll] = useState(false);

  const handleCheckboxChange = (markCustId) => {
    const selectedReportIds = [...selectedReport];
    if (selectedReportIds.includes(markCustId)) {
      const index = selectedReportIds.indexOf(markCustId);
      selectedReportIds.splice(index, 1);
    } else {
        selectedReportIds.push(markCustId);
    }
    setSelectedReport(selectedReportIds);
  };


  const handleSelectAll = () => {
    if (selectAll) {
        setSelectedReport([]);
    } else {
      const allReportIds = reportData.map(
        (report) => report.mark_cust_id
      );
      setSelectedReport(allReportIds);
    }
    setSelectAll(!selectAll);
  };

  const [anchorEl, setAnchorEl] = useState(null);

  const handleExport = (format) => {
    if (reportData.length === 0) {
      console.log("No Customer selected for export");
      return;
    }

    switch (format) {
      case "CSV":
        exportToCSV();
        break;
      case "Excel":
        exportToExcel();
        break;
      case "JSON":
        exportToJSON();
        break;
      default:
        break;
    }
  };

  const exportToCSV = () => {
    if (selectedReport.length === 0) {
      console.log("No Customer selected for export");
      return;
    }
  
    const selectedReportData = reportData.filter((markCust) =>
      selectedReport.includes(markCust.mark_cust_id)
    );
  
    // Create CSV content
    const header = Object.keys(selectedReportData[0]).join(",");
    const csv = [
      header,
      ...selectedReportData.map((markCust) =>
        Object.values(markCust)
          .map((value) => `"${value}"`)
          .join(",")
      ),
    ].join("\n");
  
    // Create Blob for CSV file
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
  
    // Download CSV file
    const a = document.createElement("a");
    a.href = url;
    a.download = "marketing_report.csv";
    document.body.appendChild(a); // Required for Firefox
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  

  const exportToExcel = () => {
    const selectedReportData = reportData.filter((markCust) =>
      selectedReport.includes(markCust.mark_cust_id)
    );
    const worksheet = XLSX.utils.json_to_sheet(selectedReportData);

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Customer");
    XLSX.writeFile(workbook, "marketing_report.xlsx");
  };

  const exportToJSON = () => {
    const selectedReportData = reportData.filter((markCust) =>
      selectedReport.includes(markCust.mark_cust_id)
    );

    const jsonData = JSON.stringify(selectedReportData, null, 2);
    const blob = new Blob([jsonData], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "marketing customer.json";
    a.click();
    URL.revokeObjectURL(url);
  };

    

  return (
    <div style={{marginTop:'20px'}}>


<div className="row" style={{ marginTop: "50px", marginBottom: "50px" }}>
        <div className="col-3">
          <Button
            style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}
            onClick={(e) => setAnchorEl(e.currentTarget)}
          >
            Export data
          </Button>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={() => setAnchorEl(null)}
          >
            <MenuItem onClick={() => handleExport("CSV")}>
              Export as CSV
            </MenuItem>
            <MenuItem onClick={() => handleExport("Excel")}>
              Export as Excel
            </MenuItem>
            <MenuItem onClick={() => handleExport("JSON")}>
              Export as JSON
            </MenuItem>
          </Menu>
        </div>
        <div className="col-3">
          <TextField
            label="Search"
            onChange={(e) => setSearchedVal(e.target.value)}
          />
        </div>
        <div className="col-3">
          <select
            value={itemsPerPage}
            onChange={handleChangeItemPerPage}
            style={{
              padding: "5px 10px",
              margin: "0 5px",
              border: "1px solid #007bff",
              borderRadius: "4px",
              cursor: "pointer",
              backgroundColor: "#fff",
              color: "#007bff",
              textDecoration: "none",
              transition: "background-color 0.3s, color 0.3s",
            }}
          >
            <option value="5">5 Per Page</option>
            <option value="10">10 Per Page</option>
            <option value="15">15 Per Page</option>
            <option value="0">All Per Page</option>
          </select>
        </div>
        <div className="col-3">
          <Button
          
            style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}
          >
            Add New Customer
          </Button>
        </div>
      </div>

      <TableContainer component={Paper}>
            <Table>
              <TableHead style={{ backgroundColor: "#1B9C85" }}>
                <TableRow>
                  <TableCell>
                  <Checkbox checked={selectAll} onChange={handleSelectAll} />
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    S.No
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Name
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Mobile
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Email
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Bussiness Name
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Bussiness Category
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Priority
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Followed By
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Follo Up Date
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {currentItems.filter(filterData).map((report, index) => (
                  <TableRow key={report.mark_cust_id}>
                    <TableCell style={{ border: "1px solid #ddd" }}>
        <Checkbox
          checked={selectedReport.includes(report.mark_cust_id)}
          onChange={() => handleCheckboxChange(report.mark_cust_id)}
        />
      </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {index + 1}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {report.mark_cust_name}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {report.mark_cust_mobile}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {report.mark_cust_email}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {report.mark_cust_bus_name}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {report.mark_cust_bus_category}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {report.category}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {report.emp_name}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {report.follow_up_date}
                    </TableCell>
                    
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <nav aria-label="Page navigation" className="text-center">
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "20px",
              }}
            >
              <ReactPaginate
                previousLabel={
                  <span
                    style={{
                      padding: "5px 10px",
                      margin: "0 5px",
                      border: "1px solid #ccc",
                      borderRadius: "4px",
                      cursor: "pointer",
                      backgroundColor: "#152445",
                      color: "white",
                      textDecoration: "underline",
                      textDecorationColor: "#152445",
                    }}
                  >
                    Previous
                  </span>
                }
                nextLabel={
                  <span
                    style={{
                      padding: "5px 10px",
                      margin: "0 5px",
                      border: "1px solid #ccc",
                      borderRadius: "4px",
                      cursor: "pointer",
                      backgroundColor: "#152445",
                      color: "white",
                      textDecoration: "underline",
                      textDecorationColor: "#152445",
                    }}
                  >
                    Next
                  </span>
                }
                breakLabel={
                  <span
                    style={{
                      padding: "5px 10px",
                      margin: "0 5px",
                      border: "1px solid #ccc",
                      borderRadius: "4px",
                      cursor: "pointer",
                      backgroundColor: "#fff",
                      color: "#333",
                      textDecoration: "none",
                    }}
                  >
                    ...
                  </span>
                }
                pageCount={Math.ceil(
                  reportData.filter(filterData).length / itemsPerPage
                )} // Use 'customers' instead of 'filteredCustomers'
                marginPagesDisplayed={2}
                pageRangeDisplayed={4}
                onPageChange={({ selected }) => setCurrentPage(selected + 1)}
                containerClassName={"pagination justify-content-center"}
                subContainerClassName={"pages pagination"}
                activeClassName={"active"}
              />
            </div>
          </nav>
    </div>
  )
}

export default MarketingReportTable
