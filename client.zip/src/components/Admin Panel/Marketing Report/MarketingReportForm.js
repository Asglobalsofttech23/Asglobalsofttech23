import React, { useEffect, useState } from 'react';
import { Button, Grid, MenuItem, TextField } from '@mui/material';
import axios from 'axios';
import MarketingReportTable from './MarketingReportTable';
import config from '../../../config';
function MarketingReportForm({searchQuery}) {
    const [formData, setFormData] = useState({
        mark_cust_id: '',
        emp_id: '',
        mark_cust_bus_name: '',
        category: '',
        f_date: '',
        t_date: '',
    });

    const [customer, setCustomer] = useState([]);
    useEffect(() => {
        axios.get(`${config.apiUrl}/marketing/getmarketingCustData`)
            .then((response) => {
                setCustomer(response.data);
            })
            .catch((error) => {
                console.log("Error :", error);
            });
    }, []);

    const [employee, setEmployee] = useState([]);
    useEffect(() => {
        axios.get(`${config.apiUrl}/marketing/getmarketingEmployee`)
            .then((response) => {
                setEmployee(response.data);
            })
            .catch((error) => {
                console.log("Error :", error);
            });
    }, []);

    const [reportData, setReportData] = useState([]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    }

    const handleReport = (e) => {
        e.preventDefault();
        axios.get(`${config.apiUrl}/marketing/markCustFilter?mark_cust_id=${formData.mark_cust_id}&emp_id=${formData.emp_id}&mark_cust_bus_name=${formData.mark_cust_bus_name}&category=${formData.category}&f_date=${formData.f_date}&t_date=${formData.t_date}`)
            .then((response) => {
                setReportData(response.data);
                
            })
            .catch((error) => {
                console.error("Error :", error);
            });
    }


  return (
    <div>
        <h1 className='text-center mt-3 mb-3'>Marketing Report</h1>
      <Grid container spacing={3}>
        <Grid item xs={6}>
            <TextField
            fullWidth
            select
            label ="Select Customer"
            name='mark_cust_id'
            value={formData.mark_cust_id}
            onChange={handleInputChange}
            >
                {customer.map((cust) =>(
                    <MenuItem key={cust.mark_cust_id} value={cust.mark_cust_id}>{cust.mark_cust_name}</MenuItem>
                ))}
            </TextField>
        </Grid>
        <Grid item xs={6}>
            <TextField 
            select 
            fullWidth
            label = "Select Employee"
            name = "emp_id"
            value={formData.emp_id}
            onChange={handleInputChange}
            >
                {employee.map((emp)=>(
                    <MenuItem key={emp.emp_id} value={emp.emp_id}>{emp.emp_name}</MenuItem>
                ))}
            </TextField>
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            select
            label ="Customer Bussiness"
            name='mark_cust_bus_name'
            value={formData.mark_cust_bus_name}
            onChange={handleInputChange}
            >
                {customer.map((cust) =>(
                    <MenuItem key={cust.mark_cust_bus_name} value={cust.mark_cust_bus_name}>{cust.mark_cust_bus_name}</MenuItem>
                ))}
            </TextField>
        </Grid>
        <Grid item xs={6}>
            <TextField 
            select
            fullWidth
            label = "Select Category"
            name = "category"
            onChange={handleInputChange}
            value={formData.category}
            >
                <MenuItem value="1">1st Priority</MenuItem>
                <MenuItem value="2">2nd Priority</MenuItem>
                <MenuItem value="3">3rd Priority</MenuItem>
                <MenuItem value="4">4th Priority</MenuItem>
            </TextField>
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label = "From Date"
            name = "f_date"
            InputLabelProps={{shrink:true}}
            type='date'
            onChange={handleInputChange}
            value={formData.f_date}
            />
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label = "To Date"
            name = "t_date"
            type='date'
            InputLabelProps={{shrink:true}}
            onChange={handleInputChange}
            value={formData.t_date}
            />
        </Grid>
        <Grid item xs={12} style={{ display: 'flex', justifyContent: 'center', marginTop: '10px' }}>
            <Button onClick={handleReport} variant='contained'>Generate Report</Button>
        </Grid>
      </Grid>

      <MarketingReportTable reportData={reportData} searchQuery={searchQuery}/>
    </div>
  )
}

export default MarketingReportForm
