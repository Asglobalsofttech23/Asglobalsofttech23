import React from 'react'
import TopNav from '../../TopNav/TopNav'
import SideNav from '../../SideNav/SideNav'
import SubModuleIndex from './SubModuleIndex'
function SubModuleIndexRouting() {
  return (
    <div style={{display:'flex',overflow:'hidden'}}>
      <SideNav/>
      <div style={{overflowY:'hidden',flexGrow:'1',marginLeft:'-20px'}}>
        <TopNav/>
     
        <div style={{marginLeft:'20px',marginRight:'20px'}}>
          <SubModuleIndex/>
        </div>
      </div>
    </div>
  )
}

export default SubModuleIndexRouting

