import { Button, Grid, MenuItem, TextField } from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";
import config from "../../../../config";
function AddSubModule({onClose}) {
  const [formData, setFormData] = useState({
    cust_id: "",
    pro_id: "",
    pro_name: "",
    pro_module_id: "",
    module_name: "",
    sub_module_name: "",
    sub_module_desc: "",
    start_date: "",
    end_date: "",
    selectedEmployee: [],
  });

  const [selectCustomer, setSelectCustomer] = useState([]);
  const [selectProject, setSelectProject] = useState([]);
  const [selectModule, setSelectModule] = useState([]);
  const [selectEmployee, setSelectEmployee] = useState([]);

  useEffect(() => {
    axios.get(`${config.apiUrl}/project/selectCustomer`)
      .then((response) => {
        setSelectCustomer(response.data);
      });
  }, []);

  // Select project
  useEffect(() => {
    axios.get(`${config.apiUrl}/project/cust_id?cust_id=${formData.cust_id}`)
      .then((response) => {
        setSelectProject(response.data);
      });
  }, [formData.cust_id]);

  //   select module

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/project/selectmodule?pro_id=${formData.pro_id}`)
      .then((response) => {
        setSelectModule(response.data);
      });
  }, [formData.pro_id]);

  // Select Employee
  useEffect(() => {
    axios
      .get(`${config.apiUrl}/project/selectModuleEmployee?pro_module_id=${formData.pro_module_id}`)
      .then((response) => {
        setSelectEmployee(response.data);
      });
  }, [formData.pro_module_id]);

  const handleSelectEmployee = (e) => {
    const selectedEmployeeIds = Array.isArray(e.target.value)
      ? e.target.value
      : [e.target.value];
    setFormData({ ...formData, selectedEmployee: selectedEmployeeIds });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post(`${config.apiUrl}/subModule/postSubmodule`, formData)
      .then((response) => {
        console.log("Successfully Added SubModule Data");
        onClose();
      });

    console.log(formData);
  };

  return (
    <div>
      <h1 className="text-center">Add Project Sub Modules</h1>
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <TextField
            fullWidth
            select
            label="Select Customer"
            name="cust_id"
            value={formData.cust_id}
            onChange={(e) =>
              setFormData({ ...formData, cust_id: e.target.value })
            }
          >
            <MenuItem value="">Select Customer</MenuItem>
            {selectCustomer.map((cust) => (
              <MenuItem key={cust.cust_id} value={cust.cust_id}>
                {cust.cust_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            select
            label="Select Project"
            name="pro_name"
            value={`${formData.pro_id}-${formData.pro_name}`}
            onChange={(e) => {
              const [selectProId, selectProName] = e.target.value.split("-");
              setFormData({
                ...formData,
                pro_id: selectProId,
                pro_name: selectProName,
              });
            }}
          >
            <MenuItem value="">Select Project</MenuItem>
            {selectProject.map((pro, index) => (
              <MenuItem key={index} value={`${pro.pro_id}-${pro.pro_name}`}>
                {pro.pro_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            select
            label="Select Module"
            name="module_name"
            value={`${formData.pro_module_id}-${formData.module_name}`}
            onChange={(e) => {
              const [selectModuleId, selectModuleName] =
                e.target.value.split("-");
              setFormData({
                ...formData,
                pro_module_id: selectModuleId,
                module_name: selectModuleName,
              });
            }}
          >
            <MenuItem value=""> Select module</MenuItem>
            {selectModule.map((mod) => (
              <MenuItem
                key={mod.pro_module_id}
                value={`${mod.pro_module_id}-${mod.module_name}`}
              >
                {mod.module_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Sub Module Name"
            name="sub_module_name"
            value={formData.sub_module_name}
            onChange={(e) =>
              setFormData({ ...formData, sub_module_name: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Start Date"
            name="start_date"
            type="date"
            InputLabelProps={{
              shrink: true,
            }}
            value={formData.start_date}
            onChange={(e) =>
              setFormData({ ...formData, start_date: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="End Date"
            name="end_date"
            type="date"
            InputLabelProps={{
              shrink: true,
            }}
            value={formData.end_date}
            onChange={(e) =>
              setFormData({ ...formData, end_date: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            fullWidth
            select
            label="Select Employees"
            name="selectedEmployee"
            value={formData.selectedEmployee}
            onChange={handleSelectEmployee}
            SelectProps={{
              multiple: true,
              renderValue: (selected) => {
                const selectedEmployeeIds = selectEmployee
                  .filter((emp) => selected.includes(emp.emp_id))
                  .map((emp) => emp.emp_name)
                  .join(", ");
                return selectedEmployeeIds;
              },
            }}
          >
            <MenuItem value="">Select Employees</MenuItem>
            {selectEmployee.map((emp) => (
              <MenuItem key={emp.emp_id} value={emp.emp_id}>
                {emp.emp_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Sub Module Description"
            name="sub_module_desc"
            value={formData.sub_module_desc}
            onChange={(e) =>
              setFormData({ ...formData, sub_module_desc: e.target.value })
            }
          />
        </Grid>
      </Grid>
      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "20px" }}
      >
        <Button onClick={handleSubmit}>Submit</Button>
      </div>
    </div>
  );
}

export default AddSubModule;
