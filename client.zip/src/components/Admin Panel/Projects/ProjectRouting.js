import React, { useState } from 'react'
import TopNav from '../TopNav/TopNav'
import SideNav from '../SideNav/SideNav'
import ProjectIndex from './ProjectIndex'
function ProjectRouting() {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchInputChange = (query) => {
    setSearchQuery(query);
  };
  return (
    <>
    <div style={{display:'flex',overflow:'hidden',minHeight:'700px'}}>
      <SideNav/>
      <div style={{overFlowY:'hidden',flexGrow:'1',marginLeft:'-20px'}}>
        <TopNav onSearchInputChange={handleSearchInputChange}/>
        <div style={{marginLeft:'20px',marginRight:'20px'}}>
          <ProjectIndex searchQuery={searchQuery}/>
        </div>
      </div>
    </div>
    </>
  )
}

export default ProjectRouting
