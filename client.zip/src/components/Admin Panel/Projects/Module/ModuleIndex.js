import React, { useEffect, useState } from "react";
import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Menu,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import axios from "axios";
import { format } from "date-fns";
import ProjectModules from "./ProjectModules";
import * as XLSX from "xlsx";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import UpdateModule from "./UpdateModule";
import config from "../../../../config";
function ModuleIndex() {
  const [moduleData, setModuleData] = useState([]);
  const [openDesc, setOpenDesc] = useState(false);
  const [selectedDesc, setSelectedDesc] = useState("");
  const [addNewModule, setAddNewModule] = useState(false);

  const handleOpenAddModule = () => {
    setAddNewModule(true);
  };
  const handleCloseAddModule = () => {
    setAddNewModule(false);
  };

  const handleOpenDesc = (desc) => {
    setSelectedDesc(desc);
    setOpenDesc(true);
  };

  const handleCloseDesc = () => {
    setOpenDesc(false);
  };

  useEffect(() => {
    axios.get(`${config.apiUrl}/module/getModuleData`)
      .then((response) => {
        setModuleData(response.data);
      })
      .catch((error) => {
        console.error("Error :", error);
      });
  });

  const [itemPerPage, setItemsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  const handleItemsPerPageChange = (e) => {
    const newItemPerPage = parseInt(e.target.value, 10);
    if (newItemPerPage === 0) {
      setItemsPerPage(moduleData.length);
    } else {
      setItemsPerPage(newItemPerPage);
      setCurrentPage(1);
    }
  };

  const indexOfLastItem = currentPage * itemPerPage;
  const indexOfFirstItem = indexOfLastItem - itemPerPage;
  const CurrentItems = moduleData.slice(indexOfFirstItem, indexOfLastItem);

  const [searchedVal, setSearchedVal] = useState("");

  const filterModule = (mod) => {
    const searchValue = searchedVal.toLocaleLowerCase();
    return (
      !searchedVal ||
      (mod.pro_name &&
        mod.pro_name.toString().toLowerCase().includes(searchValue)) ||
      (mod.module_name &&
        mod.module_name.toString().toLowerCase().includes(searchValue)) ||
      (mod.module_desc &&
        mod.module_desc.toString().toLowerCase().includes(searchValue)) ||
      (mod.emp_name &&
        mod.emp_name.toString().toLowerCase().includes(searchValue)) ||
      (mod.start_date &&
        mod.start_date.toString().toLowerCase().includes(searchValue)) ||
      (mod.end_date &&
        mod.end_date.toString().toLowerCase().includes(searchValue))
    );
  };

  // Select Check box
  const [selectedModule, setSelectedModule] = useState([]);
  const [selectAll, setSelectAll] = useState(false);


  const handleCheckboxChange = (moduleId) => {
    const selectedModuleIds = [...selectedModule];

    if (selectedModuleIds.includes(moduleId)) {
      const index = selectedModuleIds.indexOf(moduleId);
      selectedModuleIds.splice(index, 1);
    } else {
      selectedModuleIds.push(moduleId);
    }

    setSelectedModule(selectedModuleIds);
  };


  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedModule([]);
    } else {
      const allModuleIds = moduleData.map((mod) => mod.pro_module_id);
      setSelectedModule(allModuleIds);
    }
    setSelectAll(!selectAll);
  };

  const [anchorEl, setAnchorEl] = useState(null);

  const handleExport = (format) => {
    if (selectedModule.length === 0) {
      console.log("No Module selected for export");
      return;
    }

    switch (format) {
      case "CSV":
        exportToCSV();
        break;
      case "Excel":
        exportToExcel();
        break;
      case "JSON":
        exportToJSON();
        break;
      default:
        break;
    }
  };


  const exportToCSV = () => {
    if (selectedModule.length === 0) {
      console.log("No Module selected for export");
      return;
    }

    const selectedModuleData = moduleData.filter((mod) =>
    selectedModule.includes(mod.pro_module_id)
    );

    // Create CSV content
    const header = Object.keys(selectedModuleData[0]).join(",");
    const csv = [
      header,
      ...selectedModuleData.map((mod) =>
        Object.values(mod)
          .map((value) => `"${value}"`)
          .join(",")
      ),
    ].join("\n");

    // Create Blob for CSV file
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);

    // Download CSV file
    const a = document.createElement("a");
    a.href = url;
    a.download = "modules.csv";
    a.click();
    URL.revokeObjectURL(url);
  };


  const exportToExcel = () => {
    const selectedModuleData = moduleData.filter((mod) =>
    selectedModule.includes(mod.pro_module_id)
    );
    const worksheet = XLSX.utils.json_to_sheet(selectedModuleData);

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Modules");
    XLSX.writeFile(workbook, "modules.xlsx");
  };

  const exportToJSON = () => {
    const selectedModuleData = moduleData.filter((mod) =>
    selectedModule.includes(mod.pro_module_id)
    );

    const jsonData = JSON.stringify(selectedModuleData, null, 2);
    const blob = new Blob([jsonData], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "modules.json";
    a.click();
    URL.revokeObjectURL(url);
  };



  const [showSuccessMsg, setShowSuccessMsg] = useState(false);
  const showSuccessMessage = () => {
    setShowSuccessMsg(true);

    setTimeout(() => {
      setShowSuccessMsg(false);
    }, 3000); 
  };


  const [selectModuleEditData, setSelectModuleEditData] = useState(null);
  const [openEdit, setOpenEdit] = useState(false);

  const handleOpenEditModule = (mod) => {
    setSelectModuleEditData(mod);
    setOpenEdit(true);
  };

  const handleCloseEditModule = () => {
    setOpenEdit(false);
  };



  const [dltData,setDltData]= useState();
  const [openDltModal,setOpenDltModal] = useState(false);

  const handleDlt = (pro_module_id) =>{
    const selectedDltModuleId = moduleData.find((mod)=>mod.pro_module_id == pro_module_id)

    if(selectedDltModuleId){
      console.log("Id is ",selectedDltModuleId)
      setDltData(selectedDltModuleId);
      setOpenDltModal(true)
    }
  }

  


  const confirmDelete = () => {
    if (dltData) {
      axios
        .delete(`${config.apiUrl}/module/delete?pro_module_id=${dltData.pro_module_id}`)
        .then((response) => {
          console.log("Module Data Deleted Successfully", response);
          setOpenDltModal(false);
  
          // Remove the deleted module from moduleData state
          const updatedModuleData = moduleData.filter(
            (mod) => mod.pro_module_id !== dltData.pro_module_id
          );
          setModuleData(updatedModuleData); // Update state with the modified data
        })
        .catch((error) => {
          console.error("Module Data is Not Deleted", error);
        });
    }
  };

  const tableCellStyle = {
    border: '1px solid #ddd',
    padding: '8px', // Adjust padding as needed
    color:'white'
  };
  const tableCellStyleBody = {
    border: '1px solid #ddd',
    padding: '8px', // Adjust padding as needed
    color:'black'
  };
  
  const tableRowStyle = {
    border: '1px solid #ddd',
  };
  return (
    <div>
      <h1 className="text-center mt-2">Module Index</h1>

     <div style={{marginLeft:'40px'}}>
     <div className="row mt-5">
        <div className="col-3">
        
              <Button
                style={{
                  backgroundColor: "#1B9C85",
                  borderColor: "#1B9C85",
                  color: "white",
                }}
                onClick={(e) => setAnchorEl(e.currentTarget)}
              >
                Export data
              </Button>
              <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={() => setAnchorEl(null)}
              >
                <MenuItem onClick={() => handleExport("CSV")}>
                  Export as CSV
                </MenuItem>
                <MenuItem onClick={() => handleExport("Excel")}>
                  Export as Excel
                </MenuItem>
                <MenuItem onClick={() => handleExport("JSON")}>
                  Export as JSON
                </MenuItem>
              </Menu>
            </div>
       
        <div className="col-3">
          <TextField
            label="Search"
            onChange={(e) => setSearchedVal(e.target.value)}
            sx={{
              "& input": {
                height: "7px",
              },
            }}
          />
        </div>
        <div className="col-3">
          <div style={{ marginBottom: "20px", marginLeft: "100px" }}>
            <select
              // value={itemPerPage}
              onChange={handleItemsPerPageChange}
              style={{
                padding: "5px 10px",
                margin: "0 5px",
                border: "1px solid #007bff",
                borderRadius: "4px",
                cursor: "pointer",
                backgroundColor: "#fff",
                color: "#007bff",
                textDecoration: "none",
                transition: "background-color 0.3s, color 0.3s",
              }}
            >
              <option value="5">5 Per Page</option>
              <option value="10">10 Per Page</option>
              <option value="15">15 Per Page</option>
              <option value="0">All Per Page</option>
            </select>
          </div>
        </div>
        <div className="col-3">
          <Button onClick={handleOpenAddModule}>Add New Module</Button>
        </div>
      </div>
     </div>

      {moduleData.length > 0 ? (
        <>
          <TableContainer component={Paper} className="mt-4" style={{marginLeft:'10px',marginRight:'550px'}}>
            <Table>
              <TableHead style={{ backgroundColor: '#1B9C85'}}>
                <TableRow style={tableRowStyle}>
                <TableCell>
                    <Checkbox checked={selectAll} onChange={handleSelectAll} />
                  </TableCell>
                  <TableCell style={tableCellStyle}>S.No</TableCell>
                  <TableCell style={tableCellStyle}>Project Name</TableCell>
                  <TableCell style={tableCellStyle}>Module Name</TableCell>
                  <TableCell style={tableCellStyle}>Module Description</TableCell>
                  <TableCell style={tableCellStyle}>Employee Name</TableCell>
                  <TableCell style={tableCellStyle}>Start Date</TableCell>
                  <TableCell style={tableCellStyle}>End Date</TableCell>
                  <TableCell style={tableCellStyle}>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {CurrentItems .filter(filterModule) .map((mod, index) => (
                  <TableRow key={index} style={tableRowStyle}>
                     <TableCell>
                      <Checkbox
                        checked={selectedModule.includes(mod.pro_module_id)}
                        onChange={() => handleCheckboxChange(mod.pro_module_id)}
                      />
                    </TableCell>
                    <TableCell style={tableCellStyleBody}>{index + 1}</TableCell>
                    <TableCell style={tableCellStyleBody}>{mod.pro_name}</TableCell>
                    <TableCell style={tableCellStyleBody}>{mod.module_name}</TableCell>
                    <TableCell style={tableCellStyleBody}>
                      <Button onClick={() => handleOpenDesc(mod.module_desc)}>
                        Description
                      </Button>
                    </TableCell>
                    <TableCell style={tableCellStyleBody}>{mod.emp_name}</TableCell>
                    <TableCell style={tableCellStyleBody}>
                      {format(new Date(mod.start_date), "yyyy-MM-dd")}
                    </TableCell>
                    <TableCell style={tableCellStyleBody}>
                      {format(new Date(mod.end_date), "yyyy-MM-dd")}
                    </TableCell>
                    <TableCell style={tableCellStyleBody}>
                      <Button onClick={()=>handleOpenEditModule(mod)}>
                      <EditIcon />
                        Edite
                        </Button>
                      <Button onClick={()=>handleDlt(mod.pro_module_id)}>
                      <DeleteIcon style={{ color: 'red' }} />
                        Delete
                        </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <Dialog open={openDesc} onClose={handleCloseDesc}>
            <DialogTitle>Mdule Description</DialogTitle>
            <DialogContent>
              <p>{selectedDesc}</p>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseDesc}>Close</Button>
            </DialogActions>
          </Dialog>

          
        </>
      ) : (
        <div style={{height:'478px'}}>
          <div > <p className="text-center"> No Module Data Avilable</p></div>
        </div>
      )}

<Dialog open={addNewModule} onClose={handleCloseAddModule}>
            <DialogTitle>Add New Module</DialogTitle>
            <DialogContent>
              <ProjectModules onClose={handleCloseAddModule} />
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseAddModule}>Close</Button>
            </DialogActions>
          </Dialog>


          <Dialog open={openEdit} onClose={handleCloseEditModule} maxWidth="md">
            <DialogContent>
              {selectModuleEditData && (
                <UpdateModule
                  module={selectModuleEditData}
                  onClose={handleCloseEditModule}
                  showSuccessMessage={showSuccessMessage}
                />
              )}
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseEditModule}>Close</Button>
            </DialogActions>
          </Dialog>

          <Dialog
            open={showSuccessMsg}
            onClose={() => setShowSuccessMsg(false)}
            maxWidth="sm"
          >
            <DialogContent>
              <h3>Task Data Updated SuccessFully</h3>
            </DialogContent>
            <DialogActions>
              <Button onClose={() => setShowSuccessMsg(false)}>Close</Button>
            </DialogActions>
          </Dialog>


<Dialog open={openDltModal} onClose={()=>setOpenDltModal(false)}>
            <DialogTitle>Delete Confirmation Module</DialogTitle>
            <DialogContent>
            <div>
            <p>Are you sure you want to delete this employee?</p>
          </div>
            </DialogContent>
            <DialogActions>
            <Button
            variant="contained"
            onClick={confirmDelete}
            style={{ backgroundColor: "#DC143C", color: "white" }}
          >
            OK
          </Button>
          <Button
            variant="contained"
            onClick={() => setOpenDltModal(false)}
            style={{ backgroundColor: "#1B9C85", color: "white" }}
          >
            Cancel
          </Button>
            </DialogActions>
          </Dialog>
    </div>
  );
}

export default ModuleIndex;
