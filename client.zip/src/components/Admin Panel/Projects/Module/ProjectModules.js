import { Button, Grid, MenuItem, TextField } from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";
import config from "../../../../config";
function ProjectModules({onClose}) {
  const [formData, setFormData] = useState({
    cust_id: "",
    pro_id: "",
    pro_name: "",
    module_name: "",
    module_desc: "",
    start_date: "",
    end_date: "",
    selectedEmployees: [],
  });

  const [selectCustomer, setSelectCustomer] = useState([]);
  const [selectProject, setSelectProject] = useState([]);
  const [selectEmployee, setSelectEmployee] = useState([]);

  useEffect(() => {
    axios.get(`${config.apiUrl}/project/selectCustomer`)
      .then((response) => {
        setSelectCustomer(response.data);
      });
  }, []);

  useEffect(() => {
    axios.get(`${config.apiUrl}/project/cust_id?cust_id=${formData.cust_id}`)
      .then((response) => {
        setSelectProject(response.data);
      });
  }, [formData.cust_id]);

  useEffect(() => {
    axios.get(`${config.apiUrl}/project/projectEmployee?pro_id=${formData.pro_id}`)
      .then((response) => {
        setSelectEmployee(response.data);
      });
  }, [formData.pro_id]);

  const handleSelectEmployee = (event) => {
    const selectEmployeesId = Array.isArray(event.target.value)
      ? event.target.value
      : [event.target.value];
    setFormData({ ...formData, selectedEmployees: selectEmployeesId });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData); // Log formData here
    axios.post(`${config.apiUrl}/module/projectModule`, formData)
      .then((response) => {
        console.log("Successfully Added Project Data");
        onClose();
      })
      .catch((error) => {
        console.error("Error adding project data:", error); // Log the entire error object
      });
      
    
  };
  return (
    <>
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Select Customer"
            name="cust_id"
            value={formData.cust_id}
            onChange={(e) =>
              setFormData({ ...formData, cust_id: e.target.value })
            }
          >
            <MenuItem value="">Select Customer</MenuItem>
            {selectCustomer.map((cust) => (
              <MenuItem key={cust.cust_id} value={cust.cust_id}>
                {cust.cust_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Select Project"
            name="pro_name"
            value={`${formData.pro_id}-${formData.pro_name}`}
            onChange={(e) => {
              const [selectedProId, selectedProName] =
                e.target.value.split("-");
              setFormData({
                ...formData,
                pro_id: selectedProId,
                pro_name: selectedProName,
              });
            }}
          >
            <MenuItem value=""> Select Project</MenuItem>
            {selectProject.map((pro, index) => (
              <MenuItem key={index} value={`${pro.pro_id}-${pro.pro_name}`}>
                {pro.pro_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Module Name"
            name="module_name"
            value={formData.module_name}
            onChange={(e) =>
              setFormData({ ...formData, module_name: e.target.value })
            }
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Start Date"
            type="date"
            InputLabelProps={{
              shrink: true,
            }}
            name="start_date"
            value={formData.start_date}
            onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="End Date"
            name="end_date"
            type="date"
            value={formData.end_date}
            onChange={(e) =>
              setFormData({ ...formData, end_date: e.target.value })
            }
            InputLabelProps={{
              shrink: true,
            }}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Select Employee"
            name="selectedEmployees"
            value={formData.selectedEmployees}
            onChange={handleSelectEmployee}
            SelectProps={{
              multiple: true,
              renderValue: (selected) => {
                const selectedEmployeeNames = selectEmployee
                  .filter((emp) => selected.includes(emp.emp_id))
                  .map((emp) => emp.emp_name)
                  .join(", ");
                return selectedEmployeeNames; 
              },
            }}
          >
            <MenuItem value=""> Select Employee</MenuItem>
            {selectEmployee.map((emp) => (
              <MenuItem key={emp.emp_id} value={emp.emp_id}>
                {emp.emp_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={12}>
            <TextField
            fullWidth
            label="Module Description"
            name="module_desc"
            value={formData.module_desc}
            onChange={(e) => setFormData({...formData,module_desc:e.target.value})}
            />
        </Grid>
        
      </Grid>
      <div style={{display:'flex',justifyContent:'center'}}>
        <Button onClick={handleSubmit}> Submit</Button>
        </div>
    </>
  );
}

export default ProjectModules;
