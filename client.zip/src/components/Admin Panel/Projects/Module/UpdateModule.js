import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  MenuItem,
  TextField,
} from "@mui/material";
import axios from "axios";
import { format } from "date-fns";
import React, { useEffect, useState } from "react";
import config from "../../../../config";
function UpdateModule({ module,onClose,showSuccessMessage }) {
  const start_date = format(new Date(module.start_date), "yyyy-MM-dd");
  const end_date = format(new Date(module.end_date), "yyyy-MM-dd");

  const [updateModule, setUpdateModule] = useState({
    pro_id: module ? module.pro_id : "",
    pro_name: module ? module.pro_name : "",
    module_name: module ? module.module_name : "",
    module_desc: module ? module.module_desc : "",
    start_date: module ? start_date : "",
    end_date: module ? end_date : "",
    emp_id: module ? module.emp_id : "",
    emp_name: module ? module.emp_name : "",
  });

  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const [newlyFetchedEmployees, setNewlyFetchedEmployees] = useState([]);
  const [open, setOpen] = useState(false);
  const [errorModalOpen, setErrorModalOpen] = useState(false); // New state for error modal
  const [errorMessage, setErrorMessage] = useState(""); // State to store error message
  const [projectData, setProjectData] = useState("");
  const [successmsg , setSuccessMsg] = useState(false)

  useEffect(() => {
    axios.get(`${config.apiUrl}/module/getModuleEmp/${module.pro_module_id}`)
      .then((response) => {
        if (response.data && response.data.length > 0) {
          const employees = response.data.map((emp) => ({
            emp_id: emp.emp_id,
            emp_name: emp.emp_name,
          }));
          setSelectedEmployees(employees);
        }
      })
      .catch((error) => {
        console.error("Error fetching employee data:", error);
      });
  }, [module]);

  useEffect(() => {
    axios.get(`${config.apiUrl}/project/getProjectByProId/${module.pro_id}`)
      .then((response) => {
        if (response.data && response.data.length > 0) {
          setProjectData(response.data);
        }
      })
      .catch((error) => {
        console.error("Error fetching project data:", error);
      });
  }, [module.pro_id]);

  const projectStartDate = projectData.length > 0 ? projectData[0].start_date : "";
  const projectEndDate = projectData.length > 0 ? projectData[0].end_date : "";

  const handleAddEmployee = () => {
    axios
      .get(`${config.apiUrl}/project/projectEmployee?pro_id=${module.pro_id}`)
      .then((response) => {
        const selectableEmployees = response.data.filter(
          (employee) =>
            !selectedEmployees.some(
              (selected) => selected.emp_id === employee.emp_id
            )
        );
        if (selectableEmployees.length === 0) {
          setErrorMessage("All employees are already selected.");
          setErrorModalOpen(true);
        } else {
          setNewlyFetchedEmployees(selectableEmployees);
          setOpen(true);
        }
      })
      .catch((error) => {
        console.error("Error fetching selectable employees:", error);
      });
  };

 

  const handleEmployeeRemove = (empId) => {
    const updatedEmployees = selectedEmployees.filter(
      (employee) => employee.emp_id !== empId
    );

    // Update the selected employees and trigger validation
    setSelectedEmployees(updatedEmployees);

    // Trigger validation for the selectedEmployees field
    const errorMessage = validateField("selectedEmployees", updatedEmployees);

    // Update the errors state to display the error message in the TextField
    setErrors({ ...errors, selectedEmployees: errorMessage });
  };

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

 

  const [errors, setErrors] = useState({
    module_name: "",
    module_desc: "",
    start_date: "",
    end_date: "",
    selectedEmployees: "",
  });

  const validateField = (name, value) => {
    let errorMessage = "";

    switch (name) {
      case "module_name":
        if (!value.trim()) {
          errorMessage = "Module name cannot be empty.";
        }
        break;
      case "module_desc":
        if (!value.trim()) {
          errorMessage = "Module Description cannot be empty.";
        }
        break;
      case "start_date":
        if (!value.trim()) {
          errorMessage = "Task Start date cannot be empty.";
        }
        break;

      case "end_date":
        if (!value.trim()) {
          errorMessage = "Task End date cannot be empty.";
        }
        break;
      case "selectedEmployees":
        if (value.length === 0) {
          errorMessage = "Please select at least one employee.";
        }
        break;

      default:
        break;
    }

    return errorMessage;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    const errorMessage = validateField(name, value);

    setErrors({ ...errors, [name]: errorMessage });

    if (name === "selectedEmployees") {
      setSelectedEmployees(value);
      // Clear error message for selectedEmployees when selecting employees
      setErrors({ ...errors, selectedEmployees: "" });
    } else {
      setUpdateModule({ ...updateModule, [name]: value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();



    const errorValues = Object.values(errors);
    const hasErrors = errorValues.some((error) => !!error);

    
    const noEmployeesSelected = selectedEmployees.length === 0;

  if (hasErrors || noEmployeesSelected) {
    // Prevent submission when there are errors or no employees are selected
    setErrorMessage("Please resolve all errors and select at least one employee before submitting.");
    setErrorModalOpen(true);
    return;
  }


   
    const employeeIds = selectedEmployees.map((employee) => employee.emp_id);
    const employeeNames = selectedEmployees.map(
      (employee) => employee.emp_name
    );

   
    setUpdateModule({
      ...updateModule,
      emp_id: employeeIds,
      emp_name: employeeNames,
    });

    // Prepare the data for updating the task
    const updatedTaskData = {
      ...updateModule,
      emp_id: employeeIds, // Assigning the emp_id array
      emp_name: employeeNames, // Assigning the emp_name array
    };

    // Send PUT request to update the task
    axios
      .put(`${config.apiUrl}/module/updateModule/${module.pro_module_id}`,updatedTaskData)
      .then((response) => {
        console.log("Module updated successfully");
        onClose();
        showSuccessMessage();
      })
      .catch((error) => {
        console.error("Error updating Module:", error);
        // Handle error scenarios as needed
      });

    console.log(updatedTaskData);
  };

  return (
    <div>
      <h1 className="text-center">Update Module</h1>
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Module Name"
            name="module_name"
            value={updateModule.module_name}
            onChange={handleInputChange}
            error={!!errors.module_name} // Applying error state based on validation
            helperText={errors.module_name} // Displaying the error message
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Module Description"
            name="module_desc"
            value={updateModule.module_desc}
            onChange={handleInputChange}
            error={!!errors.module_desc} // Applying error state based on validation
            helperText={errors.module_desc} // Displaying the error message
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Start Date"
            name="start_date"
            type="date"
            value={updateModule.start_date}
            InputLabelProps={{
              shrink: true,
            }}
            inputProps={{
              min: projectStartDate,
              max: projectEndDate,
            }}
            onChange={handleInputChange}
            error={!!errors.start_date}
            helperText={errors.start_date}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="End Date"
            type="date"
            name="end_date"
            value={updateModule.end_date}
            InputLabelProps={{
              shrink: true,
            }}
            inputProps={{
              min: projectStartDate,
              max: projectEndDate,
            }}
            onChange={handleInputChange}
            error={!!errors.end_date}
            helperText={errors.end_date}
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Selected Employee"
            name="selectedEmployees"
            value={selectedEmployees.map((employee) => employee.emp_id)}
            open={open}
            onClose={handleClose}
            SelectProps={{
              multiple: true,
            }}
            error={!!errors.selectedEmployees}
            helperText={
              errors.selectedEmployees ? errors.selectedEmployees : ""
            }
          >
            {selectedEmployees.map((employee, index) => (
              <MenuItem
                key={index}
                value={employee.emp_id}
                onClick={() => handleEmployeeRemove(employee.emp_id)}
              >
                {employee.emp_name}
              </MenuItem>
            ))}
            {newlyFetchedEmployees.map((employee) => (
              <MenuItem
                key={employee.emp_id}
                value={employee.emp_id}
                onClick={() => {
                  setSelectedEmployees([...selectedEmployees, employee]);
                  setOpen(false); // Close the Select field after selecting a new employee
                  setNewlyFetchedEmployees([]); // Clear the newly fetched employees
                  // Clear error message for selectedEmployees when new employees are selected
                  setErrors({ ...errors, selectedEmployees: "" });
                }}
              >
                {employee.emp_name}
              </MenuItem>
            ))}
            <MenuItem onClick={handleAddEmployee}>Add Employee</MenuItem>
          </TextField>
        </Grid>
      </Grid>

      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "40px" }}
      >
        <Button variant="contained" color="primary" onClick={handleSubmit}>
          Submit
        </Button>
      </div>

      <Dialog open={errorModalOpen} onClose={() => setErrorModalOpen(false)}>
        <DialogTitle>Error</DialogTitle>
        <DialogContent>
          <DialogContentText>{errorMessage}</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setErrorModalOpen(false)} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default UpdateModule;


