import React, { useState } from 'react'
import SideNav from '../../SideNav/SideNav';
import TopNav from '../../TopNav/TopNav';
import ProjectEmployee from './ProjectEmployee';
import { useParams } from 'react-router-dom';

function ProjectEmployeeRouting() {
  const {proId} = useParams();
    const [searchQuery, setSearchQuery] = useState('');

    const handleSearchInputChange = (query) => {
      setSearchQuery(query);
    };
    return (
      <>
      <div style={{display:'flex',overflow:'hidden'}}>
        <SideNav/>
        <div style={{overFlowY:'hidden',flexGrow:'1',marginLeft:'-20px'}}>
          <TopNav onSearchInputChange={handleSearchInputChange}/>
          <div style={{marginLeft:'20px',marginRight:'20px'}}>
            <ProjectEmployee searchQuery={searchQuery} proId={proId}/>
          </div>
        </div>
      </div>
      </>
    )
  }

export default ProjectEmployeeRouting
