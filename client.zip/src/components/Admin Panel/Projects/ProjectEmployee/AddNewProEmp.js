import React, { useEffect, useState } from 'react';
import { Grid, TextField, Select, MenuItem, FormControl, InputLabel, Button } from '@mui/material';
import axios from 'axios';
import config from '../../../../config';
function AddNewProEmp({ proId ,onClose}) {
    const [projectData, setProjectData] = useState([]);
    const [employeeIds, setEmployeeIds] = useState([]);
    const [newEmployees, setNewEmployees] = useState([]);
    const [formData, setFormData] = useState({
        pro_id: proId,
        emp_id: [],
        pro_name: '',
        selectedEmployees: [],
        allocation_date: ''
    });



    

    useEffect(() => {
        axios.get(`${config.apiUrl}/project/getProjectEmployeeByProId?pro_id=${proId}`)
            .then((res) => {
                setProjectData(res.data);
                const empIds = res.data.map((item) => item.emp_id);
                setEmployeeIds(empIds);
            })
            .catch((error) => {
                console.error('Error fetching project data:', error);
            });
    }, [proId]);

    useEffect(() => {
        axios.get(`${config.apiUrl}/project/getEmpExceptIds`, {params: { employeeIds: JSON.stringify(employeeIds) },})
        .then((res) => {
            setNewEmployees(res.data)
        })
        .catch((error) => {
            console.error('Error fetching employee data:', error);
        });
    }, [employeeIds]);

    const findSelectedEmployeeNames = (selectedEmpIds) => {
        return selectedEmpIds.map((empId) => {
            const selectedEmployee = newEmployees.find((employee) => employee.emp_id === empId);
            return selectedEmployee ? selectedEmployee.emp_name : '';
        });
    };
    
    const handleSelectChange = (event) => {
        const selectedEmpIds = Array.isArray(event.target.value) ? event.target.value : [event.target.value];
        const selectedEmployeeNames = findSelectedEmployeeNames(selectedEmpIds);
        const isEmpNameEmpty = selectedEmployeeNames.some(name => name.trim() === '');
    
        setFormData({
            ...formData,
            emp_id: selectedEmpIds,
            selectedEmployees: selectedEmployeeNames,
            isEmpNameEmpty: isEmpNameEmpty,
        });
    };
    
    const handleAllocationDateChange = (event) => {
        const date = event.target.value;
        const isDateEmpty = date.trim() === '';
    
        setFormData({
            ...formData,
            allocation_date: date,
            isDateEmpty: isDateEmpty,
        });
    };
    const handleSubmit = () => {
        // Check if selected employees or allocation date is empty
        if (formData.emp_id.length === 0 || formData.allocation_date.trim() === '') {
            // You can show an alert or console.log to indicate the fields are empty
            console.log('Selected employees or allocation date cannot be empty.');
            return; // Prevent form submission
        }
    
        // Proceed with form submission if no empty fields
        const completeFormData = {
            ...formData,
            pro_name: projectData[0]?.pro_name || '',
        };
        
        axios.post(`${config.apiUrl}/project/addProjectEmployee`,completeFormData)
        .then((res) =>{
            onClose();
        })
        .catch((error) =>{
            console.error("Error:",error)
        })
    };
    

    return (
        <div>
            <h1 className='text-center'>Add Employee</h1>
            <Grid container spacing={3} className='mt-2'>
                <Grid item xs={6}>
                <TextField
    fullWidth
    label="Select Project"
    value={projectData[0]?.pro_name || ''}
    onChange={(e) => setFormData({...formData,pro_name:e.target.value})}
    disabled
/>

                </Grid>
                <Grid item xs={6}>
                    <FormControl fullWidth>
                        <InputLabel id="multiple-employees-label">Select Employees</InputLabel>
                        <Select
                            labelId="multiple-employees-label"
                            id="multiple-employees"
                            multiple
                            value={formData.emp_id}
                            onChange={handleSelectChange}
                            fullWidth
                        >
                            {newEmployees.map((employee) => (
                                <MenuItem key={employee.emp_id} value={employee.emp_id}>
                                    {employee.emp_name}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={6}>
                    <TextField
                        fullWidth
                        type="date"
                        label="Allocation Date"
                        value={formData.allocation_date}
                        onChange={handleAllocationDateChange}
                        InputLabelProps={{
                            shrink: true,
                        }}
                    />
                </Grid>
                <Grid item xs={6}>
                    <Button variant="contained" onClick={handleSubmit}>Submit</Button>
                </Grid>
            </Grid>
        </div>
    );
}

export default AddNewProEmp;
