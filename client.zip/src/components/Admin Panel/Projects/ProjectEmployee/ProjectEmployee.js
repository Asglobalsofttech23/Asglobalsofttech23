import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Menu,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import * as XLSX from "xlsx";
import ProEmpUpdateForm from "./ProEmpUpdateForm";
import ReactPaginate from "react-paginate";
import AddNewProEmp from "./AddNewProEmp";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import config from "../../../../config";
function ProjectEmployee({ searchQuery, proId }) {


  useEffect(() => {
    const highlightColor = 'black';
    const unhighlightColor = 'initial';
    const highlightBackground = 'yellow';
    const unhighlightBackground = 'white';
  
    const tableCells = document.querySelectorAll('td'); // Select all table cells or specific cells where you want to apply the highlight
  
    tableCells.forEach((cell) => {
      const cellText = cell.textContent;
      const searchQueryLC = searchQuery.toLowerCase();
      
      // Split the text content of the cell into parts based on the search query
      const parts = cellText.split(new RegExp(`(${searchQueryLC})`, 'gi'));
      
      // Recreate the inner HTML of the cell to highlight the matched parts
      cell.innerHTML = parts.map(part => {
        if (part.toLowerCase() === searchQueryLC) {
          return `<span style="color: ${highlightColor}; background-color: ${highlightBackground}">${part}</span>`;
        } else {
          return part;
        }
      }).join('');
    });
  }, [searchQuery]);

  const [projectEmployee, setProjectEmployee] = useState([]);

  
const [openAddNewEmpModal,setOpenAddNewModal] = useState(false)

const addNewEmp = () => {
  setOpenAddNewModal(true)
};

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/project/getProjectEmployeeByProId?pro_id=${proId}`)
      .then((res) => {
        setProjectEmployee(res.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  });

  const [itemPerPage, setItemPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  const handleItemPerPageChange = (e) => {
    const newItemPerPage = parseInt(e.target.value, 10);

    if (newItemPerPage === 0) {
      setItemPerPage(projectEmployee.length);
      setCurrentPage(1);
    } else {
      setItemPerPage(newItemPerPage);
      setCurrentPage(1);
    }
  };

  const indexOfLastItem = currentPage * itemPerPage;
  const indexOfFirstItem = indexOfLastItem - itemPerPage;
  const currentItem = projectEmployee.slice(indexOfFirstItem, indexOfLastItem);
  

  const [searchedVal, setSearchedVal] = useState("");

  const filterData = (proEmp) => {
    const searchValue = searchedVal.toLocaleLowerCase();
    return Object.values(proEmp).some(
      (value) => value && value.toString().toLowerCase().includes(searchValue)
    );
  };

  const [selectedEmployee, setSelectedEmployee] = useState([]);
  const [selectAll, setSelectAll] = useState(false);

  const handleCheckboxChange = (proEmp) => {
    const selectedEmployeeIds = [...selectedEmployee];
    if (selectedEmployeeIds.includes(proEmp)) {
      const index = selectedEmployeeIds.indexOf(proEmp);
      selectedEmployeeIds.splice(index, 1);
    } else {
      selectedEmployeeIds.push(proEmp);
    }
    setSelectedEmployee(selectedEmployeeIds);
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedEmployee([]);
    } else {
      const allempIds = projectEmployee.map((proEmp) => proEmp.pro_emp_id);
      setSelectedEmployee(allempIds);
    }
    setSelectAll(!selectAll);
  };

  const [anchorEl, setAnchorEl] = useState(null);

  const handleExport = (format) => {
    if (selectedEmployee.length === 0) {
      console.log("No Employee selected for export");
      return;
    }

    switch (format) {
      case "CSV":
        exportToCSV();
        break;
      case "Excel":
        exportToExcel();
        break;
      case "JSON":
        exportToJSON();
        break;
      default:
        break;
    }
  };

  const exportToCSV = () => {
    if (selectedEmployee.length === 0) {
      console.log("No Employee selected for export");
      return;
    }

    const selectedEmployeeData = projectEmployee.filter((proEmp) =>
      selectedEmployee.includes(proEmp.pro_emp_id)
    );

    // Create CSV content
    const header = Object.keys(selectedEmployeeData[0]).join(",");
    const csv = [
      header,
      ...selectedEmployeeData.map((proEmp) =>
        Object.values(proEmp)
          .map((value) => `"${value}"`)
          .join(",")
      ),
    ].join("\n");

    // Create Blob for CSV file
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);

    // Download CSV file
    const a = document.createElement("a");
    a.href = url;
    a.download = "project Employee.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportToExcel = () => {
    const selectedEmployeeData = projectEmployee.filter((proEmp) =>
      selectedEmployee.includes(proEmp.pro_emp_id)
    );
    const worksheet = XLSX.utils.json_to_sheet(selectedEmployeeData);

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Employees");
    XLSX.writeFile(workbook, "Project Employees.xlsx");
  };

  const exportToJSON = () => {
    const selectedEmployeeData = projectEmployee.filter((proEmp) =>
      selectedEmployee.includes(proEmp.pro_emp_id)
    );

    const jsonData = JSON.stringify(selectedEmployeeData, null, 2);
    const blob = new Blob([jsonData], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "Project Employee.json";
    a.click();
    URL.revokeObjectURL(url);
  };




  const [openEditModal,setOpenEditModal] = useState(false);
  const [SelectedEmployeeData,setSelectedEmployeeData] = useState()

  const handleOpenEditDialog = (pro_emp_id) =>{
    const selectedEmployee = projectEmployee.find((proEmp)=>proEmp.pro_emp_id === pro_emp_id);

    if(selectedEmployee){
      setSelectedEmployeeData(selectedEmployee);
      setOpenEditModal(true)
    }
  }

  const [openDltModal,setOpenDltModal] = useState(false)
  const [selectedDltData,setSelectedDltData] = useState()

  const handleOpenDltModal = (pro_emp_id) =>{
    const selectDeleteData = projectEmployee.find((proEmp)=>proEmp.pro_emp_id === pro_emp_id);

    if(selectDeleteData){
      setSelectedDltData(selectDeleteData)
      setOpenDltModal(true)
    }
  }

  const handleConfirmDlt = () => {
    axios
      .delete(`${config.apiUrl}/project/deleteEmployee/${selectedDltData.pro_emp_id}`)
      .then((res) => {
        console.log("Project Employee Deleted Successfully", res.data);
        setOpenDltModal(false); // Close the modal upon successful deletion
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  };
  

  

  return (
    <div style={{minHeight:'590px'}}>
      <div className="row mt-5">
        <div className="col-lg-3 col-md-3 col-sm-12">
          <Button
            style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}
            onClick={(e) => setAnchorEl(e.currentTarget)}
          >
            Export data
          </Button>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={() => setAnchorEl(null)}
          >
            <MenuItem onClick={() => handleExport("CSV")}>
              Export as CSV
            </MenuItem>
            <MenuItem onClick={() => handleExport("Excel")}>
              Export as Excel
            </MenuItem>
            <MenuItem onClick={() => handleExport("JSON")}>
              Export as JSON
            </MenuItem>
          </Menu>
        </div>
        <div className="col-lg-3 col-md-3 col-sm-12">
          <TextField
            label="Search"
            onChange={(e) => setSearchedVal(e.target.value)}
          />
        </div>
        <div className="col-lg-3 col-md-3 col-sm-12">
          <select
            value={itemPerPage}
            onChange={handleItemPerPageChange}
            style={{
              padding: "5px 10px",
              margin: "0 5px",
              border: "1px solid #007bff",
              borderRadius: "4px",
              cursor: "pointer",
              backgroundColor: "#fff",
              color: "#007bff",
              textDecoration: "none",
              transition: "background-color 0.3s, color 0.3s",
            }}
          >
            <option value="5">5 Per Page</option>
            <option value="10">10 Per Page</option>
            <option value="15">15 Per Page</option>
            <option value="0">All Per Page</option>
          </select>
        </div>
        <div className="col-lg-3 col-md-3 col-sm-3">
         <Button 
         onClick={addNewEmp}
         style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}>Add New Employee</Button>
        </div>
      </div>

      {projectEmployee.length > 0 ? (
        <>
          <TableContainer
            component={Paper}
            className="mt-4"
            style={{
              overflowX: "auto",
              maxWidth: "100%",
              width: "100%",
              display: "block",
            }}
          >
            <Table>
              <TableHead style={{ backgroundColor: "#1B9C85" }}>
                <TableRow>
                  <TableCell>
                    <Checkbox checked={selectAll} onChange={handleSelectAll} />
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    S.No
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Project Name
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Employee Name
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Allocation Date
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Progress
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Start Date
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    End Date
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Action
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {currentItem.filter(filterData).map((proEmp, index) => (
                  <>
                    <TableRow key={index + 1}>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        <Checkbox
                          checked={selectedEmployee.includes(proEmp.pro_emp_id)}
                          onChange={() =>
                            handleCheckboxChange(proEmp.pro_emp_id)
                          }
                        ></Checkbox>
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {index + 1}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {proEmp.pro_name}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {proEmp.emp_name}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {proEmp.allocation_date}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {proEmp.progress}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {proEmp.start_date}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {proEmp.end_date}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        <Button onClick={()=>handleOpenEditDialog(proEmp.pro_emp_id)}><EditIcon />Edit</Button>
                        <Button onClick={()=>handleOpenDltModal(proEmp.pro_emp_id)}>
                        <DeleteIcon style={{ color: 'red' }} />
                          Delete
                          </Button>
                      </TableCell>
                    </TableRow>
                  </>
                ))}
              </TableBody>
            </Table>
          </TableContainer>


          {/* Pagination */}
      <nav aria-label="Page navigation" className="text-center">
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
          <ReactPaginate
            previousLabel={
              <span
                style={{
                  padding: '5px 10px',
                  margin: '0 5px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: '#152445',
                  color: 'white',
                  textDecoration: 'underline',
                  textDecorationColor: '#152445',
                }}
              >
                Previous
              </span>
            }
            nextLabel={
              <span
                style={{
                  padding: '5px 10px',
                  margin: '0 5px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: '#152445',
                  color: 'white',
                  textDecoration: 'underline',
                  textDecorationColor: '#152445',
                }}
              >
                Next
              </span>
            }
            breakLabel={
              <span
                style={{
                  padding: '5px 10px',
                  margin: '0 5px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: '#fff',
                  color: '#333',
                  textDecoration: 'none',
                }}
              >
                ...
              </span>
            }
            pageCount={Math.ceil(projectEmployee.filter(filterData).length / itemPerPage)} // Use 'customers' instead of 'filteredCustomers'
            marginPagesDisplayed={2}
            pageRangeDisplayed={4}
            onPageChange={({ selected }) => setCurrentPage(selected + 1)}
            containerClassName={"pagination justify-content-center"}
            subContainerClassName={"pages pagination"}
            activeClassName={"active"}
          />
        </div>
      </nav>


          <Dialog open={openAddNewEmpModal} onClose={()=>setOpenAddNewModal(false)} maxWidth='xl'>
            {/* <DialogTitle className="text-center">Add New Employee</DialogTitle> */}
            <DialogContent>
              <AddNewProEmp proId= {proId} onClose={()=>setOpenAddNewModal(false)}/>
            </DialogContent>
            <DialogActions>
              <Button onClick={()=>setOpenAddNewModal(false)}>Close</Button>
            </DialogActions>
          </Dialog>

          <Dialog open={openEditModal} onClose={()=>setOpenEditModal(false)} maxWidth='md'>
            <DialogContent>
              <ProEmpUpdateForm selectedData= {SelectedEmployeeData} onClose={()=>setOpenEditModal(false)}/>
            </DialogContent>
            <DialogActions>
              <Button onClick={()=>setOpenEditModal(false)}>Close</Button>
            </DialogActions>
          </Dialog>



          <Dialog
        open={openDltModal}
        onClose={()=>setOpenDltModal(false)}
      >
        <DialogContent>
          <div>
            <p>Are you sure you want to delete this employee?</p>
          </div>
        </DialogContent>
        <DialogActions>
          <Button
            variant="contained"
            onClick={handleConfirmDlt}
            style={{ backgroundColor: "#DC143C", color: "white" }}
          >
            OK
          </Button>
          <Button
            variant="contained"
            onClick={() => setOpenDltModal(false)}
            style={{ backgroundColor: "#1B9C85", color: "white" }}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
        </>
      ) : (
        <></>
      )}
    </div>
  );
}

export default ProjectEmployee;
