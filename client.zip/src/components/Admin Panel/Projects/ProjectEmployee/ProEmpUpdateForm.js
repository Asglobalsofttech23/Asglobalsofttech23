import { Grid, TextField, Button } from '@mui/material';
import React, { useState } from 'react';
import axios from 'axios'
import { toast } from 'react-toastify';
import config from '../../../../config';
function ProEmpUpdateForm({ selectedData, onClose }) {
  const [updateData, setUpdateData] = useState({
    pro_name: selectedData ? selectedData.pro_name : "",
    start_date: selectedData ? selectedData.start_date : "",
    end_date: selectedData ? selectedData.end_date : "",
    emp_name: selectedData ? selectedData.emp_name : "",
    allocation_date: selectedData ? selectedData.allocation_date : "",
    progress: selectedData ? selectedData.progress : "",
    pro_emp_id: selectedData ? selectedData.pro_emp_id : ""
  });

  const handleChangeInput = (e) => {
    const {name,value}= e.target;
    setUpdateData({...updateData,[name]:value})
  };



  
  


  const handleUpdate = () => {
    const { pro_emp_id, progress, allocation_date } = updateData;
    const dataToUpdate = { progress, allocation_date };
  
    axios.put(`${config.apiUrl}/project/updeateProEmployee/${pro_emp_id}`, dataToUpdate)
      .then((response) => {
        console.log('Updated successfully:', response.data);
        onClose();
      })
      .catch((error) => {
        console.error('Error updating:', error);
      });
  };
  
  
  

  return (
    <div>
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <TextField
          fullWidth
            label="Project Name"
            value={updateData.pro_name}
            disabled
          />
        </Grid>
        
        <Grid item xs={6}>
          <TextField
          fullWidth
            label="Employee Name"
            value={updateData.emp_name}
            disabled
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
          fullWidth
            label="Progress"
            name="progress"
            value={updateData.progress}
            onChange={handleChangeInput}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
          fullWidth
            label="Allocation Date"
            type="date"
            name="allocation_date"
            value={updateData.allocation_date}
            onChange={handleChangeInput}
          />
        </Grid>
        <Grid item xs={12} style={{display:'flex',justifyContent:'center'}}>
          <Button variant="contained" color="primary" onClick={handleUpdate}>
            Update
          </Button>
        </Grid>
      </Grid>
    </div>
  );
}

export default ProEmpUpdateForm;
