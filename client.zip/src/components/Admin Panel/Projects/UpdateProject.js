import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Button, Grid, MenuItem, TextField } from '@mui/material';
import config from '../../../config';
function UpdateProject({ proData, updateProjectData, onClose }) {
    const [updateProject, setUpdateProject] = useState({
        cust_email: proData ? proData.cust_email : '', // Set to an empty string as the default value
        pro_name: proData ? proData.pro_name : '',
        pro_desc: proData ? proData.pro_desc : '',
        start_date: proData ? proData.start_date : '',
        end_date: proData ? proData.end_date : '',
    });

    const [errors, setErrors] = useState({
        cust_email:'',
        pro_name:'',
        pro_desc:'',
        start_date:'',
        end_date:''

    })

    const validateField = (name,value) =>{
        let errorMsg = "";
        const trimmedValue = value && typeof value === "string" ? value.trim() : value;
        switch(name){
            case "cust_email":
                if(!trimmedValue){
                    errorMsg="Customer Email is Required"  
                }
                break;
            case "pro_name":
                if(!trimmedValue){
                    errorMsg = "Project Name is Required"
                }
                break;
            case "pro_desc":
                if(!trimmedValue){
                    errorMsg = "Project Description is Required"
                }
                break;
            case "start_date":
                if(!trimmedValue){
                    errorMsg = "Project Start Date is Required"
                }
                break;
            case "end_date":
                if(!trimmedValue){
                    errorMsg = "Project End Date is Required"
                }
                break;
            default:
                break;
        }
        return errorMsg;
    }

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        const error = validateField(name,value);
        setUpdateProject({ ...updateProject, [name]: value });
        setErrors({...errors,[name]:error})
    };

    const handleUpdateProject = () => {


        const updatedErrors = {
            cust_email: validateField('cust_email', updateProject.cust_email),
            pro_name: validateField('pro_name', updateProject.pro_name),
            pro_desc: validateField('pro_desc', updateProject.pro_desc),
            start_date: validateField('start_date', updateProject.start_date),
            end_date: validateField('end_date', updateProject.end_date)
        };
    
        // Check if there are errors in any field
        if (Object.values(updatedErrors).some((error) => error !== '')) {
            setErrors(updatedErrors);
            return;
        }

        updateProjectData(proData.pro_id, updateProject);
        onClose();
    };

    const [customer, setCustomer] = useState([]);

    useEffect(() => {
       axios.get(`${config.apiUrl}/customers`)
            .then((response) => {
                setCustomer(response.data);
            })
            .catch((error) => {
                console.error('Error fetching data:', error);
            });
    }, []);

    return (
        <div>
            {proData ? (
                <div>
                    <Grid container spacing={3}>
                        <Grid item xs={6}>
                            <TextField
                                fullWidth
                                select
                                label="Customer Email"
                                name="cust_email"
                                value={updateProject.cust_email}
                                onChange={handleInputChange}
                                error={!!errors.cust_email}
                                helperText={errors.cust_email}
                            >
                                <MenuItem value="">Select Customer Email</MenuItem>
                                {customer.map((cust) => (
                                    <MenuItem key={cust.cust_id} value={cust.cust_email}>
                                        {cust.cust_email}
                                    </MenuItem>
                                ))}
                            </TextField>
                        </Grid>
                        <Grid item xs={6}>
                            <TextField
                            fullWidth
                                label="Project Name"
                                name="pro_name"
                                value={updateProject.pro_name}
                                onChange={handleInputChange}
                                error={!!errors.pro_name}
                                helperText={errors.pro_name}
                            />
                        </Grid>
                        <Grid item xs={6}>
                            <TextField
                            fullWidth
                                label="Start Date"
                                name="start_date"
                                type='date'
                                InputLabelProps={{shrink:true}}
                                value={updateProject.start_date}
                                onChange={handleInputChange}
                                error={!!errors.start_date}
                                helperText={errors.start_date}
                            />
                        </Grid>
                        <Grid item xs={6}>
                            <TextField
                            fullWidth
                                label="End Date"
                                name="end_date"
                                type='date'
                                InputLabelProps={{shrink:true}}
                                value={updateProject.end_date}
                                onChange={handleInputChange}
                                error={!!errors.end_date}
                                helperText={errors.end_date}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                            fullWidth
                                label="Project Description"
                                name="pro_desc"
                                value={updateProject.pro_desc}
                                onChange={handleInputChange}
                                error={!!errors.pro_desc}
                                helperText={errors.pro_desc}
                            />
                        </Grid>
                    </Grid>
                    <div style={{ display: 'flex', justifyContent: 'center', marginTop: '25px' }}>
                        <Button onClick={handleUpdateProject} style={{ backgroundColor: '#1B9C85', borderColor: '#1B9C85', color: 'white' }}>
                            Submit
                        </Button>
                    </div>
                </div>
            ) : (
                <>
                    <p>No Available Customer Data</p>
                </>
            )}
        </div>
    );
}

export default UpdateProject;