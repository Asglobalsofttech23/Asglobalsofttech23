import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Menu,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import { CSVLink } from "react-csv";
import * as XLSX from "xlsx";
import EditIcon from "@mui/icons-material/Edit";
import { debounce } from "lodash";
import ReactPaginate from "react-paginate";
import AddProject from "./AddProject";
import UpdateProject from "./UpdateProject";
import { format } from "date-fns";
import DeleteIcon from "@mui/icons-material/Delete";
import { MdGridView } from "react-icons/md";
import { FaArrowAltCircleRight } from "react-icons/fa";
import config from "../../../config";
function ProjectIndex({searchQuery}) {



  useEffect(() => {
    const highlightColor = 'black';
    const unhighlightColor = 'initial';
    const highlightBackground = 'yellow';
    const unhighlightBackground = 'white';
  
    const tableCells = document.querySelectorAll('td'); // Select all table cells or specific cells where you want to apply the highlight
  
    tableCells.forEach((cell) => {
      const cellText = cell.textContent;
      const searchQueryLC = searchQuery.toLowerCase();
      
      // Split the text content of the cell into parts based on the search query
      const parts = cellText.split(new RegExp(`(${searchQueryLC})`, 'gi'));
      
      // Recreate the inner HTML of the cell to highlight the matched parts
      cell.innerHTML = parts.map(part => {
        if (part.toLowerCase() === searchQueryLC) {
          return `<span style="color: ${highlightColor}; background-color: ${highlightBackground}">${part}</span>`;
        } else {
          return part;
        }
      }).join('');
    });
  }, [searchQuery]);


  const [project, setProject] = useState([]);

  const [selectedProjectDashboard, setSelectedProjectDashboard] =
    useState(null);

  const handleSelectedProjectDashboard = (pro) => {
    const selectedProject = project.find((pro) => pro.pro_id === pro.pro_id);

    if (selectedProject) {
      setSelectedProjectDashboard(selectedProject);
    }
  };

  useEffect(() => {
    axios.get(`${config.apiUrl}/project`)
      .then((response) => {
        setProject(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, );

  //   Select Data and export
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectAll, setSelectAll] = useState(false);

  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleRowSelect = (pro_id) => {
    const selectedIndex = selectedRows.indexOf(pro_id);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selectedRows, pro_id);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selectedRows.slice(1));
    } else if (selectedIndex === selectedRows.length - 1) {
      newSelected = newSelected.concat(selectedRows.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selectedRows.slice(0, selectedIndex),
        selectedRows.slice(selectedIndex + 1)
      );
    }

    setSelectedRows(newSelected);
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedRows([]);
    } else {
      const allProjectIds = project.map((pro) => pro.pro_id);
      setSelectedRows(allProjectIds);
    }
    setSelectAll(!selectAll);
  };

  // Export as CSV
  const handleCSVExport = () => {
    const csvData = project.map(
      (
        {
          pro_id,
          cust_name,
          cust_mobile,
          cust_email,
          bus_category,
          pro_name,
          pro_desc,
        },
        index
      ) => ({
        "S.no": index + 1,
        "Customer Name": cust_name,
        "Customer Mobile": cust_mobile,
        "Customer Email": cust_email,
        "Customer Business Category": bus_category,
        "Project Name": pro_name,
        "Project Description": pro_desc,
      })
    );

    const csvHeaders = [
      { label: "S.no", key: "S.no" },
      { label: "Customer Name", key: "Customer Name" },
      { label: "Customer Mobile", key: "Customer Mobile" },
      { label: "Customer Email", key: "Customer Email" },
      {
        label: "Customer Business Category",
        key: "Customer Business Category",
      },
      { label: "Project Name", key: "Project Name" },
      { label: "Project Description", key: "Project Description" },
    ];

    const csvFilename = "project_data.csv";

    // Example using react-csv
    // <CSVLink data={csvData} headers={csvHeaders} filename={csvFilename} className='btn btn-primary'>Export CSV</CSVLink>;
  };

  const handleExcelExport = () => {
    const excelData = project.map(
      (
        {
          pro_id,
          cust_name,
          cust_mobile,
          cust_email,
          bus_category,
          pro_name,
          pro_desc,
        },
        index
      ) => [
        index + 1,
        cust_name,
        cust_mobile,
        cust_email,
        bus_category,
        pro_name,
        pro_desc,
      ]
    );

    const ws = XLSX.utils.aoa_to_sheet([
      [
        "S.no",
        "Customer Name",
        "Customer Mobile",
        "Customer Email",
        "Customer Business Category",
        "Project Name",
        "Project Description",
      ],
      ...excelData,
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Sheet 1");
    XLSX.writeFile(wb, "project_data.xlsx");
  };

  const handleJSONExport = () => {
    const jsonData = JSON.stringify(project, null, 2); // The '2' parameter adds indentation for better readability
    const blob = new Blob([jsonData], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "project_data.json";
    link.click();
  };

  // Search
  const [searchedVal, setSearchedVal] = useState("");

  const filterProject = (pro) => {
    const searchValue = searchedVal.toLowerCase();
    return (
      !searchedVal ||
      (pro.cust_name &&
        pro.cust_name.toString().toLowerCase().includes(searchValue)) ||
      (pro.cust_mobile &&
        pro.cust_mobile.toString().toLowerCase().includes(searchValue)) ||
      (pro.cust_email &&
        pro.cust_email.toString().toLowerCase().includes(searchValue)) ||
      (pro.bus_category &&
        pro.bus_category.toString().toLowerCase().includes(searchValue)) ||
      (pro.pro_name &&
        pro.pro_name.toString().toLowerCase().includes(searchValue)) ||
      (pro.pro_desc &&
        pro.pro_desc.toString().toLowerCase().includes(searchValue)) ||
      (pro.start_date &&
        pro.start_date.toString().toLowerCase().includes(searchValue)) ||
      (pro.end_date &&
        pro.end_date.toString().toLowerCase().includes(searchValue))
    );
  };

  //   Pagination

  // Pagination
  const [itemsPerPage, setItemsPerPage] = useState(5); // Change the default value to 5
  const [currentPage, setCurrentPage] = useState(1);

  const handleItemsPerPageChange = (event) => {
    const newItemsPerPage = parseInt(event.target.value, 10);
    if (newItemsPerPage === 0) {
      setItemsPerPage(project.length);
      setCurrentPage(1);
    } else {
      setItemsPerPage(newItemsPerPage);
      setCurrentPage(1);
    }
  };
  

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = project.slice(indexOfFirstItem, indexOfLastItem);

  // Add New Project

  const [newProjectDialog, setNewProjectDialog] = useState(false);

  const handleOpenNewProjectDialog = () => {
    setNewProjectDialog(true);
  };

  const handleCloseNewProjectDialog = () => {
    setNewProjectDialog(false);
  };

  // Edit Customer Data
  const [selectedProjectData, setSelectedProjectData] = useState(null);
  const [openEditDialog, setOpenEditDialog] = useState(false);

  const updateProjectData = (proId, updatedData) => {
    axios.put(`${config.apiUrl}/project/${proId}`, updatedData)
      .then((response) => {
        console.log("Customer data updated successfully:", response.data);
      })
      .catch((error) => {
        console.error("Error updating Customer data:", error);
      });
  };

  const handleOpenEditDialog = (pro_id) => {
    const selectedProject = project.find((pro) => pro.pro_id === pro_id);

    if (selectedProject) {
      setSelectedProjectData(selectedProject);
      setOpenEditDialog(true);
    }
  };

  const handleCloseEditDialog = () => {
    setSelectedProjectData(null);
    setOpenEditDialog(false);
  };

  // Delete
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState(null);

  const handleDeleteProject = (pro_id) => {
    const selectedProject = project.find((pro) => pro.pro_id === pro_id);

    if (selectedProject) {
      setProjectToDelete(selectedProject);
      setOpenDeleteDialog(true);
    }
  };

  const confirmDelete = () => {
    // You can perform the delete operation here, e.g., make an API call to delete the Customer
    if (projectToDelete) {
      
      axios.delete(`${config.apiUrl}/project/${projectToDelete.pro_id}/delete`)

        .then((response) => {
          console.log("Project deleted successfully:", response.data);

          // You may want to fetch the updated data again

          setOpenDeleteDialog(false); // Close the confirmation dialog
        })
        .catch((error) => {
          console.error("Error deleting project:", error);
        });
    }
  };

  const [openDescDialog,setOpenDescDialog] = useState(false);
  const [description,setDescription] = useState();

  const handleDescription = (desc) =>{
    setDescription(desc)
    setOpenDescDialog(true)
  }
  return (
    <div>
      <h1 className="text-center">Project Index</h1>

      <div className="row">
        <div className="col-3">
          <Button
            style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}
            onClick={handleClick}
          >
            Export data
          </Button>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <MenuItem onClick={handleCSVExport}>Export as CSV</MenuItem>
            <MenuItem onClick={handleExcelExport}>Export as Excel</MenuItem>
            <MenuItem onClick={handleJSONExport}>Export as JSON</MenuItem>
          </Menu>
        </div>
        <div className="col-3">
          <TextField
            onChange={(e) => setSearchedVal(e.target.value)}
            label="Search"
            sx={{
              "& input": {
                height: "7px",
              },
            }}
          />
        </div>
        <div className="col-3">
          <div style={{ marginBottom: "20px"}}>
            <select
              value={itemsPerPage}
              onChange={handleItemsPerPageChange}
              style={{
                padding: "5px 10px",
                margin: "0 5px",
                border: "1px solid #007bff",
                borderRadius: "4px",
                cursor: "pointer",
                backgroundColor: "#fff",
                color: "#007bff",
                textDecoration: "none",
                transition: "background-color 0.3s, color 0.3s",
              }}
            >
              <option value="5">5 Per Page</option>
              <option value="10">10 Per Page</option>
              <option value="15">15 Per Page</option>
              <option value="0">All Per Page</option>
            </select>
          </div>
        </div>
        <div className="col-3">
          <Button
            style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}
            onClick={handleOpenNewProjectDialog}
          >
            Add New Project
          </Button>
        </div>
      </div>
      {project.length === 0 ? (
         <div style={{width:'179vh',height:'465px'}}>
        <p className="text-center">No projects available</p>
        </div>
      ) : (
        <>
          <TableContainer component={Paper} className="mt-2">
            <Table>
              <TableHead style={{ backgroundColor: "#1B9C85" }}>
                <TableRow>
                  <TableCell style={{ border: "1px solid #ddd" }}>
                    <Checkbox checked={selectAll} onChange={handleSelectAll} />
                  </TableCell>

                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    S.no
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Name
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Mobile
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Email
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                   Business Category
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Project Name
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Project Description
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Start Date
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    End Date
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Action
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {currentItems.filter(filterProject).map((pro, index) => (
                  <TableRow key={pro.pro_id}>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      <Checkbox
                        checked={selectedRows.includes(pro.pro_id)}
                        onChange={() => handleRowSelect(pro.pro_id)}
                      />
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {index + 1}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {pro.cust_name}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {pro.cust_mobile}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {pro.cust_email}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {pro.bus_category}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {pro.pro_name}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      <Button onClick={()=>handleDescription(pro.pro_desc)}>Description</Button>
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {pro.start_date ? (
                        <>
                          {/* {format(new Date(pro.start_date), "yyyy-MM-dd")} */}
                          {pro.start_date}
                        </>
                      ) : (
                        <>
                          <p>Project Start time Is not avilable</p>
                        </>
                      )}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {pro.end_date ? (
                        <>
                          {/* {format(new Date(pro.end_date), "yyyy-MM-dd")} */}
                          {pro.end_date}
                        </>
                      ) : (
                        <>
                          <p>Project End Date is not avilable</p>
                        </>
                      )}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      <Button onClick={() => handleOpenEditDialog(pro.pro_id)}>
                        <EditIcon />
                        Edit
                      </Button>
                      <Button onClick={() => handleDeleteProject(pro.pro_id)}>
                      <DeleteIcon style={{ color: 'red' }} />
                        Delete
                      </Button>
                      <Button style={{backgroundColor:'#00073D',color:'white'}}>
                      <FaArrowAltCircleRight size={30}/>
                      <Link to={`/projectEmployees/${pro.pro_id}`} style={{textDecoration:'none',color:'whitesmoke'}} >Employees</Link>
                      </Button>
                      <br/><br/>
                      <Button style={{backgroundColor:'#00073D',color:'white'}}>
                      <Link to={`/projectDashboard/${pro.pro_id}`} style={{textDecoration:'none',color:'whitesmoke'}} className="fa:dashboard">
                      
                   Dashboard
                        </Link>
                      </Button>
                     
                     
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </>
      )}

      <nav aria-label="Page navigation" className="text-center">
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            marginTop: "20px",
          }}
        >
          <ReactPaginate
            previousLabel={
              <span
                style={{
                  padding: "5px 10px",
                  margin: "0 5px",
                  border: "1px solid #ccc",
                  borderRadius: "4px",
                  cursor: "pointer",
                  backgroundColor: "#152445",
                  color: "white",
                  textDecoration: "underline",
                  textDecorationColor: "#152445",
                }}
              >
                Previous
              </span>
            }
            nextLabel={
              <span
                style={{
                  padding: "5px 10px",
                  margin: "0 5px",
                  border: "1px solid #ccc",
                  borderRadius: "4px",
                  cursor: "pointer",
                  backgroundColor: "#152445",
                  color: "white",
                  textDecoration: "underline",
                  textDecorationColor: "#152445",
                }}
              >
                Next
              </span>
            }
            breakLabel={
              <span
                style={{
                  padding: "5px 10px",
                  margin: "0 5px",
                  border: "1px solid #ccc",
                  borderRadius: "4px",
                  cursor: "pointer",
                  backgroundColor: "#fff",
                  color: "#333",
                  textDecoration: "none",
                }}
              >
                ...
              </span>
            }
            pageCount={Math.ceil(
              project.filter(filterProject).length / itemsPerPage
            )} // Use 'customers' instead of 'filteredCustomers'
            marginPagesDisplayed={2}
            pageRangeDisplayed={4}
            onPageChange={({ selected }) => setCurrentPage(selected + 1)}
            containerClassName={"pagination justify-content-center"}
            subContainerClassName={"pages pagination"}
            activeClassName={"active"}
          />
        </div>
      </nav>

      {/* Add New Project */}
      <Dialog open={newProjectDialog} onClose={handleCloseNewProjectDialog} maxWidth='lg'>
        <DialogContent>
          <AddProject  onClose={handleCloseNewProjectDialog}/>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseNewProjectDialog}> Close</Button>
        </DialogActions>
      </Dialog>

      {/* Edit Project */}

      <Dialog open={openEditDialog} onClose={handleCloseEditDialog}>
        <DialogContent>
          <UpdateProject
            proData={selectedProjectData}
            updateProjectData={updateProjectData}
            onClose={handleCloseEditDialog}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseEditDialog}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Delete project */}

      <Dialog
        open={openDeleteDialog}
        onClose={() => setOpenDeleteDialog(false)}
      >
        <DialogContent>
          <div>
            <p>Are you sure you want to delete this employee?</p>
          </div>
        </DialogContent>
        <DialogActions>
          <Button
            variant="contained"
            onClick={confirmDelete}
            style={{ backgroundColor: "#DC143C", color: "white" }}
          >
            OK
          </Button>
          <Button
            variant="contained"
            onClick={() => setOpenDeleteDialog(false)}
            style={{ backgroundColor: "#1B9C85", color: "white" }}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={openDescDialog} onClose={()=>setOpenDescDialog(false)}>
        <DialogTitle style={{backgroundColor:'blue',color:'whitesmoke'}} className="text-center">Description</DialogTitle>
        <DialogContent>
          <p>{description}</p>
        </DialogContent>
        <DialogActions>
          <Button onClick={()=>setOpenDescDialog(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default ProjectIndex;
