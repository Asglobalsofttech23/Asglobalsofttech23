import React from 'react'
import TopNav from '../../TopNav/TopNav'
import SideNav from '../../SideNav/SideNav'
import TaskIndex from './TaskIndex'

function TaskIndexRouting() {
  return (
    <div style={{display:'flex',overflow:'hidden'}}>
      <SideNav/>
      
        <div style={{overflowY:'hidden',flexGrow:'1',marginLeft:'-20px'}}>
          <TopNav/>
        
        <div style={{marginLeft:'20px',marginRight:'20px'}}>
          <TaskIndex/>
        </div>
        </div>
   
    </div>
  )
}

export default TaskIndexRouting
