import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Grid,
  MenuItem,
  TextField,
} from "@mui/material";
import axios from "axios";
import { format } from "date-fns";
import React, { useEffect, useState } from "react";
import config from "../../../../config";
function UpdateTask({ task,onClose,showSuccessMessage }) {
  const start_date = format(new Date(task.start_date), "yyyy-MM-dd");
  const end_date = format(new Date(task.end_date), "yyyy-MM-dd");

  const [updateTask, setUpdateTask] = useState({
    pro_id: task ? task.pro_id : "",
    pro_module_id: task ? task.pro_module_id : "",
    sub_mod_id: task ? task.sub_mod_id : "",
    task_id: task ? task.task_id : "",
    pro_name: task ? task.pro_name : "",
    module_name: task ? task.module_name : "",
    sub_module_name: task ? task.sub_module_name : "",
    task_name: task ? task.task_name : "",
    task_desc: task ? task.task_desc : "",
    start_date: task ? start_date : "",
    end_date: task ? end_date : "",
    emp_id: task ? task.emp_id : "",
    emp_name: task ? task.emp_name : "",
  });

  const [selectedEmployees, setSelectedEmployees] = useState([]);
  const [newlyFetchedEmployees, setNewlyFetchedEmployees] = useState([]);
  const [open, setOpen] = useState(false);
  const [errorModalOpen, setErrorModalOpen] = useState(false); // New state for error modal
  const [errorMessage, setErrorMessage] = useState(""); // State to store error message
  const [subModuledata, setSubModuleData] = useState("");
  const [successmsg , setSuccessMsg] = useState(false)

  useEffect(() => {
    axios.get(`${config.apiUrl}/task/getTaskEmp/${task.task_id}`)
      .then((response) => {
        if (response.data && response.data.length > 0) {
          const employees = response.data.map((emp) => ({
            emp_id: emp.emp_id,
            emp_name: emp.emp_name,
          }));
          setSelectedEmployees(employees);
        }
      })
      .catch((error) => {
        console.error("Error fetching employee data:", error);
      });
  }, [task]);

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/subModule/getSubModuleData/${task.sub_mod_id}`)
      .then((response) => {
        if (response.data && response.data.length > 0) {
          setSubModuleData(response.data);
        }
      })
      .catch((error) => {
        console.error("Error fetching submodule data:", error);
      });
  }, [task.sub_mod_id]);

  const subModuleStartDate =
    subModuledata.length > 0
      ? format(new Date(subModuledata[0].start_date), "yyyy-MM-dd")
      : "";
  const subModuleEndDate =
    subModuledata.length > 0
      ? format(new Date(subModuledata[0].end_date), "yyyy-MM-dd")
      : "";

  const handleAddEmployee = () => {
    axios.get(`${config.apiUrl}/project/selectSubmoduleEmployee?sub_mod_id=${task.sub_mod_id}`)
      .then((response) => {
        const selectableEmployees = response.data.filter(
          (employee) =>
            !selectedEmployees.some(
              (selected) => selected.emp_id === employee.emp_id
            )
        );
        if (selectableEmployees.length === 0) {
          setErrorMessage("All employees are already selected.");
          setErrorModalOpen(true);
        } else {
          setNewlyFetchedEmployees(selectableEmployees);
          setOpen(true);
        }
      })
      .catch((error) => {
        console.error("Error fetching selectable employees:", error);
      });
  };

  // const handleEmployeeRemove = (empId) => {
  //   const updatedEmployees = selectedEmployees.filter(
  //     (employee) => employee.emp_id !== empId
  //   );
  //   setSelectedEmployees(updatedEmployees);
  // };

  const handleEmployeeRemove = (empId) => {
    const updatedEmployees = selectedEmployees.filter(
      (employee) => employee.emp_id !== empId
    );

    // Update the selected employees and trigger validation
    setSelectedEmployees(updatedEmployees);

    // Trigger validation for the selectedEmployees field
    const errorMessage = validateField("selectedEmployees", updatedEmployees);

    // Update the errors state to display the error message in the TextField
    setErrors({ ...errors, selectedEmployees: errorMessage });
  };

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

 

  const [errors, setErrors] = useState({
    task_name: "",
    task_desc: "",
    start_date: "",
    end_date: "",
    selectedEmployees: "",
  });

  const validateField = (name, value) => {
    let errorMessage = "";

    switch (name) {
      case "task_name":
        if (!value.trim()) {
          errorMessage = "Task name cannot be empty.";
        }
        break;
      case "task_desc":
        if (!value.trim()) {
          errorMessage = "Task Description cannot be empty.";
        }
        break;
      case "start_date":
        if (!value.trim()) {
          errorMessage = "Task Start date cannot be empty.";
        }
        break;

      case "end_date":
        if (!value.trim()) {
          errorMessage = "Task End date cannot be empty.";
        }
        break;
      case "end_date":
        if (!value.trim()) {
          errorMessage = "Task End date cannot be empty.";
        }
        break;

      case "selectedEmployees":
        if (value.length === 0) {
          errorMessage = "Please select at least one employee.";
        }
        break;

      default:
        break;
    }

    return errorMessage;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    const errorMessage = validateField(name, value);

    setErrors({ ...errors, [name]: errorMessage });

    if (name === "selectedEmployees") {
      setSelectedEmployees(value);
      // Clear error message for selectedEmployees when selecting employees
      setErrors({ ...errors, selectedEmployees: "" });
    } else {
      setUpdateTask({ ...updateTask, [name]: value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();



    const errorValues = Object.values(errors);
    const hasErrors = errorValues.some((error) => !!error);

    
    const noEmployeesSelected = selectedEmployees.length === 0;

  if (hasErrors || noEmployeesSelected) {
    // Prevent submission when there are errors or no employees are selected
    setErrorMessage("Please resolve all errors and select at least one employee before submitting.");
    setErrorModalOpen(true);
    return;
  }


   
    const employeeIds = selectedEmployees.map((employee) => employee.emp_id);
    const employeeNames = selectedEmployees.map(
      (employee) => employee.emp_name
    );

    // Update the updateTask state with emp_id and emp_name arrays
    setUpdateTask({
      ...updateTask,
      emp_id: employeeIds,
      emp_name: employeeNames,
    });

    // Prepare the data for updating the task
    const updatedTaskData = {
      ...updateTask,
      emp_id: employeeIds, // Assigning the emp_id array
      emp_name: employeeNames, // Assigning the emp_name array
    };

    // Send PUT request to update the task
    axios
      .put(`${config.apiUrl}/task/updateTask/${task.task_id}`,updatedTaskData)
      .then((response) => {
        console.log("Task updated successfully");
        onClose();
        showSuccessMessage();
      })
      .catch((error) => {
        console.error("Error updating task:", error);
        // Handle error scenarios as needed
      });

    console.log(updatedTaskData);
  };

  return (
    <div>
      <h1 className="text-center">Update Task</h1>
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Task Name"
            name="task_name"
            value={updateTask.task_name}
            onChange={handleInputChange}
            error={!!errors.task_name} // Applying error state based on validation
            helperText={errors.task_name} // Displaying the error message
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Task Description"
            name="task_desc"
            value={updateTask.task_desc}
            onChange={handleInputChange}
            error={!!errors.task_desc} // Applying error state based on validation
            helperText={errors.task_desc} // Displaying the error message
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Start Date"
            name="start_date"
            type="date"
            value={updateTask.start_date}
            InputLabelProps={{
              shrink: true,
            }}
            inputProps={{
              min: subModuleStartDate,
              max: subModuleEndDate,
            }}
            onChange={handleInputChange}
            error={!!errors.start_date}
            helperText={errors.start_date}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="End Date"
            type="date"
            name="end_date"
            value={updateTask.end_date}
            InputLabelProps={{
              shrink: true,
            }}
            inputProps={{
              min: subModuleStartDate,
              max: subModuleEndDate,
            }}
            onChange={handleInputChange}
            error={!!errors.end_date}
            helperText={errors.end_date}
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Selected Employee"
            name="selectedEmployees"
            value={selectedEmployees.map((employee) => employee.emp_id)}
            open={open}
            onClose={handleClose}
            SelectProps={{
              multiple: true,
            }}
            error={!!errors.selectedEmployees}
            helperText={
              errors.selectedEmployees ? errors.selectedEmployees : ""
            }
          >
            {selectedEmployees.map((employee, index) => (
              <MenuItem
                key={index}
                value={employee.emp_id}
                onClick={() => handleEmployeeRemove(employee.emp_id)}
              >
                {employee.emp_name}
              </MenuItem>
            ))}
            {newlyFetchedEmployees.map((employee) => (
              <MenuItem
                key={employee.emp_id}
                value={employee.emp_id}
                onClick={() => {
                  setSelectedEmployees([...selectedEmployees, employee]);
                  setOpen(false); // Close the Select field after selecting a new employee
                  setNewlyFetchedEmployees([]); // Clear the newly fetched employees
                  // Clear error message for selectedEmployees when new employees are selected
                  setErrors({ ...errors, selectedEmployees: "" });
                }}
              >
                {employee.emp_name}
              </MenuItem>
            ))}
            <MenuItem onClick={handleAddEmployee}>Add Employee</MenuItem>
          </TextField>
        </Grid>
      </Grid>

      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "40px" }}
      >
        <Button variant="contained" color="primary" onClick={handleSubmit}>
          Submit
        </Button>
      </div>

      <Dialog open={errorModalOpen} onClose={() => setErrorModalOpen(false)}>
        <DialogTitle>Error</DialogTitle>
        <DialogContent>
          <DialogContentText>{errorMessage}</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setErrorModalOpen(false)} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default UpdateTask;

















// import {
//   Button,
//   Dialog,
//   DialogActions,
//   DialogContent,
//   DialogContentText,
//   DialogTitle,
//   Grid,
//   MenuItem,
//   TextField,
// } from "@mui/material";
// import axios from "axios";
// import { format } from "date-fns";
// import React, { useEffect, useState } from "react";

// function UpdateTask({ task }) {
//   const start_date = format(new Date(task.start_date), "yyyy-MM-dd");
//   const end_date = format(new Date(task.end_date), "yyyy-MM-dd");

//   const [updateTask, setUpdateTask] = useState({
//     pro_id: task ? task.pro_id : "",
//     pro_module_id: task ? task.pro_module_id : "",
//     sub_mod_id: task ? task.sub_mod_id : "",
//     task_id: task ? task.task_id : "",
//     pro_name: task ? task.pro_name : "",
//     module_name: task ? task.module_name : "",
//     sub_module_name: task ? task.sub_module_name : "",
//     task_name: task ? task.task_name : "",
//     task_desc: task ? task.task_desc : "",
//     start_date: task ? start_date : "",
//     end_date: task ? end_date : "",
//     emp_id: task ? task.emp_id : "",
//     emp_name: task ? task.emp_name : "",
//   });

//   const [selectedEmployees, setSelectedEmployees] = useState([]);
//   const [newlyFetchedEmployees, setNewlyFetchedEmployees] = useState([]);
//   const [open, setOpen] = useState(false);
//   const [errorModalOpen, setErrorModalOpen] = useState(false); // New state for error modal
//   const [errorMessage, setErrorMessage] = useState(""); // State to store error message
//   const [subModuledata, setSubModuleData] = useState("");

//   useEffect(() => {
//     axios
//       .get(`http://localhost:3001/task/getTaskEmp/${task.task_id}`)
//       .then((response) => {
//         if (response.data && response.data.length > 0) {
//           const employees = response.data.map((emp) => ({
//             emp_id: emp.emp_id,
//             emp_name: emp.emp_name,
//           }));
//           setSelectedEmployees(employees);
//         }
//       })
//       .catch((error) => {
//         console.error("Error fetching employee data:", error);
//       });
//   }, [task]);

//   useEffect(() => {
//     axios
//       .get(
//         `http://localhost:3001/subModule/getSubModuleData/${task.sub_mod_id}`
//       )
//       .then((response) => {
//         if (response.data && response.data.length > 0) {
//           setSubModuleData(response.data);
//         }
//       })
//       .catch((error) => {
//         console.error("Error fetching submodule data:", error);
//       });
//   }, [task.sub_mod_id]);

//   const subModuleStartDate =
//     subModuledata.length > 0
//       ? format(new Date(subModuledata[0].start_date), "yyyy-MM-dd")
//       : "";
//   const subModuleEndDate =
//     subModuledata.length > 0
//       ? format(new Date(subModuledata[0].end_date), "yyyy-MM-dd")
//       : "";

//   const handleAddEmployee = () => {
//     axios
//       .get(
//         `http://localhost:3001/project/selectSubmoduleEmployee?sub_mod_id=${task.sub_mod_id}`
//       )
//       .then((response) => {
//         const selectableEmployees = response.data.filter(
//           (employee) =>
//             !selectedEmployees.some(
//               (selected) => selected.emp_id === employee.emp_id
//             )
//         );
//         if (selectableEmployees.length === 0) {
//           setErrorMessage("All employees are already selected.");
//           setErrorModalOpen(true);
//         } else {
//           setNewlyFetchedEmployees(selectableEmployees);
//           setOpen(true);
//         }
//       })
//       .catch((error) => {
//         console.error("Error fetching selectable employees:", error);
//       });
//   };

//   const handleEmployeeRemove = (empId) => {
//     const updatedEmployees = selectedEmployees.filter(
//       (employee) => employee.emp_id !== empId
//     );
//     setSelectedEmployees(updatedEmployees);
//   };

//   const handleOpen = () => {
//     setOpen(true);
//   };

//   const handleClose = () => {
//     setOpen(false);
//   };

//   // const handleInputChange = (e) => {
//   //   const { name, value } = e.target;
//   //   setUpdateTask({ ...updateTask, [name]: value });
//   // };

//   const [errors, setErrors] = useState({
//     task_name: "",
//     // Add more fields here for error handling, if necessary
//   });

//   const validateTaskName = (value) => {
//     if (!value.trim()) {
//       return "Task name cannot be empty.";
//     }
//     return "";
//   };

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;

//     // Perform validation based on the field name
//     let errorMessage = "";

//     if (name === "task_name") {
//       errorMessage = validateTaskName(value);
//     }

//     // Update the specific field's error message in the errors state
//     setErrors({ ...errors, [name]: errorMessage });

//     // Update the state with the new value
//     setUpdateTask({ ...updateTask, [name]: value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();

//     // Extracting emp_id and emp_name from selectedEmployees
//     const employeeIds = selectedEmployees.map((employee) => employee.emp_id);
//     const employeeNames = selectedEmployees.map(
//       (employee) => employee.emp_name
//     );

//     // Update the updateTask state with emp_id and emp_name arrays
//     setUpdateTask({
//       ...updateTask,
//       emp_id: employeeIds,
//       emp_name: employeeNames,
//     });

//     // Prepare the data for updating the task
//     const updatedTaskData = {
//       ...updateTask,
//       emp_id: employeeIds, // Assigning the emp_id array
//       emp_name: employeeNames, // Assigning the emp_name array
//     };

//     // Send PUT request to update the task
//     axios
//       .put(
//         `http://localhost:3001/task/updateTask/${task.task_id}`,
//         updatedTaskData
//       )
//       .then((response) => {
//         console.log("Task updated successfully");
//       })
//       .catch((error) => {
//         console.error("Error updating task:", error);
//         // Handle error scenarios as needed
//       });

//     console.log(updatedTaskData);
//   };

//   return (
//     <div>
//       <h1 className="text-center">Update Task</h1>
//       <Grid container spacing={3}>
//         <Grid item xs={6}>
//           <TextField
//             fullWidth
//             label="Task Name"
//             name="task_name"
//             value={updateTask.task_name}
//             onChange={handleInputChange}
//             error={!!errors.task_name} // Applying error state based on validation
//             helperText={errors.task_name} // Displaying the error message
//           />
//         </Grid>

//         <Grid item xs={6}>
//           <TextField
//             fullWidth
//             label="Task Description"
//             name="task_desc"
//             value={updateTask.task_desc}
//             onChange={handleInputChange}
//           />
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             fullWidth
//             label="Start Date"
//             name="start_date"
//             type="date"
//             value={updateTask.start_date}
//             InputLabelProps={{
//               shrink: true,
//             }}
//             inputProps={{
//               min: subModuleStartDate,
//               max: subModuleEndDate,
//             }}
//             onChange={handleInputChange}
//           />
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             fullWidth
//             label="End Date"
//             type="date"
//             name="end_date"
//             value={updateTask.end_date}
//             InputLabelProps={{
//               shrink: true,
//             }}
//             inputProps={{
//               min: subModuleStartDate,
//               max: subModuleEndDate,
//             }}
//             onChange={handleInputChange}
//           />
//         </Grid>

//         <Grid item xs={6}>
//           <TextField
//             select
//             fullWidth
//             label="Selected Employee"
//             value={selectedEmployees.map((employee) => employee.emp_id)}
//             open={open}
//             onClose={handleClose}
//             SelectProps={{
//               multiple: true,
//             }}
//           >
//             {selectedEmployees.map((employee, index) => (
//               <MenuItem
//                 key={index}
//                 value={employee.emp_id}
//                 onClick={() => handleEmployeeRemove(employee.emp_id)}
//               >
//                 {employee.emp_name}
//               </MenuItem>
//             ))}
//             {newlyFetchedEmployees.map((employee) => (
//               <MenuItem
//                 key={employee.emp_id}
//                 value={employee.emp_id}
//                 onClick={() => {
//                   setSelectedEmployees([...selectedEmployees, employee]);
//                   setOpen(false); // Close the Select field after selecting a new employee
//                   setNewlyFetchedEmployees([]); // Clear the newly fetched employees
//                 }}
//               >
//                 {employee.emp_name}
//               </MenuItem>
//             ))}
//             <MenuItem onClick={handleAddEmployee}>Add Employee</MenuItem>
//           </TextField>
//         </Grid>
//       </Grid>

//       <div
//         style={{ display: "flex", justifyContent: "center", marginTop: "40px" }}
//       >
//         <Button variant="contained" color="primary" onClick={handleSubmit}>
//           Submit
//         </Button>
//       </div>

//       <Dialog open={errorModalOpen} onClose={() => setErrorModalOpen(false)}>
//         <DialogTitle>Error</DialogTitle>
//         <DialogContent>
//           <DialogContentText>{errorMessage}</DialogContentText>
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={() => setErrorModalOpen(false)} color="primary">
//             Close
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </div>
//   );
// }

// export default UpdateTask;
