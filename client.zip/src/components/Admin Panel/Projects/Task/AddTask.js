import React, { useEffect, useState } from "react";
import { Grid, MenuItem, TextField } from "@mui/material";
import axios from "axios";
import { format } from "date-fns";
import config from "../../../../config";
function AddTask({onClose,handleShowNewTaskSuccesMsg}) {
  const [formData, setFormData] = useState({
    cust_id: "",
    pro_id: "",
    pro_module_id: "",
    sub_mod_id: "",
    pro_name: "",
    module_name: "",
    sub_module_name: "",
    task_name: "",
    task_desc: "",
    start_date: "",
    end_date: "",
    selectedEmployee: [],
  });

  const [selectCustomer, setSelectCustomer] = useState([]);
  const [selectProject, setSelectProject] = useState([]);
  const [selectModule, setSelectModule] = useState([]);
  const [selectSubModule, setSelectSubModule] = useState([]);
  const [selectEmployee, setSelectEmployee] = useState([]);

  const [subModuledata, setSubModuleData] = useState("");

  useEffect(() => {
    axios.get(`${config.apiUrl}/project/selectCustomer`)
      .then((response) => {
        setSelectCustomer(response.data);
      });
  }, []);

  useEffect(() => {
    axios.get(`${config.apiUrl}/project/cust_id?cust_id=${formData.cust_id}`)
      .then((response) => {
        setSelectProject(response.data);
      });
  }, [formData.cust_id]);

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/project/selectmodule?pro_id=${formData.pro_id}`)
      .then((response) => {
        setSelectModule(response.data);
      });
  }, [formData.pro_id]);

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/project/selectSubModule?pro_module_id=${formData.pro_module_id}`)
      .then((response) => {
        setSelectSubModule(response.data);
      });
  }, [formData.pro_module_id]);

  useEffect(() => {
    axios.get(`${config.apiUrl}/project/selectSubmoduleEmployee?sub_mod_id=${formData.sub_mod_id}`)
      .then((response) => {
        setSelectEmployee(response.data);
      });
  }, [formData.sub_mod_id]);

  // Date
  useEffect(() => {
    axios
      .get(`${config.apiUrl}/subModule/getSubModuleData/${formData.sub_mod_id}`)
      .then((response) => {
        if (response.data && response.data.length > 0) {
          setSubModuleData(response.data);
        }
      })
      .catch((error) => {
        console.error("Error fetching submodule data:", error);
      });
  }, [formData.sub_mod_id]);

  const subModuleStartDate =
    subModuledata.length > 0
      ? format(new Date(subModuledata[0].start_date), "yyyy-MM-dd")
      : "";
  const subModuleEndDate =
    subModuledata.length > 0
      ? format(new Date(subModuledata[0].end_date), "yyyy-MM-dd")
      : "";

  const handleSelectEmployee = (e) => {
    const selectEmployeeIds = Array.isArray(e.target.value)
      ? e.target.value
      : [e.target.value];
    setFormData({ ...formData, selectedEmployee: selectEmployeeIds });
    setErrors({
      ...errors,
      selectedEmployee:
        selectEmployeeIds.length > 0
          ? ""
          : "Please Atleast Select one Employee.",
    });
  };

  const [errors, setErrors] = useState({
    cust_id: "",
    pro_id: "",
    pro_module_id: "",
    sub_mod_id: "",
    task_name: "",
    task_desc: "",
    start_date: "",
    end_date: "",
    selectedEmployee: "",
  });

  const ValidateField = (name, value) => {
    let errorMsg = "";
    const trimmedValue =
      value && typeof value === "string" ? value.trim() : value; // Check if value is a string before trimming

    switch (name) {
      case "cust_id":
        if (!trimmedValue) {
          errorMsg = "Please Select one Customer.";
        }
        break;
      case "pro_id":
        if (!trimmedValue) {
          errorMsg = "Please Select one Project.";
        }
        break;
      case "pro_module_id":
        if (!trimmedValue) {
          errorMsg = "Please Select one Module.";
        }
        break;
      case "sub_mod_id":
        if (!trimmedValue) {
          errorMsg = "Please Select one Sub Module.";
        }
        break;
      case "task_name":
        if (!trimmedValue) {
          errorMsg = "Task Name cannot be empty";
        }
        break;
      case "task_desc":
        if (!trimmedValue) {
          errorMsg = "Task Description cannot be empty.";
        }
        break;
      case "start_date":
        if (!trimmedValue) {
          errorMsg = "Task Start date Cannot be empty.";
        } else if (new Date(trimmedValue) < new Date(subModuleStartDate)) {
          errorMsg = "Start date must be on or after Sub Module Start Date.";
        } else if (new Date(trimmedValue) > new Date(subModuleEndDate)) {
          errorMsg = "Start date must be on or before Sub Module End Date.";
        }
        break;

      case "end_date":
        if (!trimmedValue) {
          errorMsg = "Task End Date cannot be empty";
        } else if (new Date(trimmedValue) < new Date(subModuleStartDate)) {
          errorMsg = "End date must be on or after Sub Module Start Date.";
        } else if (new Date(trimmedValue) > new Date(subModuleEndDate)) {
          errorMsg = "End date must be on or before Sub Module End Date.";
        } else if (new Date(trimmedValue) < new Date(formData.start_date)) {
          errorMsg = "End date cannot be before Start date.";
        }
        break;
      case "selectedEmployee":
        if (!Array.isArray(trimmedValue) || trimmedValue.length === 0) {
          errorMsg = "Please Atleast Select one Employee.";
        }
        break;
      default:
        break;
    }
    return errorMsg;
  };

  const handleValidation = () => {
    let newErrors = {
      cust_id: ValidateField("cust_id", formData.cust_id),
      pro_id: ValidateField("pro_id", formData.pro_id),
      pro_module_id: ValidateField("pro_module_id", formData.pro_module_id),
      sub_mod_id: ValidateField("sub_mod_id", formData.sub_mod_id),
      task_name: ValidateField("task_name", formData.task_name),
      task_desc: ValidateField("task_desc", formData.task_desc),
      start_date: ValidateField("start_date", formData.start_date),
      end_date: ValidateField("end_date", formData.end_date),
      selectedEmployee: ValidateField(
        "selectedEmployee",
        formData.selectedEmployee
      ),
    };

    setErrors(newErrors);

    // Check if any field has an error
    return Object.values(newErrors).some((error) => error !== "");
  };

  const handleSelectCustomer = (e) => {
    const selectedCustomerId = e.target.value;
    setFormData({ ...formData, cust_id: selectedCustomerId });
    setErrors({ ...errors, cust_id: "" });
  };

  const handleSelectProject = (e) => {
    const [selectProId, selectProName] = e.target.value.split("-");
    setFormData({ ...formData, pro_id: selectProId, pro_name: selectProName });
    setErrors({ ...errors, pro_id: "" });
  };

  const handleSelectModule = (e) => {
    const [selectModuleId, selectModuleName] = e.target.value.split("-");
    setFormData({
      ...formData,
      pro_module_id: selectModuleId,
      module_name: selectModuleName,
    });
    setErrors({ ...errors, pro_module_id: "" });
  };

  const handleSelectSubModule = (e) => {
    const [selectSubModuleId, selectSubModuleName] = e.target.value.split("-");
    setFormData({
      ...formData,
      sub_mod_id: selectSubModuleId,
      sub_module_name: selectSubModuleName,
    });
    setErrors({ ...errors, sub_mod_id: "" });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;

    let errorMsg = ValidateField(
      name,
      value,
      subModuleStartDate,
      subModuleEndDate
    );

    setFormData({ ...formData, [name]: value });

    setErrors({ ...errors, [name]: errorMsg });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (handleValidation()) {
      // If there are errors, prevent form submission
      console.error("Form has errors. Cannot submit.");
      return;
    }

    // Form submission logic
    axios.post(`${config.apiUrl}/task/postTask`, formData)
      .then((response) => {
        console.log("Task and their Employee Data added Successfully");
        console.log(formData);
        onClose();
        handleShowNewTaskSuccesMsg();
      })
      .catch((error) => {
        console.error("Task and Their Employee data is not added");
      });
  };

  return (
    <div className="mt-3">
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Select Customer"
            name="cust_id"
            value={formData.cust_id}
            onChange={handleSelectCustomer}
            error={!!errors.cust_id}
            helperText={errors.cust_id}
          >
            <MenuItem value="">Select Customer</MenuItem>
            {selectCustomer.map((cust) => (
              <MenuItem key={cust.cust_id} value={cust.cust_id}>
                {cust.cust_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Select Project"
            name="pro_id"
            value={`${formData.pro_id}-${formData.pro_name}`}
            onChange={handleSelectProject}
            error={!!errors.pro_id}
            helperText={errors.pro_id}
          >
            <MenuItem value="">Select Project</MenuItem>
            {selectProject.map((pro) => (
              <MenuItem
                key={pro.pro_id}
                value={`${pro.pro_id}-${pro.pro_name}`}
              >
                {pro.pro_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="select Module"
            name="pro_module_id"
            value={`${formData.pro_module_id}-${formData.module_name}`}
            onChange={handleSelectModule}
            error={!!errors.pro_module_id}
            helperText={errors.pro_module_id}
          >
            <MenuItem value="">Select Module</MenuItem>
            {selectModule.map((module) => (
              <MenuItem
                key={module.pro_module_id}
                value={`${module.pro_module_id}-${module.module_name}`}
              >
                {module.module_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Select sub Module"
            name="sub_mod_id"
            value={`${formData.sub_mod_id}-${formData.sub_module_name}`}
            onChange={handleSelectSubModule}
            error={!!errors.sub_mod_id}
            helperText={errors.sub_mod_id}
          >
            <MenuItem value=""> Select Sub Module</MenuItem>
            {selectSubModule.map((subMod) => (
              <MenuItem
                key={subMod.sub_mod_id}
                value={`${subMod.sub_mod_id}-${subMod.sub_module_name}`}
              >
                {subMod.sub_module_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Task Name"
            name="task_name"
            value={formData.task_name}
            onChange={handleInputChange}
            error={!!errors.task_name}
            helperText={errors.task_name}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Task Description"
            name="task_desc"
            value={formData.task_desc}
            onChange={handleInputChange}
            error={!!errors.task_desc}
            helperText={errors.task_desc}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Start Date"
            name="start_date"
            type="date"
            value={formData.start_date}
            onChange={handleInputChange}
            
            InputLabelProps={{
              shrink: true,
            }}
            InputProps={{
              inputProps: {
                min: subModuleStartDate,
                max: subModuleEndDate,
              },
            }}
            error={!!errors.start_date}
            helperText={errors.start_date}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="End Date"
            name="end_date"
            type="date"
            value={formData.end_date}
            onChange={handleInputChange}
            InputLabelProps={{
              shrink: true,
            }}
            InputProps={{
              inputProps: {
                min: subModuleStartDate,
                max: subModuleEndDate,
              },
            }}
            error={!!errors.end_date}
            helperText={errors.end_date}
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Select Employee"
            name="selectedEmployee"
            value={formData.selectedEmployee}
            onChange={handleSelectEmployee}
            SelectProps={{
              multiple: true,
              renderValue: (selected) => {
                const selectedEmployeeIds = selectEmployee
                  .filter((emp) => selected.includes(emp.emp_id))
                  .map((emp) => emp.emp_name)
                  .join(",");
                return selectedEmployeeIds;
              },
            }}
            error={!!errors.selectedEmployee}
            helperText={errors.selectedEmployee}
          >
            <MenuItem value="">Select Employees</MenuItem>
            {selectEmployee.map((emp) => (
              <MenuItem key={emp.emp_id} value={emp.emp_id}>
                {emp.emp_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
      </Grid>
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}

export default AddTask;
