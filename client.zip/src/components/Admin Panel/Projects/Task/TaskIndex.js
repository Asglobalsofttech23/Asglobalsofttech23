import axios from "axios";
import React, { useEffect, useState } from "react";
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Checkbox,
  Button,
  Menu,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
} from "@mui/material";
import { CSVLink } from "react-csv";
import * as XLSX from "xlsx";
import { format } from "date-fns";
import UpdateTask from "./UpdateTask";
import AddTask from "./AddTask";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import config from "../../../../config";
function TaskIndex() {
  const [taskData, setTaskData] = useState([]);
  const [selectedTasks, setSelectedTasks] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [showSuccessMsg, setShowSuccessMsg] = useState(false);

  const [openNewTaskSuccessMsg,setOpenNewTaskSuccessMsg] = useState(false)
  const [openNewTask,setOpenNewTask] = useState(false)

  const handleShowNewTaskSuccesMsg = () =>{
    setOpenNewTaskSuccessMsg(true);

    setTimeout(() =>{
      setOpenNewTaskSuccessMsg(false);
    },3000)

  }

  

  const showSuccessMessage = () => {
    setShowSuccessMsg(true);

    setTimeout(() => {
      setShowSuccessMsg(false);
    }, 3000); 
  };

  useEffect(() => {
    axios.get(`${config.apiUrl}/task/getTaskData`)
      .then((response) => {
        setTaskData(response.data);
      })
      .catch((error) => {
        console.error("Error fetching task data:", error);
      });
  }, [showSuccessMsg,openNewTaskSuccessMsg]);

  const handleCheckboxChange = (taskId) => {
    const selectedTaskIds = [...selectedTasks];

    if (selectedTaskIds.includes(taskId)) {
      const index = selectedTaskIds.indexOf(taskId);
      selectedTaskIds.splice(index, 1);
    } else {
      selectedTaskIds.push(taskId);
    }

    setSelectedTasks(selectedTaskIds);
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedTasks([]);
    } else {
      const allTaskIds = taskData.map((task) => task.task_id);
      setSelectedTasks(allTaskIds);
    }
    setSelectAll(!selectAll);
  };

  const handleExport = (format) => {
    if (selectedTasks.length === 0) {
      console.log("No tasks selected for export");
      return;
    }

    switch (format) {
      case "CSV":
        exportToCSV();
        break;
      case "Excel":
        exportToExcel();
        break;
      case "JSON":
        exportToJSON();
        break;
      default:
        break;
    }
  };

  const exportToCSV = () => {
    if (selectedTasks.length === 0) {
      console.log("No tasks selected for export");
      return;
    }

    const selectedTaskData = taskData.filter((task) =>
      selectedTasks.includes(task.task_id)
    );

    // Create CSV content
    const header = Object.keys(selectedTaskData[0]).join(",");
    const csv = [
      header,
      ...selectedTaskData.map((task) =>
        Object.values(task)
          .map((value) => `"${value}"`)
          .join(",")
      ),
    ].join("\n");

    // Create Blob for CSV file
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);

    // Download CSV file
    const a = document.createElement("a");
    a.href = url;
    a.download = "tasks.csv";
    a.click();
    URL.revokeObjectURL(url);
  };
  const exportToExcel = () => {
    const selectedTaskData = taskData.filter((task) =>
      selectedTasks.includes(task.task_id)
    );
    const worksheet = XLSX.utils.json_to_sheet(selectedTaskData);

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Tasks");
    XLSX.writeFile(workbook, "tasks.xlsx");
  };

  const exportToJSON = () => {
    const selectedTaskData = taskData.filter((task) =>
      selectedTasks.includes(task.task_id)
    );

    const jsonData = JSON.stringify(selectedTaskData, null, 2);
    const blob = new Blob([jsonData], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "tasks.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  // Description

  const [selectedDesc, SetSelectedDesc] = useState("");
  const [oepnDesc, setOpenDesc] = useState(false);

  const handleOpenDesc = (desc) => {
    SetSelectedDesc(desc);
    setOpenDesc(true);
  };

  const handleCloseDesc = () => {
    setOpenDesc(false);
  };

  // Edit Task Data

  const [selectTaskEditData, setSelectTaskEditData] = useState(null);
  const [openEdit, setOpenEdit] = useState(false);

  const handleOpenEditTask = (task) => {
    setSelectTaskEditData(task);
    setOpenEdit(true);
  };

  const handleCloseEditTask = () => {
    setOpenEdit(false);
  };

  // Delete Data
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [taskToDelete, setTaskToDelete] = useState(null);
  const [deletemsg, setDeleteMsg] = useState("");

  const handleDeleteTask = (task_id) => {
    const selectedTask = taskData.find((task) => task.task_id === task_id);

    if (selectedTask) {
      setTaskToDelete(selectedTask);
      setOpenDeleteDialog(true);
      setDeleteMsg("Are you sure you want to delete this task?");
    }
  };

  const confirmDelete = () => {
    if (taskToDelete) {
      axios
        .delete(`${config.apiUrl}/task/deleteTaskData/${taskToDelete.task_id}`)
        .then((response) => {
          setDeleteMsg("Task deleted successfully.");

          // Remove the deleted task from taskData state
          const updatedTaskData = taskData.filter(
            (task) => task.task_id !== taskToDelete.task_id
          );
          setTaskData(updatedTaskData);

          setTimeout(() => {
            setOpenDeleteDialog(false);
          }, 3000);
        })
        .catch((error) => {
          console.error("Error deleting task:", error);
          setDeleteMsg("Error deleting task. Please try again.");
        });
    }
  };

  // Pagination

  const [tasksPerPage, setTasksPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  const handleChangeTasksPerPage = (e) => {
    const newTaskPerPage = parseInt(e.target.value, 10);

    if (newTaskPerPage == 0) {
      setTasksPerPage(taskData.length);
    } else {
      setTasksPerPage(newTaskPerPage);
      setCurrentPage(1);
    }
  };

  const indexOfLastTasks = currentPage * tasksPerPage;
  const indexOfFirstTasks = indexOfLastTasks - tasksPerPage;
  const currentTasks = taskData.slice(indexOfFirstTasks, indexOfLastTasks);

  const [searchedVal, setSearchedVal] = useState("");

  const filterTask = (task) => {
    const searchValue = searchedVal.toLowerCase();
    return (
      !searchedVal ||
      (task.pro_name &&
        task.pro_name.toString().toLowerCase().includes(searchValue)) ||
      (task.module_name &&
        task.module_name.toString().toLowerCase().includes(searchValue)) ||
      (task.sub_module_name &&
        task.sub_module_name.toString().toLowerCase().includes(searchValue)) ||
      (task.task_name &&
        task.task_name.toString().toLowerCase().includes(searchValue)) ||
      (task.task_desc &&
        task.task_desc.toString().toLowerCase().includes(searchValue)) ||
      (task.emp_name &&
        task.emp_name.toString().toLowerCase().includes(searchValue)) ||
      (task.start_date &&
        task.start_date.toString().toLowerCase().includes(searchValue)) ||
      (task.end_date &&
        task.end_date.toString().toLowerCase().includes(searchValue))
    );
  };

  return (
    <div style={{marginTop:'30px'}}>
     <h1 style={{marginLeft:'500px'}}>Task Index</h1>
          <div className="row">
            <div className="col-3">
              <Button
                style={{
                  backgroundColor: "#1B9C85",
                  borderColor: "#1B9C85",
                  color: "white",
                }}
                onClick={(e) => setAnchorEl(e.currentTarget)}
              >
                Export data
              </Button>
              <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={() => setAnchorEl(null)}
              >
                <MenuItem onClick={() => handleExport("CSV")}>
                  Export as CSV
                </MenuItem>
                <MenuItem onClick={() => handleExport("Excel")}>
                  Export as Excel
                </MenuItem>
                <MenuItem onClick={() => handleExport("JSON")}>
                  Export as JSON
                </MenuItem>
              </Menu>
            </div>

            <div className="col-3">
              <TextField
                label="Search"
                onChange={(e) => setSearchedVal(e.target.value)}
                sx={{
                  "& input": {
                    height: "7px",
                  },
                }}
              />
            </div>

            <div className="col-3">
              <select
                onChange={handleChangeTasksPerPage}
                style={{
                  padding: "5px 10px",
                  margin: "0 5px",
                  border: "1px solid #007bff",
                  borderRadius: "4px",
                  cursor: "pointer",
                  backgroundColor: "#fff",
                  color: "#007bff",
                  textDecoration: "none",
                  transition: "background-color 0.3s, color 0.3s",
                }}
              >
                <option value="5">5 Per Page</option>
                <option value="10">10 Per Page</option>
                <option value="15">15 Per Page</option>
                <option value="0">All Per Page</option>
              </select>
            </div>
            <div className="col-3">
              <Button onClick={()=>setOpenNewTask(true)}>Add New Task</Button>
            </div>
          </div>
          {taskData.length > 0 ? (
        <>
          <TableContainer component={Paper} className="mt-3" style={{marginRight:'50px'}}>
            <Table>
              <TableHead style={{ backgroundColor: '#1B9C85'}}>
                <TableRow>
                  <TableCell style={{ border: "1px solid #ddd" }}>
                    <Checkbox checked={selectAll} onChange={handleSelectAll} />
                  </TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>S.No</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Project Name</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Module Name</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Sub Module Name</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Task Name</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Task Description</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Task Employee</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Start Date</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>End Date</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {currentTasks.filter(filterTask).map((task, index) => (
                  <TableRow key={task.task_id}>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      <Checkbox
                        checked={selectedTasks.includes(task.task_id)}
                        onChange={() => handleCheckboxChange(task.task_id)}
                      />
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>{index + 1}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>{task.pro_name}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>{task.module_name}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>{task.sub_module_name}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>{task.task_name}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      <Button onClick={() => handleOpenDesc(task.task_desc)}>
                        Description
                      </Button>
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>{task.emp_name}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>{format(new Date(task.start_date),'yyyy-MM-dd')}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>{format(new Date(task.created_at),'yyyy-MM-dd')}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      <Button onClick={() => handleOpenEditTask(task)}>
                        <EditIcon/>
                        Edit
                      </Button>
                      <Button onClick={() => handleDeleteTask(task.task_id)}>
                      <DeleteIcon style={{ color: 'red' }} />
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <Dialog open={oepnDesc} onClose={handleCloseDesc}>
            <DialogTitle>Task Description</DialogTitle>
            <DialogContent>
              <p>{selectedDesc}</p>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseDesc}>Close</Button>
            </DialogActions>
          </Dialog>

         

          <Dialog open={openEdit} onClose={handleCloseEditTask} maxWidth="md">
            <DialogContent>
              {selectTaskEditData && (
                <UpdateTask
                  task={selectTaskEditData}
                  onClose={handleCloseEditTask}
                  showSuccessMessage={showSuccessMessage}
                />
              )}
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseEditTask}>Close</Button>
            </DialogActions>
          </Dialog>

          <Dialog
            open={showSuccessMsg}
            onClose={() => setShowSuccessMsg(false)}
            maxWidth="sm"
          >
            <DialogContent>
              <h3>Task Data Updated SuccessFully</h3>
            </DialogContent>
            <DialogActions>
              <Button onClose={() => setShowSuccessMsg(false)}>Close</Button>
            </DialogActions>
          </Dialog>

          <Dialog
            open={openDeleteDialog}
            onClose={() => setOpenDeleteDialog(false)}
          >
            <DialogTitle>Delete Message</DialogTitle>
            <DialogContent>
              <p>{deletemsg}</p>
            </DialogContent>
            <DialogActions>
              <Button
                variant="contained"
                onClick={confirmDelete}
                style={{ backgroundColor: "#DC143C", color: "white" }}
              >
                OK
              </Button>
              <Button
                variant="contained"
                onClick={() => setOpenDeleteDialog(false)}
                style={{ backgroundColor: "#1B9C85", color: "white" }}
              >
                Cancel
              </Button>
            </DialogActions>
          </Dialog>
        </>
      ) : (
        <div style={{width:'175vh',height:'465px'}}>
            <p className="text-center mt-5">Sub Module Data Is Not Available </p>
          </div>
      )}
       <Dialog open={openNewTask} onClose={()=>setOpenNewTask(false)} maxWidth='md'>
            <DialogTitle variant="h3" className="text-center">Add New Task</DialogTitle>
            <DialogContent>
              <AddTask onClose={()=>setOpenNewTask(false)} handleShowNewTaskSuccesMsg={handleShowNewTaskSuccesMsg}/>
            </DialogContent>
            <DialogActions>
              <Button onClick={()=>setOpenNewTask(false)}>Close</Button>
            </DialogActions>
          </Dialog>


          <Dialog
            open={openNewTaskSuccessMsg}
            onClose={() => setOpenNewTaskSuccessMsg(false)}
            maxWidth="sm"
          >
            <DialogContent>
              <h3>SuccessFully Added New Task</h3>
            </DialogContent>
            <DialogActions>
              <Button onClose={() => setOpenNewTaskSuccessMsg(false)}>Close</Button>
            </DialogActions>
          </Dialog>
          
    </div>
  );
}

export default TaskIndex;
