import React, { useEffect, useState } from "react";
import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Menu,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import axios from "axios";
import { format } from "date-fns";
import * as XLSX from "xlsx";
import Papa from "papaparse";

import AddTask from "./AddTask";
import config from "../../../../config";
function TaskEmpIndex() {
  const [taskData, setTaskData] = useState([]);
  const [openDesc, setOpenDesc] = useState(false);
  const [selectedDesc, setSelectedDesc] = useState("");
  const [addTask, setAddTask] = useState(false);

  const handleOpenAddTask = () => {
    setAddTask(true);
  };

  const handleCloseAddTask = () => {
    setAddTask(false);
  };

  const handleOpenDesc = (desc) => {
    setSelectedDesc(desc);
    setOpenDesc(true);
  };

  const handleCloseDesc = () => {
    setOpenDesc(false);
  };

  useEffect(() => {
    axios.get(`${config.apiUrl}/task/getEmpTaskData`)
      .then((response) => {
        setTaskData(response.data);
      })
      .catch((error) => {
        console.error("Data not found:", error);
      });
  }, []);

  const [itemPerPage, setItemPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  const handleItemPerPage = (e) => {
    const newItem = parseInt(e.target.value, 10);
    if (newItem === 0) {
      setItemPerPage(taskData.length);
    } else {
      setItemPerPage(newItem);
      setCurrentPage(1);
    }
  };

  const indexOfLastItem = itemPerPage * currentPage;
  const indexOfFirstItem = indexOfLastItem - itemPerPage;
  const currentItem = taskData.slice(indexOfFirstItem, indexOfLastItem);

  const [searchedVal, setSearchedVal] = useState("");

  const filterTask = (task) => {
    const searchValue = searchedVal.toLowerCase();
    return (
      !searchedVal ||
      (task.pro_name &&
        task.pro_name.toString().toLowerCase().includes(searchValue)) ||
      (task.module_name &&
        task.module_name.toString().toLowerCase().includes(searchValue)) ||
      (task.sub_module_name &&
        task.sub_module_name.toString().toLowerCase().includes(searchValue)) ||
      (task.task_name &&
        task.task_name.toString().toLowerCase().includes(searchValue)) ||
      (task.task_desc &&
        task.task_desc.toString().toLowerCase().includes(searchValue)) ||
      (task.emp_name &&
        task.emp_name.toString().toLowerCase().includes(searchValue)) ||
      (task.start_date &&
        task.start_date.toString().toLowerCase().includes(searchValue)) ||
      (task.end_date &&
        task.end_date.toString().toLowerCase().includes(searchValue))
    );
  };

  const [selectedTasks, setSelectedTasks] = useState([]);

  const handleTaskSelect = (taskId) => {
    const selectedIndex = selectedTasks.indexOf(taskId);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selectedTasks, taskId);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selectedTasks.slice(1));
    } else if (selectedIndex === selectedTasks.length - 1) {
      newSelected = newSelected.concat(selectedTasks.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selectedTasks.slice(0, selectedIndex),
        selectedTasks.slice(selectedIndex + 1)
      );
    }

    setSelectedTasks(newSelected);
  };

  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const downloadCSV = (csvData, filename) => {
    const csvString = Papa.unparse(csvData);
    const csvBlob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
    if (navigator.msSaveBlob) {
      // For IE 10+
      navigator.msSaveBlob(csvBlob, filename);
    } else {
      const link = document.createElement("a");
      if (link.download !== undefined) {
        const url = URL.createObjectURL(csvBlob);
        link.setAttribute("href", url);
        link.setAttribute("download", filename);
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  };

  // Function to handle CSV export using the downloadCSV method
  const handleCSVExport = () => {
    const csvData = taskData.map(
      (
        {
          task_id,
          pro_name,
          module_name,
          sub_module_name,
          task_name,
          task_desc,
          emp_name,
          start_date,
          end_date,
        },
        index
      ) => [
        index + 1,
        pro_name,
        module_name,
        sub_module_name,
        task_name,
        task_desc,
        emp_name,
        format(new Date(start_date), "yyyy-M-dd"),
        format(new Date(end_date), "yyyy-MM-dd"),
      ]
    );

    const csvFormattedData = [
      [
        "S.no",
        "Project Name",
        "Module Name",
        "Sub Module Name",
        "Task Name",
        "Description",
        "Employee Name",
        "Start Date",
        "End Date",
      ],
      ...csvData,
    ];

    const csvFilename = "task_data.csv";
    downloadCSV(csvFormattedData, csvFilename);
  };

  const handleExcelExport = () => {
    const excelData = taskData.map(
      (
        {
          task_id,
          pro_name,
          module_name,
          sub_module_name,
          task_name,
          task_desc,
          emp_name,
          start_date,
          end_date,
        },
        index
      ) => [
        index + 1,
        pro_name,
        module_name,
        sub_module_name,
        task_name,
        task_desc,
        emp_name,
        format(new Date(start_date), "yyyy-M-dd"),
        format(new Date(end_date), "yyyy-MM-dd"),
      ]
    );

    const ws = XLSX.utils.aoa_to_sheet([
      [
        "S.no",
        "Project Name",
        "Module Name",
        "Sub Module Name",
        "Task Name",
        "Task Description",
        "Employee Name",
        "Start Date",
        "End Date",
      ],
      ...excelData,
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Sheet 1");
    XLSX.writeFile(wb, "task_data.xlsx");
  };

  const handleJSONExport = () => {
    const jsonData = JSON.stringify(taskData, null, 2); // The '2' parameter adds indentation for better readability
    const blob = new Blob([jsonData], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "task_data.json";
    link.click();
  };

  return (
    <div
      style={{ marginTop: "50px", marginLeft: "-50px", marginRight: "30px" }}
    >
      <h1 className="text-center">Task Index</h1>
      <div className="row">
        <div className="col-3">
          <Button
            style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}
            onClick={handleClick}
          >
            Export data
          </Button>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <MenuItem onClick={handleCSVExport}>Export as CSV</MenuItem>
            <MenuItem onClick={handleExcelExport}>Export as Excel</MenuItem>
            <MenuItem onClick={handleJSONExport}>Export as JSON</MenuItem>
          </Menu>
        </div>
        <div className="col-3">
          <TextField
            label="Search"
            onChange={(e) => setSearchedVal(e.target.value)}
            sx={{
              "& input": {
                height: "7px",
              },
            }}
          />
        </div>
        <div className="col-3">
          <select
           
            onChange={handleItemPerPage}
            style={{
              padding: "5px 10px",
              margin: "0 5px",
              border: "1px solid #007bff",
              borderRadius: "4px",
              cursor: "pointer",
              backgroundColor: "#fff",
              color: "#007bff",
              textDecoration: "none",
              transition: "background-color 0.3s, color 0.3s",
            }}
          >
            <option value="5">5 Per Page</option>
            <option value="10">10 Per Page</option>
            <option value="15">15 Per Page</option>
            <option value="0">All Per Page</option>
          </select>
        </div>
        <div className="col-3">
          <Button
            onClick={handleOpenAddTask}
            style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}
          >
            Add New Task
          </Button>
        </div>
      </div>
      {taskData.length > 0 ? (
        <>
          <div style={{marginLeft:'-40px',marginRight:'20px'}}>
          <TableContainer component={Paper} className="mt-3">
            <Table>
              <TableHead style={{ backgroundColor: "#1B9C85", }}>
                <TableRow>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>S.no</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Project Name</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Module Name</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Sub Module Name</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Task Name</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Description</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Employee Name</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Start Date</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>End Date</TableCell>
                  <TableCell style={{ border: "1px solid #ddd", color: "whitesmoke" }}>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {currentItem.filter(filterTask).map((task, index) => (
                  <TableRow key={task.task_id}>
                    {/* <TableCell style={{ border: "1px solid #ddd" }}>
                      <Checkbox
                        checked={selectedTasks.includes(task.task_id)}
                        onChange={() => handleTaskSelect(task.task_id)}
                      />
                    </TableCell> */}
                    <TableCell style={{ border: "1px solid #ddd",}}>{index + 1}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd",}}>{task.pro_name}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd",}}>{task.module_name}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd",}}>{task.sub_module_name}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd",}}>{task.task_name}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd",}}>
                      <Button onClick={() => handleOpenDesc(task.task_desc)}>
                        Description
                      </Button>
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd",}}>{task.emp_name}</TableCell>
                    <TableCell style={{ border: "1px solid #ddd",}}>
                      {format(new Date(task.start_date), "yyyy-M-dd")}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd",}}>
                      {format(new Date(task.end_date), "yyyy-MM-dd")}
                    </TableCell>
                    <TableCell></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          </div>

          {/* Description */}
          <Dialog open={openDesc} onClose={handleCloseDesc}>
            <DialogTitle>Task Description</DialogTitle>
            <DialogContent>
              <p>{selectedDesc}</p>
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseDesc}>Close</Button>
            </DialogActions>
          </Dialog>

          {/* Add New Task */}
          <Dialog open={addTask} onClose={handleCloseAddTask} maxWidth="md">
            <DialogTitle
              className="text-center"
              style={{ fontSize: "20px", fontWeight: "bold" }}
            >
              Add New Task
            </DialogTitle>
            <DialogContent>
              <AddTask />
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseAddTask}>Close</Button>
            </DialogActions>
          </Dialog>
        </>
      ) : (
        <h3 className="text-center" style={{ marginTop: "50px", color: "red" }}>
          Task Data is Not Available
        </h3>
      )}
    </div>
  );
}

export default TaskEmpIndex;
