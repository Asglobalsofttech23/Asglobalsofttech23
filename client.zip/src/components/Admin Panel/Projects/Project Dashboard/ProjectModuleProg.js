
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Pie } from 'react-chartjs-2';
import { ResponsiveContainer } from 'recharts';
import config from '../../../../config';
const ProjectModuleProg = ({proId}) => {
  const [hoveredSegment, setHoveredSegment] = useState(null);

  const [data,setData] = useState([])

  useEffect(() =>{
    axios.get(`${config.apiUrl}/projectDashboard/ProModuleProg?pro_id=1`)
    .then(response =>{
        setData(response.data)
    })
  },[])



  const labels = data.map(item => item.module_name);
  const percentages = data.map(item => parseFloat(item.module_completion_percentage));

  const randomColor = () => `#${Math.floor(Math.random() * 16777215).toString(16)}`;
  const colors = Array.from({ length: data.length }, () => randomColor());

  const chartData = {
    labels: labels,
    datasets: [
      {
        data: percentages,
        backgroundColor: colors,
        hoverBackgroundColor: colors, // Use the same colors for hover effect
      },
    ],
  };

  const options = {
    tooltips: {
      callbacks: {
        label: function (tooltipItem, data) {
          const label = data.labels[tooltipItem.index] || '';
          const value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
          return `${label}: ${value}%`;
        },
      },
    },
    onHover: (event, chartElement) => {
      if (chartElement.length > 0) {
        setHoveredSegment(chartElement[0].index);
      } else {
        setHoveredSegment(null);
      }
    },
  };

  const borderWidths = Array(data.length).fill(2); // Default border width for all segments
  if (hoveredSegment !== null) {
    borderWidths[hoveredSegment] = 8; // Increase border width for the hovered segment to "split" it
  }

  const highlightedData = { ...chartData };
  highlightedData.datasets[0].borderWidth = borderWidths;

  return (
    <div >
      <h2 className='text-center'>Project Module</h2>
      <ResponsiveContainer width="100%" height={290}>
      <Pie data={highlightedData} options={options} />
      </ResponsiveContainer>
    </div>
  );
};

export default ProjectModuleProg;



