import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { BarChart, Bar, Cell, CartesianGrid, XAxis, YAxis, ResponsiveContainer } from 'recharts';
import SingleProProg from './SingleProProg';
import ProjectModuleProg from './ProjectModuleProg';
import ProjectSubModuleProg from './ProjectSubModuleProg';
import Example from './ProjectSubModuleProg';
import ProjectTaskProg from './ProjectTaskProg';
import config from '../../../../config';
const colors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', 'red', 'pink'];

const SingleProEmpProg = ({proId}) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get(`${config.apiUrl}/projectDashboard/singleprojectEmp?pro_id=${proId}`)
      .then(response => {
        setData(response.data);
        console.log(response.data)
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);

  const TriangleBar = (props) => {
    const { fill, x, y, width, height } = props;
    const path = `M${x},${y + height}C${x + width / 3},${y + height} ${x + width / 2},${y + height / 3} ${x + width / 2},${y}C${x + width / 2},${y + height / 3} ${x + (2 * width) / 3},${y + height} ${x + width},${y + height}Z`;

    return <path d={path} stroke="none" fill={fill} />;
  };

  return (
    <div>
      <h1 className='text-center'>Project Employee</h1>
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="emp_name" />
        <YAxis />
        <Bar dataKey="progress" fill="#8884d8" shape={<TriangleBar />} label={{ position: 'top' }}>
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>



    
    </div>

    
  );
};

export default SingleProEmpProg;
