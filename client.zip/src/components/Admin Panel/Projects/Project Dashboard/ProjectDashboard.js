
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';
import config from '../../../../config';
const ProjectDashboard = () => {
  const [projectData, setProjectData] = useState([]);

  useEffect(() => {
    // Fetch data from the API endpoint
    axios.get(`${config.apiUrl}/projectDashboard/allprojectdashboard`)
      .then(response => {
        setProjectData(response.data);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);

  const getRandomColor = () => {
    // Generate random color in hexadecimal format
    return `#${Math.floor(Math.random() * 16777215).toString(16)}`;
  };

  const labels = projectData.map(project => project.pro_name);
  const completionData = projectData.map(project => project.overall_completion_percentage);

  const generateRandomColors = () => {
    return completionData.map(() => getRandomColor());
  };

  const chartData = {
    labels: labels,
    datasets: [
      {
        label: 'Overall Completion Percentage',
        backgroundColor: generateRandomColors(),
        data: completionData,
      },
    ],
  };

  return (
    <div style={{ height:'300px',marginLeft:'20px'}}>
      <Bar
        data={chartData}
        options={{
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
            },
          },
          plugins: {
            legend: {
              display: false,
            },
          },
          elements: {
            bar: {
              borderWidth: 0, // Remove border from bars
            },
          },
        }}
      />
    </div>
  );
};

export default ProjectDashboard;