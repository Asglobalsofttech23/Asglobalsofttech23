
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Pie } from 'react-chartjs-2';
import { ResponsiveContainer } from 'recharts';
import config from '../../../../config';
const ProjectModuleProg = ({proId}) => {
  const [hoveredSegment, setHoveredSegment] = useState(null);
  const [overallCompletion, setOverallCompletion] = useState(0);
  const [remainingCompletion, setRemainingCompletion] = useState(0);

  useEffect(() => {
    axios.get(`${config.apiUrl}/projectDashboard/singleProjectProgress?pro_id=2`) 
      .then(response => {
        const responseData = response.data;
        if (Array.isArray(responseData) && responseData.length > 0) {
          const { overall_completion_percentage } = responseData[0];
          const overallPercentage = parseFloat(overall_completion_percentage);
          setOverallCompletion(overallPercentage);

          // Assuming total completion is 100%, calculate the remaining completion
          const remainingPercentage = 100 - overallPercentage;
          setRemainingCompletion(remainingPercentage);
        }
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);

  const overallLabel = 'Overall Completion';
  const remainingLabel = 'Remaining';

  const data = {
    labels: [overallLabel, remainingLabel],
    datasets: [
      {
        data: [overallCompletion, remainingCompletion],
        backgroundColor: ['#36A2EB', '#FFCE56'], // Colors for overall completion and remaining
        hoverBackgroundColor: ['#36A2EB', '#FFCE56'],
      },
    ],
  };

  const options = {
    tooltips: {
      callbacks: {
        label: function (tooltipItem, data) {
          const label = data.labels[tooltipItem.index] || '';
          const value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
          return `${label}: ${value}%`;
        },
      },
    },
    onHover: (event, chartElement) => {
      if (chartElement.length > 0) {
        setHoveredSegment(chartElement[0].index);
      } else {
        setHoveredSegment(null);
      }
    },
  };

  const borderWidths = [2, 2]; // Default border width for both segments
  if (hoveredSegment !== null) {
    borderWidths[hoveredSegment] = 8; // Increase border width for the hovered segment
  }

  const highlightedData = { ...data };
  highlightedData.datasets[0].borderWidth = borderWidths;

  return (
    <div>
      <h2 className='text-center'>Project Progress</h2>
      <div style={{marginLeft:'20px'}}>
      <ResponsiveContainer width="100%" height={290}>
        <Pie data={highlightedData} options={options} />
      </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ProjectModuleProg;
