import React, { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import axios from 'axios';
import config from '../../../../config';
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    // Extracting data from the payload
    const { pro_name, module_name, sub_module_name, task_name,progress } = payload[0].payload;

    return (
      <div className="custom-tooltip"   
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
        border: '1px solid #ccc',
        padding: '10px',
        borderRadius: '35px 35px 35px 35px',
        boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.1)',
      }}
      >
        <p>{`Pro Name: ${pro_name}`}</p>
        <p>{`Module Name: ${module_name}`}</p>
        <p>{`Submodule Name: ${sub_module_name}`}</p>
        <p>{`Task Name: ${task_name}`}</p>
        <p>{`Progress: ${progress}%`}</p>
      </div>
    );
  }

  return null;
};

const ProjectTaskProg = ({proId}) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/projectDashboard/taskProg?pro_id=4`)
      .then((response) => {
        setData(response.data);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);

  return (
    <div>
      <h1 className="text-center">Tasks</h1>
      <div style={{ width: '100%', height: 300 }}>
        <LineChart
          width={700}
          height={300}
          data={data}
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
        >
          {/* <XAxis dataKey="sub_module_name" /> */}
          <XAxis/>
          <YAxis />
          <CartesianGrid strokeDasharray="3 3" />
          <Tooltip content={<CustomTooltip />} /> {/* Using the CustomTooltip component */}
          <Legend />
          {Object.keys(data[0] || {}).map((key) => {
            if (
              key !== 'pro_id' &&
              key !== 'pro_name' &&
              key !== 'module_name' &&
              key !== 'sub_module_name' &&
              key !== 'task_name'
            ) {
              return (
                <Line
                  key={key}
                  type="monotone"
                  dataKey={key}
                  name={key}
                  stroke="#8884d8"
                />
              );
            }
            return null;
          })}
        </LineChart>
      </div>
    </div>
  );
};

export default ProjectTaskProg;
