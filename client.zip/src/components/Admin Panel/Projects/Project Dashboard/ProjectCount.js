import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { Card } from '@mui/material';
import config from '../../../../config';
function ProjectCount() {

    const [proCount,setProCount] = useState([]);

    

    useEffect(() =>{
      axios.get(`${config.apiUrl}/projectDashboard/projectCount`)
      .then(response => {
          console.log(response);
          const projectCounts = response.data[0];
  
          // Set session storage for total, completed, and pending projects
          sessionStorage.setItem('totalProjects', projectCounts.total_projects);
          sessionStorage.setItem('completedProjects', projectCounts.completed_projects);
          sessionStorage.setItem('pendingProjects', projectCounts.pending_projects);
  
          setProCount(projectCounts);
      })
      .catch((error) => {
        console.error("Error :", error.message);
        // Handle the error as needed, e.g., show an error message to the user
      });
  
  }, []);
  
  return (
    <div>
      {proCount ? (
        <>
        
           
            <Card >
              <div className='row mb-3' >
              <div className='col-12'>
                <Card style={{height:'155px'}}>
                <h1 className='text-center'>
                    Total Projects
                    </h1>
                    <h1 className='text-center'>{proCount.total_projects}</h1>
                </Card>
                </div>
              </div>

              <div className='row' >
                
                    <div className='col-6'>
                    <Card style={{height:'170px'}}>
                    <h1 className='text-center'>Completed</h1>
                    <h1 className='text-center'>
                    {proCount.completed_projects}
                    </h1>
                    </Card>
                    </div>
                    
                    <div className='col-6'>
                    <Card style={{height:'170px'}}>
                    <h1 className='text-center'>Pending</h1>
                    <h1 className='text-center'>
                    {proCount.pending_projects}
                    </h1>
                    </Card>
                    </div>
                    </div>
                    </Card>
               
          
        </>
      ) : (
        <>
        <p className='text-center'>Module Not Found</p>
        </>
      )}
    </div>
  )
}

export default ProjectCount
