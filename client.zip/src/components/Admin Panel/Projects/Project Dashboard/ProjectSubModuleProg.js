import React, { useEffect, useState } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Area,
  Line,
} from 'recharts';
import axios from 'axios';
import config from '../../../../config';
const CustomTooltip = ({ active, payload, label, data }) => {
    if (active && payload && payload.length) {
      const { payloadData } = payload[0];
      const item = data.find((item) => item.sub_module_name === label);
  
      return (
        <div
        style={{
            backgroundColor: 'rgba(255, 255, 255, 0.9)',
            border: '1px solid #ccc',
            padding: '10px',
            borderRadius: '35px 35px 35px 35px',
            boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.1)',
          }}
        >
          {item && (
            <>
              <p>{`Pro Name: ${item.pro_name}`}</p>
              <p>{`Module Name: ${item.module_name}`}</p>
            </>
          )}
          <p>{`Sub Module: ${label}`}</p>
          {payload.map((item, index) => (
            <p key={index}>{`${item.name}: ${item.value}`}</p>
          ))}
        </div>
      );
    }
    return null;
  };
  

const ProjectSubModuleProg = ({proId}) => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get(`${config.apiUrl}/projectDashboard/submoduleprog?pro_id=1`)
      .then(response => {
        setData(response.data);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);


  const colors = ['red', 'blue', 'green', 'yellow', 'orange'];
  return (
   <div>

    <h1 className='text-center'>Sub Module</h1>
     <div style={{ width: '100%', height: 300 }}>

<ResponsiveContainer>
  <ComposedChart
    width={500}
    height={400}
    data={data}
    margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
  >
    <CartesianGrid stroke="#f5f5f5" />
    <XAxis dataKey="sub_module_name" />
    <YAxis />
    <Tooltip content={<CustomTooltip data={data} />} />
    <Legend />
    
    <Bar dataKey="progress" fill='rgb(43,73,113)' />
  
  </ComposedChart>
</ResponsiveContainer>
</div>
   </div>
  );
};

export default ProjectSubModuleProg;
