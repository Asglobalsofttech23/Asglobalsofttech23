import React from "react";
import Navbar from "../../TopNav/TopNav";
import SingleProProg from "./SingleProProg";
import SingleProEmpProg from "./SingleProEmpProg";
import { Card } from "@mui/material";
import ProjectSubModuleProg from "./ProjectSubModuleProg";
import ProjectModuleProg from "./ProjectModuleProg";
import ProjectTaskProg from "./ProjectTaskProg";
import { useParams } from 'react-router-dom';

function SingleProjectDashboardRouting() {
  const { proId } = useParams();
  console.log("ProjectId",proId)
  return (
    <div style={{overflowX:'hidden',height:'703px'}}> 
      <div>
        <Navbar />
      </div>
      <div className="row " style={{marginTop:'70px'}} >
        <div className="col-6" > 
          <Card className="mt-3">
          <div style={{display:'flex',justifyContent:'center'}}>
          <SingleProProg  proId={proId}/>
          </div>
          </Card>
        </div>
        <div className="col-6">
          <Card className="mt-3">
          <SingleProEmpProg proId={proId}/>
          </Card>
        </div>
        {/* <div className="col-3">
          <Card className="mt-3">
          <ProjectModuleProg proId={proId}/> 
          </Card>
        </div> */}
      </div>


      {/* <div className="row mt-4" >
        <div className="col-6">
          <Card>
          <ProjectSubModuleProg proId={proId}/>
          </Card>
        </div>
        <div className="col-6">
          <Card>
          <ProjectTaskProg proId={proId}/>
          </Card>
        </div>
      </div> */}
    </div>
  );
}

export default SingleProjectDashboardRouting;




 
