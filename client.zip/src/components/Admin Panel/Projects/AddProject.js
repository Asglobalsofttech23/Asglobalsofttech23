import React, { useState, useEffect } from "react";
import {
  Button,
  Chip,
  Grid,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import axios from "axios";
import WorkingHoursCalculator from "../../../Vignesh/WorkingHoursCalculator";
import moment from "moment";
import config from "../../../config";
function AddProject({onClose}) {
  const [customers, setCustomers] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [formData, setFormData] = useState({
    cust_email: "",
    pro_name: "",
    pro_desc: "",
    start_date: "",
    end_date: "",
    allocation_date: "",
    selectedEmployees: [],
  });

  const [errors, setErrors] = useState({
    cust_email: "",
    pro_name: "",
    pro_desc: "",
    start_date: "",
    end_date: "",
    allocation_date: "",
    selectedEmployees: "",
  });

  const validateField = (name, value) => {
    let errorMsg = "";

    const trimmedValue =
      value && typeof value === "string" ? value.trim() : value;

    switch (name) {
      case "cust_email":
        if (!trimmedValue) {
          errorMsg = "Please Must Select one Customer";
        }
        break;
      case "pro_name":
        if (!trimmedValue) {
          errorMsg = "Project Name cannot be empty";
        }
        break;
      case "pro_desc":
        if (!trimmedValue) {
          errorMsg = "Project Description cannot be empty";
        }
        break;
      case "start_date":
        if (!trimmedValue) {
          errorMsg = "Start Date cannot be empty";
        }else {
          const today = moment().format("YYYY-MM-DD");
          const selectedDate = moment(trimmedValue).format("YYYY-MM-DD");
    
          if (selectedDate < today) {
            errorMsg = "Hire Date cannot be before the current date";
          }
        }
        break;
        case "end_date":
          if (!trimmedValue) {
            errorMsg = "End Date cannot be empty";
          } else {
            const startDate = formData.start_date;
            const today = moment().format("YYYY-MM-DD");
            const selectedDate = moment(trimmedValue).format("YYYY-MM-DD");
            const startDateValid = moment(startDate).isValid();
            const endDateValid = moment(trimmedValue).isValid();
    
            if (!startDateValid || !endDateValid) {
              errorMsg = "Please 1st Select Start date then select end dates";
            } else if (selectedDate <= today) {
              errorMsg = "End Date must be after the current date";
            } else if (selectedDate <= startDate) {
              errorMsg = "End Date must be after the Start Date";
            }
          }
          break;
      case "allocation_date":
        if (!trimmedValue) {
          errorMsg = "Allocation Date cannot be empty";
        }
        break;
      case "selectedEmployees":
        if (!Array.isArray(trimmedValue) || trimmedValue.length === 0) {
          errorMsg = "Please At least Select one Employee.";
        }
        break;
      case "hoursPerDay":
        if (!trimmedValue) {
          errorMsg = "Hours Per Day cannot be empty";
        } else if (parseInt(trimmedValue, 10) <= 0) {
          errorMsg = "Hours Per Day must be greater than 0";
        }
        break;
      // Add cases for other fields as needed
      default:
        break;
    }

    return errorMsg;
  };

  const handleCustomerSelect = (event) => {
    const value = event.target.value;
    setFormData({ ...formData, cust_email: value });
    const errorMsg = validateField("cust_email", value);
    setErrors({ ...errors, cust_email: errorMsg });
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
    const errorMsg = validateField(name, value);
    setErrors({ ...errors, [name]: errorMsg });
  };

  useEffect(() => {
    axios.get(`${config.apiUrl}/customers/converted_customer`)
      .then((response) => {
        setCustomers(response.data);
      })
      .catch((error) => {
        console.error("Error fetching customers:", error);
      });

    axios.get(`${config.apiUrl}/employees`) // Replace with your employees endpoint
      .then((response) => {
        setEmployees(response.data);
      })
      .catch((error) => {
        console.error("Error fetching employees:", error);
      });
  }, []);

  const handleEmployeeSelect = (event) => {
    const selectedEmpIds = Array.isArray(event.target.value)
      ? event.target.value
      : [event.target.value];

    let errorMsg = "";
    if (!selectedEmpIds || selectedEmpIds.length === 0) {
      errorMsg = "Please At least Select one Employee.";
    }

    setErrors({ ...errors, selectedEmployees: errorMsg });

    // Check if the selection is not empty before updating form data
    if (selectedEmpIds.length > 0) {
      setFormData({ ...formData, selectedEmployees: selectedEmpIds });
    } else {
      // If it's empty, you can reset the selected employees or handle it based on your logic
      setFormData({ ...formData, selectedEmployees: [] });
    }
  };

  // Working Days Calculation

  const [hoursPerDay, setHoursPerDay] = useState("");
  const [totalHours, setTotalHours] = useState(0);
  const [workingDays, setWorkingDays] = useState([]);
  const [selectedHolidays, setSelectedHolidays] = useState([]);
  const [isHolidaysEnabled, setIsHolidaysEnabled] = useState(false);
  const [workingDayCounts, setWorkingDayCounts] = useState(null);

  const calculateTotalHours = () => {
    const start = moment(formData.start_date, "YYYY-MM-DD");
    const end = moment(formData.end_date, "YYYY-MM-DD");
    const hoursPerDayNumber = parseInt(hoursPerDay, 10);

    let currentDate = moment(start);
    let totalWorkingHours = 0;
    const days = [];
    const holidays = [...selectedHolidays];
    setIsHolidaysEnabled(true);

    while (currentDate <= end) {
      const dayOfWeek = currentDate.day();

      const currentFormattedDate = currentDate.format("YYYY-MM-DD");

      if (dayOfWeek !== 0 && dayOfWeek !== 7) {
        if (!holidays.includes(currentFormattedDate)) {
          totalWorkingHours += hoursPerDayNumber;
          days.push(currentDate.format("dddd"));
        }
      }
      currentDate.add(1, "day"); // Move to the next day
    }

    setTotalHours(totalWorkingHours);
    setWorkingDays(days);

    setFormData({
      ...formData,
      totalWorkingHours: totalWorkingHours,
      totalWorkingDays: days.length,
      hoursPerDay: hoursPerDay,
    });

    const dayCounts = {
      Sunday: 0,
      Monday: 0,
      Tuesday: 0,
      Wednesday: 0,
      Thursday: 0,
      Friday: 0,
      Saturday: 0,
    };

    for (const day of days) {
      const dayOfWeek = moment(day, "dddd").format("dddd");
      dayCounts[dayOfWeek]++;
    }

    const table = (
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              {Object.keys(dayCounts).map((day) => (
                <TableCell key={day} style={{ border: "1px solid #ddd" }}>
                  {day}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            <TableRow>
              {Object.values(dayCounts).map((count, index) => (
                <TableCell key={index} style={{ border: "1px solid #ddd" }}>
                  {count}
                </TableCell>
              ))}
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    );

    setWorkingDayCounts(table);
  };

  const handleHolidaySelection = (e) => {
    const selectedDate = e.target.value;
    const selectedMoment = moment(selectedDate, "YYYY-MM-DD");

    if (
      selectedMoment.isSameOrAfter(moment(formData.start_date)) &&
      selectedMoment.isSameOrBefore(moment(formData.end_date))
    ) {
      if (!selectedHolidays.includes(selectedDate)) {
        setSelectedHolidays([...selectedHolidays, selectedDate]);
      } else {
        const updatedHolidays = selectedHolidays.filter(
          (date) => date !== selectedDate
        );
        setSelectedHolidays(updatedHolidays);
      }
    } else {
      // Alert or message indicating the selected date is outside the range
      // You can use state to display a message or an alert here
      console.log("Selected date is outside the range of start and end dates");
    }
  };



  

  const handleSubmit = (e) => {
    e.preventDefault();
  
    // Validate all fields
    const validatedFields = {};
    Object.keys(formData).forEach((fieldName) => {
      const value = fieldName === 'hoursPerDay' ? hoursPerDay : formData[fieldName];
      const errorMsg = validateField(fieldName, value);
      validatedFields[fieldName] = errorMsg;
    });
  
    // Validate hoursPerDay separately if it's not included in the form data
    if (!formData.hasOwnProperty('hoursPerDay')) {
      const hoursPerDayError = validateField('hoursPerDay', hoursPerDay);
      validatedFields['hoursPerDay'] = hoursPerDayError;
    }
  
    // Update errors state with validation results for all fields
    setErrors({ ...validatedFields });
  
    // Check if any field has an error
    const isFormValid = Object.values(validatedFields).every((errorMsg) => errorMsg === "");
  
    if (isFormValid) {
      calculateTotalHours();
  
      // Include necessary data in the formData before sending
      const updatedFormData = {
        ...formData,
        totalWorkingHours: totalHours,
        totalWorkingDays: workingDays.length,
        hoursPerDay: hoursPerDay,
      };
  
      axios.post(`${config.apiUrl}/project`, updatedFormData)
        .then((response) => {
          console.log("Project Form Data:", updatedFormData);
          console.log("Successfully Added Project Data");
          onClose();
        })
        .catch((error) => {
          console.error("Error adding project data:", error);
        });
    } else {
      console.log("Form contains errors. Cannot submit.");
    }
  };
  
  
   const formatSelectedDate = (date) => {
    const formattedDate = moment(date).format("DD-MM-YYYY");
    return formattedDate;
  };

  
  

  
  return (
    <div>
      <h1>Add Project</h1>
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Customer Email"
            name="cust_name"
            value={formData.cust_email}
            onChange={handleCustomerSelect}
            error={!!errors.cust_email}
            helperText={errors.cust_email}
          >
            <MenuItem value="">Select Customer Email</MenuItem>
            {customers.map((cust) => (
              <MenuItem key={cust.cust_id} value={cust.cust_email}>
                {" "}
                {cust.cust_email}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Project Name"
            name="pro_name"
            value={formData.pro_name}
            onChange={handleInputChange}
            error={!!errors.pro_name}
            helperText={errors.pro_name}
          />

          {/* <p>{formData.pro_name}</p> */}
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Start Date"
            type="date"
            InputLabelProps={{ shrink: true }}
            name="start_date"
            value={formData.start_date}
            onChange={handleInputChange}
            error={!!errors.start_date}
            helperText={errors.start_date}
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            fullWidth
            label="End Date"
            type="date"
            InputLabelProps={{ shrink: true }}
            name="end_date"
            value={formData.end_date}
            onChange={handleInputChange}
            error={!!errors.end_date}
            helperText={errors.end_date}
          />
        </Grid>
        {/* <Grid item xs={6}>
          <TextField
            fullWidth
            label="Select Holidays"
            type="date"
            InputLabelProps={{ shrink: true }}
            onChange={handleHolidaySelection}
            min={formData.start_date} // Use formData.start_date as min
            max={formData.end_date} // Use formData.end_date as max
            value={selectedHolidays}
            multiple
            InputProps={{
              inputProps: {
                min: formData.start_date,
                max: formData.end_date,
              },
            }}
          />
        </Grid> */}

          <Grid item xs={6}>
        <TextField
    fullWidth
    label="Select Holidays"
    type="date"
    InputLabelProps={{ shrink: true }}
    onChange={handleHolidaySelection}
    min={formData.start_date}
    max={formData.end_date}
     // Display all selected dates as a comma-separated list
    multiple
    InputProps={{
      inputProps: {
        min: formData.start_date,
        max: formData.end_date,
      },
    }}
  />
        <div style={{ marginTop: "8px" }}>
          {selectedHolidays.map((date, index) => (
            <Chip
              key={index}
              label={formatSelectedDate(date)}
              onDelete={() => {
                const updatedHolidays = selectedHolidays.filter(
                  (item) => item !== date
                );
                setSelectedHolidays(updatedHolidays);
              }}
              style={{ marginRight: "4px" }}
            />
          ))}
        </div>
      </Grid>


        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Hours Per Day"
            type="number"
            value={hoursPerDay}
            onChange={(e) => {
              setHoursPerDay(e.target.value);
              const errorMsg = validateField("hoursPerDay", e.target.value);
              setErrors({ ...errors, hoursPerDay: errorMsg });
            }}
            error={!!errors.hoursPerDay}
            helperText={errors.hoursPerDay}
          />
        </Grid>

        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Project Description"
            name="pro_desc"
            value={formData.pro_desc}
            onChange={handleInputChange}
            error={!!errors.pro_desc}
            helperText={errors.pro_desc}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Select Employees"
            name="selectedEmployees"
            value={formData.selectedEmployees}
            onChange={handleEmployeeSelect}
            error={!!errors.selectedEmployees}
            helperText={errors.selectedEmployees}
            SelectProps={{
              multiple: true,
              renderValue: (selected) => (
                <div>
                  {selected.map((empId) => {
                    const employee = employees.find(
                      (emp) => emp.emp_id === empId
                    );
                    return (
                      <div key={empId}>{employee ? employee.emp_name : ""}</div>
                    );
                  })}
                </div>
              ),
            }}
          >
            {employees.map((emp) => (
              <MenuItem key={emp.emp_id} value={emp.emp_id}>
                {emp.emp_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Allocation Date"
            type="date"
            InputLabelProps={{
              shrink: true,
            }}
            name="allocation_date"
            value={formData.allocation_date}
            onChange={handleInputChange}
            error={!!errors.allocation_date}
            helperText={errors.allocation_date}
          />
        </Grid>
      </Grid>

      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "25px" }}
      >
        <Button
          onClick={handleSubmit}
          style={{
            backgroundColor: "#1B9C85",
            borderColor: "#1B9C85",
            color: "white",
          }}
        >
          Submit
        </Button>
      </div>

      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "25px" }}
      >
        <Button
          onClick={calculateTotalHours}
          style={{
            backgroundColor: "#1B9C85",
            borderColor: "#1B9C85",
            color: "white",
          }}
        >
          Calculate Total Hours
        </Button>
      </div>

      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "25px" }}
      >
        <p>Total Working Days: {workingDays.length}</p>
      </div>

      {/* <div style={{ display: "flex", justifyContent: "center", marginTop: "25px" }}>
          <p>Total Holidays: {selectedHolidays.length}</p>
          </div> */}

      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "25px" }}
      >
        <p>Total Working Hours: {totalHours}</p>
      </div>
      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "25px" }}
      >
        {workingDayCounts && <div>{workingDayCounts}</div>}
      </div>
    </div>
  );
}

export default AddProject;
