import axios from 'axios';
import moment from "moment";
import React, { useEffect, useState } from 'react';
import config from '../../../config';
import './FollowingDashboard.css';
import { Avatar } from '@mui/material';

function FollowingDashboard() {
    const [reminderData, setReminderData] = useState([]);
    const [specifiedEmpCust, setSpecifiedEmpCust] = useState([]);

    useEffect(() => {
        axios.get(`${config.apiUrl}/custMain/allEmpReminderDates`)
            .then((res) => {
                setReminderData(res.data);
            })
            .catch((error) => {
                console.error("Error:", error);
            });
    }, []);

    const currentDate = moment().format('YYYY-MM-DD');

    useEffect(() => {
        const allEmployeeData = reminderData.filter(emp => emp.reminder_date === currentDate);
        const uniqueEmpIds = [...new Set(allEmployeeData.map(emp => emp.emp_id))];

        const specifiedEmpCustData = uniqueEmpIds.map(empId => {
            const filteredCustData = reminderData.filter(cust => cust.emp_id === empId);
            const empDetails = filteredCustData[0]; // Get employee details
            return {
                emp_id: empId,
                emp_img: empDetails.emp_img, // Access emp_img from employee details
                emp_name: empDetails.emp_name,
                followup_count: filteredCustData.length,
                cust_details: filteredCustData.map(cust => ({ cust_name: cust.cust_name, reminder_date: cust.reminder_date }))
            };
        });
        setSpecifiedEmpCust(specifiedEmpCustData);
    }, [reminderData]);

    const handleCountClick = (custNames) => {
        alert(`Following Customers: ${custNames.join(', ')}`);
    };

    return (
        <div>
            <h2 className='text-center'>Today Follow up</h2>
            <div className="card-row-container">
                {specifiedEmpCust.map(emp => (
                    <div className="flip-card" key={emp.emp_id}>
                        <div className="flip-card-inner">
                            
                            <div className="flip-card-front">
                            <div style={{display:'flex',justifyContent:'center'}}>
                            <Avatar>
                                {emp.emp_img && ( // Ensure emp_img exists
                                    <img
                                        src={`data:image/jpeg;base64,${emp.emp_img}`}
                                        style={{ maxWidth: '80px', maxHeight: '100px' }}
                                        alt={`Employee ${emp.emp_name}`}
                                    />
                                )}
                            </Avatar>
                            </div>
                                <h2>{emp.emp_name}</h2>
                                <h1>{emp.followup_count}</h1>
                                <p>Hover Me</p>
                            </div>
                            <div className="flip-card-back">
                                <h2>Customers</h2>
                                <ul className='me-4'>
                                    {emp.cust_details.map(cust => (
                                        <h5 key={cust.cust_name}>
                                            {cust.cust_name}
                                        </h5>
                                    ))}
                                </ul>
                                {/* <p>Leave Me</p> */}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default FollowingDashboard;
