import { NavLink } from "react-router-dom";
// import { FaBars, FaHome, FaLock, FaMoneyBill, FaThList, FaUser } from "react-icons/fa";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import SideNavMenu from "./SideNavMenu";
import { IoFilterSharp } from "react-icons/io5";
import './Sidenav.css'
import {
    FaTh,
    FaBars,
    FaUserAlt,
    FaRegChartBar,
    FaCommentAlt,
    FaShoppingBag,
    FaThList
} from "react-icons/fa";
import { FaCircleUser, FaUserLarge, FaUserTie,FaUserPlus } from "react-icons/fa6";
import { GoProjectSymlink, GoTasklist } from "react-icons/go";
import { RiSoundModuleLine } from "react-icons/ri";

const routes = [
  
    {
        path: "/",
        name: "Dashboard",
        icon: <FaTh  className="react-iconss"/>
    },
    {
        path: "/emp_index",
        name: "Employee Index",
        icon: <FaCircleUser className="react-iconss" />
    },
    {
        path: "/cust_index",
        name: "Customer Index",
        icon: <FaUserLarge className="react-iconss" />
    },
    {
        path: "/leads_index",
        name: "Leads Index",
        icon: <FaUserTie className="react-iconss" />
    },
    {
        path: "/projectindex",
        name: "Project Index",
        icon: <GoProjectSymlink  className="react-iconss" />
    },
    {
        path: "/markcustomer",
        name: "Marketing Customer Index",
        icon: <GoProjectSymlink  className="react-iconss" />
    },
    {
        path: "/marketingreport",
        name: "Marketing Report",
        icon: <IoFilterSharp  className="react-iconss" />
    },
    // {
    //     path: "/moduleindex",
    //     name: "Module Index",
    //     icon: <RiSoundModuleLine className="react-iconss" />
    // },
    
    // {
    //     path: "/submoduleindex",
    //     name: "Sub Module Index",
    //     icon: <FaThList className="react-iconss" />
    // },
    // {
    //     path: "/taskindex",
    //     name: "Task Index",
    //     icon: <GoTasklist className="react-iconss" />
    // },
    {
        path: "/adminCustFollowup",
        name: "Customer Followups",
        icon: <FaUserPlus className="react-iconss" />
    },
    {
        path: "/adminCustmainreport",
        name: "Report",
        icon: <IoFilterSharp className="react-iconss" />
    },
    {
        path: "/followingreport",
        name: "Following Report",
        icon: <IoFilterSharp className="react-iconss" />
    },
];

const SideNav = ({ children }) => {
  const [isOpen, setIsOpen] = useState(true);
  const toggle = () => setIsOpen(!isOpen);
  const inputAnimation = {
    hidden: {
      width: 0,
      padding: 0,
      transition: {
        duration: 0.2,
      },
    },
    show: {
      width: "140px",
      padding: "5px 15px",
      transition: {
        duration: 0.2,
      },
    },
  };

  const showAnimation = {
    hidden: {
      width: 0,
      opacity: 0,
      transition: {
        duration: 0.5,
      },
    },
    show: {
      opacity: 1,
      width: "auto",
      transition: {
        duration: 0.5,
      },
    },
  };

  return (
    <>
      <div className="main-containerr">
        <motion.div
          animate={{
            width: isOpen ? "240px" : "55px",

            transition: {
              duration: 0.5,
              type: "spring",
              damping: 10,
            },
          }}
          className={`sidebarr `}
        >
          <div className="top_sectionn">
            <AnimatePresence>
              {isOpen && (
                <motion.h1
                  variants={showAnimation}
                  initial="hidden"
                  animate="show"
                  exit="hidden"
                  className="logo mt-2"
                  style={{fontWeight:'bold',fontSize:'35px',fontFamily:'Roboto'}}
                >
                  CRM
                </motion.h1>
              )}
            </AnimatePresence>

            <div className="barss" style={{marginLeft: isOpen ? '':'14px'}}>
              <FaBars onClick={toggle} size={30}/>
            </div>
          </div>
          {/* <div className="search">
            <div className="search_icon">
              <BiSearch />
            </div>
            <AnimatePresence>
              {isOpen && (
                <motion.input
                  initial="hidden"
                  animate="show"
                  exit="hidden"
                  variants={inputAnimation}
                  type="text"
                  placeholder="Search"
                />
              )}
            </AnimatePresence>
          </div> */}
          <section className="routes">
            {routes.map((route, index) => {
              if (route.subRoutes) {
                return (
                  <SideNavMenu
                    setIsOpen={setIsOpen}
                    route={route}
                    showAnimation={showAnimation}
                    isOpen={isOpen}
                  />
                );
              }

              return (
                <NavLink
                  to={route.path}
                  key={index}
                  className="link"
                  activeClassName="active"
                >
                  <div className="icon">{route.icon}</div>
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        variants={showAnimation}
                        initial="hidden"
                        animate="show"
                        exit="hidden"
                        className="link_text"
                      >
                        {route.name}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </NavLink>
              );
            })}
          </section>
        </motion.div>

        <div className="mainn">
        <main>{children}</main>
        </div>
      </div>
    </>
  );
};

export default SideNav;




// import React, { useState } from 'react';
// import {
//     FaTh,
//     FaBars,
//     FaUserAlt,
//     FaRegChartBar,
//     FaCommentAlt,
//     FaShoppingBag,
//     FaThList
// } from "react-icons/fa";
// import './Sidenav.css'
// import { NavLink } from 'react-router-dom';


// const SideNav = ({ children }) => {
//     const [isOpen, setIsOpen] = useState(true);
//     const toggle = () => setIsOpen(!isOpen);
//     const menuItem = [
        // {
        //     path: "/",
        //     name: "Dashboard",
        //     icon: <FaTh />
        // },
        // {
        //     path: "/emp_index",
        //     name: "Employee Index",
        //     icon: <FaUserAlt />
        // },
        // {
        //     path: "/cust_index",
        //     name: "Customer Index",
        //     icon: <FaRegChartBar />
        // },
        // {
        //     path: "/projectindex",
        //     name: "Project Index",
        //     icon: <FaTh />
        // },
        // {
        //     path: "/moduleindex",
        //     name: "Module Index",
        //     icon: <FaTh />
        // },
        
        // {
        //     path: "/submoduleindex",
        //     name: "Sub Module Index",
        //     icon: <FaThList />
        // },
        // {
        //     path: "/taskindex",
        //     name: "Task Index",
        //     icon: <FaShoppingBag />
        // }
        
//     ]
//     return (
//         <div className="container" >
//             <div style={{ width: isOpen ? "250px" : "50px" }} className="sidebar">
//                 <div className="top_section">
//                     {/* <h1 style={{ display: isOpen ? "block" : "none" }} className="logo">Logo</h1>
//                     <div style={{ marginLeft: isOpen ? "50px" : "0px" }} className="bars">
//                         <FaBars onClick={toggle} />
//                     </div> */}
//                 </div>
//                 {
//                     menuItem.map((item, index) => (
//                         <NavLink to={item.path} key={index} className="link" style={{textDecoration:'none'}}>
//                             <div className="icon">{item.icon}</div>
//                             <div style={{ display: isOpen ? "block" : "none" }} className="link_text">{item.name}</div>
//                         </NavLink>
//                     ))
//                 }
//             </div>
//             <main>{children}</main>
//         </div>
//     );
// };

// export default SideNav;