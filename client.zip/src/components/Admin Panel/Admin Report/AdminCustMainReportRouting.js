import React, { useState } from 'react'
import SideNav from '../SideNav/SideNav';
import TopNav from '../TopNav/TopNav';
import AdminCustMainReportTable from './AdminCustMainReportTable';
import AdminReportForm from './AdminReportForm';


function AdminCustMainReportRouting() {
  const [reportData, setReportData] = useState([]);

  const updateReportData = (data) => {
    setReportData(data);
  };

  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchInputChange = (query) => {
    setSearchQuery(query);
  };
  return (
    <div style={{display:'flex',overflow:'hidden',minHeight:'700px'}}>

     
      <SideNav/>
      
      
     
      <div style={{overflowY:'hidden',flexGrow:'1',marginLeft:'-20px'}}>
        <TopNav onSearchInputChange={handleSearchInputChange}/>
        <div style={{marginLeft:'20px',marginRight:'20px'}}>
        <AdminReportForm  setReportData={updateReportData}/>
          
            <AdminCustMainReportTable reportData={reportData} searchQuery={searchQuery} />
        
        </div>
        </div>
        
      </div>
     
      
     
  
  )
}

export default AdminCustMainReportRouting

