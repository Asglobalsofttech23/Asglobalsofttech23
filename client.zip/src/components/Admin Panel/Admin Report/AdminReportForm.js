import { Button, Grid, MenuItem, TextField } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import config from "../../../config";

const districtData = [
  "Ariyalur",
  "Chengalpattu",
  "Chennai",
  "Coimbatore",
  "Cuddalore",
  "Dharmapuri",
  "Dindigul",
  "Erode",
  "Kallakurichi",
  "Kanchipuram",
  "Kanyakumari",
  "Karur",
  "Krishnagiri",
  "Madurai",
  "Nagapattinam",
  "Namakkal",
  "Nilgiris",
  "Perambalur",
  "Pudukkottai",
  "Ramanathapuram",
  "Ranipet",
  "Salem",
  "Sivaganga",
  "Tenkasi",
  "Thanjavur",
  "Theni",
  "Thoothukudi",
  "Tiruchirappalli",
  "Tirunelveli",
  "Tirupathur",
  "Tiruppur",
  "Tiruvallur",
  "Tiruvannamalai",
  "Tiruvarur",
  "Vellore",
  "Viluppuram",
  "Virudhunagar",
];
function AdminReportForm({ setReportData }) {
  const [selectedcategory, setSelectedCategory] = useState("");
  const [f_date, setF_date] = useState("");
  const [to_date, setTo_date] = useState("");
  const [cust_email, setCustEmail] = useState(""); 
  const [emp_id, setEmpId] = useState(""); 
  const [customerEmails, setCustomerEmails] = useState([]); 
  const [employeeIds, setEmployeeIds] = useState([]); 
  const [dist,setDist ] = useState(); 
  const [city, setCity] = useState(); 
  useEffect(() => {
    axios.get(`${config.apiUrl}/custMain/getCustMainDataAdmin`)
      .then((response) => {
        setCustomerEmails(response.data);
        setEmployeeIds(response.data);
      })
      .catch((error) => {
        console.error("Error fetching customer and employee data:", error);
      });
  }, []);

  const handleReport = (e) => {
    e.preventDefault();
    axios
      .get(
        `${config.apiUrl}/custMain/adminFilter`,
        {
          params: {
            category: selectedcategory,
            fromDate: f_date,
            toDate: to_date,
            cust_email: cust_email,
            emp_id: emp_id,
            dist: dist,
            city: city,
          }
        }
      )
      .then((response) => {
        setReportData(response.data);
        console.log("Report Data:", response.data);
      })
      .catch((error) => {
        console.error("Error fetching report data:", error);
      });
  };


  return (
    <>
      <div>
        <h1 className="text-center">Report</h1>
        <div>
          <Grid container spacing={3}>
            <Grid item xs={6}>
              <TextField
                fullWidth
                select
                label="Select Customer"
                name="cust_email"
                value={cust_email}
                onChange={(e) => setCustEmail(e.target.value)}
              >
                {customerEmails.map((cust) => (
                  <MenuItem key={cust.cust_main_id} value={cust.cust_email}>
                    {cust.cust_email}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={6}>
              <TextField
                select
                fullWidth
                label="Select Employee"
                name="emp_id"
                value={emp_id}
                onChange={(e) => setEmpId(e.target.value)}
              >
                {employeeIds.map((emp) => (
                  <MenuItem key={emp.cust_main_id} value={emp.emp_id}>
                    {emp.emp_name}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="From Date"
                name="f_name"
                type="date"
                onChange={(e) => setF_date(e.target.value)}
                value={f_date}
                InputLabelProps={{shrink:true}}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="To Date"
                name="to_date"
                type="date"
                onChange={(e) => setTo_date(e.target.value)}
                value={to_date}
                InputLabelProps={{shrink:true}}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                select
                fullWidth
                name="dist"
                label="Select District"
                onChange={(e) => setDist(e.target.value)}
                value={dist}
              >
                {districtData.map((dist, index) => (
                  <MenuItem key={index} value={dist}>{dist}</MenuItem>
                ))}
              </TextField>
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                select
                name="city"
                label="Select City"
                onChange={(e) => setCity(e.target.value)}
                value={city}
              >
                {customerEmails.map((city,index)=>(
                  <MenuItem key={index} value={city.city}>{city.city}</MenuItem>
                ))}
                
              </TextField>
            </Grid>
            <Grid item xs={12}>
              <TextField
                select
                fullWidth
                label="Select Category"
                name="selectedcategory"
                onChange={(e) => setSelectedCategory(e.target.value)}
                value={selectedcategory}
              >
                <MenuItem value='1'>1st Priority</MenuItem>
                <MenuItem value='2'>2nd Priority</MenuItem>
                <MenuItem value='3'>3rd Priority</MenuItem>
                <MenuItem value='4'>4th Priority</MenuItem>
              </TextField>
            </Grid>
          </Grid>
        </div>
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '10px' }}>
          <Button variant="contained" onClick={handleReport}>Generate Report</Button>
        </div>
      </div>
    </>
  );
}

export default AdminReportForm;
