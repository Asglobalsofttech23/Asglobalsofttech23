import { Button, Checkbox, Menu, MenuItem, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import React, { useEffect, useState } from 'react'
import * as XLSX from 'xlsx';

function FollowingReportTable({reportData , searchQuery}) {

  useEffect(() => {
    const highlightColor = 'black';
    const unhighlightColor = 'initial';
    const highlightBackground = 'yellow';
    const unhighlightBackground = 'white';
  
    const tableCells = document.querySelectorAll('td'); // Select all table cells or specific cells where you want to apply the highlight
  
    tableCells.forEach((cell) => {
      const cellText = cell.textContent;
      const searchQueryLC = searchQuery.toLowerCase();
      
      // Split the text content of the cell into parts based on the search query
      const parts = cellText.split(new RegExp(`(${searchQueryLC})`, 'gi'));
      
      // Recreate the inner HTML of the cell to highlight the matched parts
      cell.innerHTML = parts.map(part => {
        if (part.toLowerCase() === searchQueryLC) {
          return `<span style="color: ${highlightColor}; background-color: ${highlightBackground}">${part}</span>`;
        } else {
          return part;
        }
      }).join('');
    });
  }, [searchQuery]);


    const customers = reportData

    const [selectedRows, setSelectedRows] = useState([]);
  
  const [selectAll, setSelectAll] = useState(false);

    const [anchorEl, setAnchorEl] = useState(null);
  
  
      const handleClick = (event) => {
          setAnchorEl(event.currentTarget);
      };

      const handleClose = () => {
        setAnchorEl(null);
    };


    
    const handleRowSelect = (cust_id) => {
        const selectedIndex = selectedRows.indexOf(cust_id);
        let newSelected = [];
    
        if (selectedIndex === -1) {
          newSelected = newSelected.concat(selectedRows, cust_id);
        } else if (selectedIndex === 0) {
          newSelected = newSelected.concat(selectedRows.slice(1));
        } else if (selectedIndex === selectedRows.length - 1) {
          newSelected = newSelected.concat(selectedRows.slice(0, -1));
        } else if (selectedIndex > 0) {
          newSelected = newSelected.concat(
            selectedRows.slice(0, selectedIndex),
            selectedRows.slice(selectedIndex + 1)
          );
        }
    
        setSelectedRows(newSelected);
      };
    
    
    
    
      const handleSelectAll = () => {
        if (selectAll) {
          setSelectedRows([]);
        } else {
          const allCustIds = customers.map((cust) => cust.cust_id);
          setSelectedRows(allCustIds);
        }
        setSelectAll(!selectAll);
      };
    

    const exportDataToCSV = () => {
        const selectedData = customers.filter((cust) => selectedRows.includes(cust.cust_id));
    
        const csvData = selectedData.map((cust, index) => ({
          'Customer ID': cust.cust_id,
          'Employee ID': cust.emp_id,
          'Employee Name': cust.emp_name,
          'Customer Name': cust.cust_name,
          'Customer Email': cust.cust_email,
          // 'Customer Mobile': cust.cust_mobile,
          'Bussiness Name': cust.bus_name,
          'Bussiness Category': cust.bus_category,
          'Priority' : cust.category,
          'District' : cust.dist,
          'City' : cust.city,
          'Notes' : cust.notes,
          'Last Follow Up Date': cust.cur_follow_up_date,
          'Customer Available Date': cust.cus_avail_date,
         
        }));
    
        const csvString = 'Customer ID,Employee ID,Employee Name,Customer Name,Customer Email,Bussiness Name,Bussiness Category,Priority ,District,City,Notes, Last Follow Up Date,Customer Available Date\n' +
          csvData.map(row => Object.values(row).join(',')).join('\n');
    
        const blob = new Blob([csvString], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
    
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = 'selected_data.csv';
    
        document.body.appendChild(a);
        a.click();
    
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      };
    
    
    
      const handleExcelExport = () => {
        const excelData = customers.map(({cust_id,emp_id,emp_name,cust_name,cust_email,bus_name,bus_category,category,dist,city,notes,cur_follow_up_date,cus_avail_date}, index) => [
            index + 1,
            emp_id,
            emp_name,
            cust_name,
            cust_email,
            bus_name,
            bus_category,
            category,
            dist,
            city,
            notes,
            cur_follow_up_date,
            cus_avail_date
     
        ]);
    
        const ws = XLSX.utils.aoa_to_sheet([['S.no', 'Employee ID', 'Employee Name', 'Customer Name','Customer Email', 'Customer Bussiness Name','Customer Business Category', 'Priority','District','City','Notes', 'Last Follow Up Date' , 'Customer Available Date'], ...excelData]);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Sheet 1');
        XLSX.writeFile(wb, 'project_data.xlsx');
    };
    
    const handleJSONExport = () => {
        const jsonData = JSON.stringify(customers, null, 2); // The '2' parameter adds indentation for better readability
        const blob = new Blob([jsonData], { type: 'application/json' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'project_data.json';
        link.click();
    };


    
  // Pagination
  const [itemsPerPage, setItemsPerPage] = useState(5); // Change the default value to 5
  const [currentPage, setCurrentPage] = useState(1);
  
  const handleItemsPerPageChange = (event) => {
    const newItemsPerPage = parseInt(event.target.value, 10);
    setItemsPerPage(newItemsPerPage);
    setCurrentPage(1); // Reset to the first page when changing items per page
  };
  
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = customers.slice(indexOfFirstItem, indexOfLastItem);
  
    

  return (

    <div>
        <h1 className='text-center'>Report Data</h1>
      <div className='row'>
            <div className='col-6'>
            <Button
        style={{ backgroundColor: '#1B9C85', borderColor: '#1B9C85', color: 'white' }}
        onClick={handleClick}
        onMouseEnter={handleClick}
      >
        Export data
      </Button>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleClose}
         // Close the menu on mouse leave
      >
        <MenuItem onClick={exportDataToCSV} >Export as CSV</MenuItem>
        <MenuItem onClick={handleExcelExport} >Export as Excel</MenuItem>
        <MenuItem onClick={handleJSONExport} onMouseOut={handleClose}>Export as JSON</MenuItem>
      </Menu>
            
            </div>
            
            <div className='col-6 me-end'>
            <div  style={{ marginBottom: '20px', marginLeft: '100px' }}>
             
  
              <select
                value={itemsPerPage} onChange={handleItemsPerPageChange}
                style={{
                  padding: '5px 10px',
                  margin: '0 5px',
                  border: '1px solid #007bff',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: '#fff',
                  color: '#007bff',
                  textDecoration: 'none',
                  transition: 'background-color 0.3s, color 0.3s',
                }}
              >
                <option value="5">5 Per Page</option>
                <option value="10">10  Per Page</option>
                <option value="15">15  Per Page</option>
                <option value="0">All  Per Page</option>
              </select>
            </div>
            </div>
            
          </div>


          <TableContainer component={Paper} className='mt-2'>
          <Table style={{ borderCollapse: 'collapse' }}>
            <TableHead style={{backgroundColor:'#1B9C85'}}>
              <TableRow>
                <TableCell style={{ border: '1px solid #ddd' }}>
                <Checkbox
                        checked={selectAll}
                        onChange={handleSelectAll}
                      />
                </TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>S.No</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Employee Name</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Customer Name</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Customer Email</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Bussiness Name</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Bussiness Category</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Priority</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>District</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>City</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Notes</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Current FollowUp Date</TableCell>
                <TableCell style={{ border: '1px solid #ddd',color:'whitesmoke' }}>Customer Avilable Date</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
            {currentItems.map((cust, index) => (
                    <TableRow key={cust.cust_id + '_' + index} style={{ backgroundColor: index % 2 === 0 ? '#f2f2f2' : 'white' }}>
  
                      <TableCell style={{ border: '1px solid #ddd' }}>
                      <Checkbox
                          checked={selectedRows.includes(cust.cust_id)}
                          onChange={() => handleRowSelect(cust.cust_id)}
                        />
                      </TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{index + 1}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.emp_name}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.cust_name}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.cust_email}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.bus_name}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.bus_category}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.category}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.dist}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.city}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.notes}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.cur_follow_up_date}</TableCell>
                      <TableCell style={{ border: '1px solid #ddd' }}>{cust.cus_avail_date}</TableCell>
                      
                    </TableRow>
                  ))}
            </TableBody>
          </Table>
        </TableContainer>
    </div>
  )
}

export default FollowingReportTable

