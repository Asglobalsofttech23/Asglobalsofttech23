import axios from 'axios';
import React, { useEffect, useState } from 'react';
import config from '../../../config';
import { Button, Grid, MenuItem, TextField } from '@mui/material';

const districtData = [
    "Ariyalur", "Chengalpattu", "Chennai", "Coimbatore", "Cuddalore", "Dharmapuri", "Dindigul", "Erode",
    "Kallakurichi", "Kanchipuram", "Kanyakumari", "Karur", "Krishnagiri", "Madurai", "Nagapattinam", "Namakkal",
    "Nilgiris", "Perambalur", "Pudukkottai", "Ramanathapuram", "Ranipet", "Salem", "Sivaganga", "Tenkasi",
    "Thanjavur", "Theni", "Thoothukudi", "Tiruchirappalli", "Tirunelveli", "Tirupathur", "Tiruppur", "Tiruvallur",
    "Tiruvannamalai", "Tiruvarur", "Vellore", "Viluppuram", "Virudhunagar"
];

function FollowingReportForm({setReportData}) {
    const [reportForm, setReportForm] = useState({
        emp_id: '',
        category: '',
        dist: '',
        city: '',
        f_date: '',
        to_date: '',
    });
    // const [reportData, setReportData] = useState([]);
    const [employeeData, setEmployeeData] = useState([]);
    const [city, setCity] = useState([]);

    useEffect(() => {
        axios.get(`${config.apiUrl}/custMain/getEmployeeByCustMainEmpId`)
            .then((res) => {
                setEmployeeData(res.data);
            })
            .catch((error) => {
                console.error('Error :', error);
            });

        axios.get(`${config.apiUrl}/custMain/getCustMainDataAdmin`)
            .then((res) => {
                setCity(res.data);
            })
            .catch((error) => {
                console.error("Error :", error);
            });
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setReportForm({ ...reportForm, [name]: value });
    };

    const handleReport = (e) => {
        e.preventDefault();
        axios.get(`${config.apiUrl}/custMain/filter`, {
            params: {
                emp_id: reportForm.emp_id,
                category: reportForm.category,
                fromDate: reportForm.f_date,
                toDate: reportForm.to_date,
                dist: reportForm.dist,
                city: reportForm.city,
            },
        })
            .then((response) => {
                setReportData(response.data);
            })
            .catch((error) => {
                console.error("Error Report is not fetched ");
            });
    };

    return (
        <div className='mt-2'>
            <h1 className='text-center'>Following Report</h1>
            <Grid container spacing={3}>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                    <TextField
                        select
                        fullWidth
                        label='Select Employee'
                        name='emp_id'
                        onChange={handleInputChange}
                        value={reportForm.emp_id}
                    >
                        {employeeData.map((emp) => (
                            <MenuItem key={emp.emp_id} value={emp.emp_id}>{emp.emp_name}</MenuItem>
                        ))}
                    </TextField>
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                    <TextField
                        fullWidth
                        select
                        name='category'
                        label='Select Category'
                        value={reportForm.category}
                        onChange={handleInputChange}
                    >
                        <MenuItem value='1'>1st Category</MenuItem>
                        <MenuItem value='2'>2nd Category</MenuItem>
                        <MenuItem value='3'>3rd Category</MenuItem>
                        <MenuItem value='4'>4th Category</MenuItem>
                    </TextField>
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                    <TextField
                        fullWidth
                        select
                        name="dist"
                        label="Select District"
                        onChange={handleInputChange}
                        value={reportForm.dist}
                    >
                        {districtData.map((dist, index) => (
                            <MenuItem key={index} value={dist}>
                                {dist}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                    <TextField
                        fullWidth
                        select
                        name="city"
                        label="Select City"
                        onChange={handleInputChange}
                        value={reportForm.city}
                    >
                        {city.map((city, index) => (
                            <MenuItem key={index} value={city.city}>
                                {city.city}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                    <TextField
                        fullWidth
                        label="From Date"
                        name="f_date"
                        type="date"
                        onChange={handleInputChange}
                        value={reportForm.f_date}
                        InputLabelProps={{ shrink: true }}
                    />
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                    <TextField
                        fullWidth
                        label="To Date"
                        name="to_date"
                        type="date"
                        onChange={handleInputChange}
                        value={reportForm.to_date}
                        InputLabelProps={{ shrink: true }}
                    />
                </Grid>
                <Grid style={{marginTop:'20px',marginLeft:'550px'}}>
          <Button variant="contained" onClick={handleReport}>
            Generate Report
          </Button>
        </Grid>
            </Grid>
        </div>
    );
}

export default FollowingReportForm;
