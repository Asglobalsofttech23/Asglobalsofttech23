// import React from 'react'
// import TopNav from '../TopNav/TopNav'
// import SideNav from '../SideNav/SideNav'
// import Dashboard from './Dashboard'

// function DashboardRouting() {
//   return (
//     <div style={{overflow:'hidden'}}>
//       <TopNav/>
//       <div className='row' style={{marginLeft:'-23.7px'}}>
//       <div className='col-3'>
//       <SideNav/>
//       </div>
//       <div className='col-9 mt-4'>
//        <Dashboard/>
//       </div>
//       </div>
//     </div>
//   )
// }

// export default DashboardRouting


import React from 'react'
import TopNav from '../TopNav/TopNav'
import SideNav from '../SideNav/SideNav'
import Dashboard from './Dashboard'

function DashboardRouting() {
  return (
    <div style={{display:'flex'}}>
       <SideNav/>
       <div style={{display:'column'}}>
        <div style={{marginLeft:'-20px'}}>
          <TopNav/>
        </div>
        <div style={{marginLeft:'10px'}}>
          <Dashboard/>
        </div>
       </div>
    </div>
  )
}

export default DashboardRouting
