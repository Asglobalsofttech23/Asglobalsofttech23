import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Button,
  Card,
  CardContent,
  Dialog,
  DialogActions,
  DialogContent,
  Grid,
  Paper,
  Typography,
} from "@mui/material";
import { Bar, Doughnut, Line, Pie, PolarArea, Radar } from "react-chartjs-2";
import Chart from "chart.js/auto";
import "./Dashboard.css";
// import { FaUserTie } from "react-icons/fa6";
import { FaUserLarge, FaUsers } from "react-icons/fa6";
import { LinearScale, CategoryScale } from "chart.js";
import { GoProjectSymlink } from "react-icons/go";
import { FaUserClock } from "react-icons/fa6";
import ProjectDashboard from "../Projects/Project Dashboard/ProjectDashboard";
import ProjectCount from "../Projects/Project Dashboard/ProjectCount";
import EntryList from "../Attendance/EntryList";
import config from "../../../config";
import FollowingDashboard from "../Following Data/FollowingDashboard";
// Register the required scales
Chart.register(LinearScale, CategoryScale);

function Dashboard() {
  const [employeeCount, setEmployeeCount] = useState(0);
  const [customerCount, setCustomerCount] = useState(0);
  const [projectCount, setProjectCount] = useState(0);

  const [openEntryForm, setOpenEntryForm] = useState(false);

  const [todayEmpEntry, setTodayEmpEntry] = useState(0);



  useEffect(() => {
    
    axios.get(`${config.apiUrl}/employees`)
      .then((response) => {
        setEmployeeCount(response.data.length);
      })
      .catch((error) => {
        console.error("Error fetching employees data:", error.message);
        // Handle the error as needed, e.g., show an error message to the user
      });
  
   
    axios.get(`${config.apiUrl}/customers`)
      .then((response) => {
        setCustomerCount(response.data.length);
      })
      .catch((error) => {
        console.error("Error fetching customers data:", error.message);
        // Handle the error as needed, e.g., show an error message to the user
      });
  
    axios.get(`${config.apiUrl}/project/dashboardproject`)
      .then((response) => {
        setProjectCount(response.data.length);
      })
      .catch((error) => {
        console.error("Error fetching projects data:", error.message);
        // Handle the error as needed, e.g., show an error message to the user
      });
  
    // Fetch attendance data
    axios.get(`${config.apiUrl}/attendance`)
      .then((response) => {
        setTodayEmpEntry(response.data.length);
      })
      .catch((error) => {
        console.error("Error fetching attendance data:", error.message);
        // Handle the error as needed, e.g., show an error message to the user
      });
  }, []);
  

  // Function to generate a random color
  const getRandomColor = () => {
    const letters = "0123456789ABCDEF";
    let color = "#";
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  };

  // Sample data for various charts
  const barChartData = {
    labels: ["Employees", "Customers", "Projects"],
    datasets: [
      {
        label: "Count",
        data: [employeeCount, customerCount, projectCount],
        backgroundColor: [getRandomColor(), getRandomColor(), getRandomColor()],
        borderWidth: 1,
      },
    ],
  };

  const pieChartData = {
    labels: ["Employees", "Customers", "Projects"],
    datasets: [
      {
        data: [employeeCount, customerCount, projectCount],
        backgroundColor: [getRandomColor(), getRandomColor(), getRandomColor()],
        borderWidth: 1,
      },
    ],
  };

  const lineChartData = {
    labels: ["January", "February", "March", "April", "May"],
    datasets: [
      {
        label: "Sales",
        data: [employeeCount, customerCount, projectCount],
        borderColor: getRandomColor(),
        borderWidth: 2,
        fill: false,
      },
    ],
  };

  const radarChartData = {
    labels: ["Employees", "Customers", "Projects"],
    datasets: [
      {
        label: "Data Set 1",
        data: [employeeCount, customerCount, projectCount],
        backgroundColor: getRandomColor(),
        borderWidth: 2,
      },
    ],
  };

  const polarAreaChartData = {
    labels: ["Employees", "Customers", "Projects"],
    datasets: [
      {
        data: [employeeCount, customerCount, projectCount],
        backgroundColor: [
          getRandomColor(),
          getRandomColor(),
          getRandomColor(),
          getRandomColor(),
          getRandomColor(),
        ],
        borderWidth: 1,
      },
    ],
  };

  const doughnutChartData = {
    labels: ["Category A", "Category B", "Category C"],
    datasets: [
      {
        data: [40, 30, 30],
        backgroundColor: [getRandomColor(), getRandomColor(), getRandomColor()],
        borderWidth: 1,
      },
    ],
  };
  return (
    <>
      <div style={{marginTop:'10px',marginRight:'20px'}}>
        <Grid container spacing={3}>
          <Grid item  lg={3} md={3} sm={3} xs={6}>
            <Card component={Paper} className="card">
            <a class="card1" href="#">
              <div className="row">
                <div className="col-8">
                <CardContent>
                  <Typography variant="h6"
                   component="div"
                   className="text-center card-content"
                   style={{ fontWeight: "bold" }}
                   >
                    Employees
                  </Typography>
                  <Typography
                    className="text-center"
                    style={{ fontWeight: "bold", fontSize: "30px" }}
                  >
                    {employeeCount}
                  </Typography>
                </CardContent>
                </div>
                <div className="col-4">
                <div style={{marginRight:'10px',marginTop:'30px'}}>
                <FaUsers size={60} />
                </div>
                </div>
              </div>
              </a>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </Card>
          </Grid>
          <Grid item lg={3} md={3} sm={3} xs={6}>
            <Card component={Paper} className="card">
            <a class="card1" href="#">
             <div className="row">
              <div className="col-8">
              <CardContent>
                <Typography variant="h6"
                 component="div"
                 className="text-center card-content"
                 style={{fontWeight:'bolder'}}
                 >
                  Customers
                </Typography>
                <Typography
                  className="text-center "
                  style={{ fontWeight: "bold", fontSize: "30px" }}
                >
                  {customerCount}
                </Typography>
              </CardContent>
              </div>
              <div className="col-3">
              <div style={{marginRight:'10px',marginTop:'20px'}}>
              <FaUserLarge size={60} />
              </div>
              </div>
             </div>
             </a>
             <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </Card>
          </Grid>
          <Grid item lg={3} md={3} sm={3} xs={6}>
            <Card component={Paper} className="card">
            <a class="card1" href="#">
             <div className="row">
              <div className="col-8">
              <CardContent>
                <Typography 
                variant="h6" 
                component="div"
                className="text-center card-content"
                style={{fontWeight:'bolder'}}
                >
                  Projects
                </Typography>
                <Typography
                  className="text-center"
                  style={{ fontWeight: "bold", fontSize: "30px" }}
                >
                  {projectCount}
                </Typography>
              </CardContent>
              </div>
              <div className="col-4 mt-3">
              <div style={{marginRight:'10px',marginTop:'15px'}}>
              <GoProjectSymlink size={60} />
              </div>
              </div>
             </div>
             </a>
             <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </Card>
          </Grid>
          <Grid item lg={3} md={3} sm={3} xs={6}>
            <Card component={Paper} className="card">
            <a class="card1" href="#">
              <div className="row">
                <div className="col-8">
                <CardContent>
                <Typography variant="h6"
                 component="div"
                 className="text-center card-content"
                 style={{fontWeight:'bolder'}}
                 >
                  Entry
                </Typography>
                <Typography
                  className="text-center"
                  style={{ fontWeight: "bold", fontSize: "30px" }}
                >
                  {todayEmpEntry}
                </Typography>
              </CardContent>
                </div>
                <div className="col-4">
                <div style={{marginRight:'10px',marginTop:'30px'}}>
                  <FaUserClock size={60}/>
                  </div>
                </div>
              </div>
              </a>
              <div class="go-corner" href="#">
                <div class="go-arrow">→</div>
              </div>
            </Card>
          </Grid>

          <Grid item lg={6} md={6} sm={6} xs={12} >
            <Card style={{height:'345px'}}>
              <EntryList/>
            </Card>
          </Grid>
          

          <Grid item lg={6} md={6} sm={6} xs={12}>
            <Card>
              <Typography variant="h4" className="text-center">
                Project
              </Typography>
              <div style={{ marginLeft: "-30px" }}>
                <ProjectDashboard />
              </div>
            </Card>
          </Grid>
          
          <Grid item xs={12}  >
            {/* sx={{ backgroundColor: '#f0f0f0', padding: '20px', margin: '20px' }} */}
            <Card >   
              <ProjectCount />
            </Card>
          </Grid>
         
          <Grid item xs={12}  >
            {/* sx={{ backgroundColor: '#f0f0f0', padding: '20px', margin: '20px' }} */}
            <Card >   
              <FollowingDashboard/>
            </Card>
          </Grid>
          
          
          
        </Grid>
      </div>
    </>
  );
}

export default Dashboard;
