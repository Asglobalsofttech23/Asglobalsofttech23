// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { Button, Grid, MenuItem, TextField } from "@mui/material";

// function AddEmployee({ onClose }) {
//   const [departments, setDepartments] = useState([]);
//   const [roles, setRoles] = useState([]);
//   const [formData, setFormData] = useState({
//     role_id: "",
//     dept_id: "",
//     emp_name: "",
//     emp_email: "",
//     emp_mobile: "",
//     emp_img: "",
//     dept_name: "",
//     emp_role: "",
//     hire_date: "",
//   });

//   const [file, setFile] = useState(null);

//   const [formErrors, setFormErrors] = useState({
//     emp_name: "",
//     emp_email: "",
//     emp_mobile: "",
//     dept_id: "",
//     emp_role: "",
//     hire_date: "",
//   });

//   const validateField = (name, value) => {
//     let errorMsg = "";

//     const trimmedValue =
//       value && typeof value === "string" ? value.trim() : value;

//     switch (name) {
//       case "emp_name":
//         if (!trimmedValue) {
//           errorMsg = "Employee name is required";
//         }
//         break;
//       case "emp_email":
//         if (!trimmedValue) {
//           errorMsg = "Email is required";
//         } else if (!/\S+@\S+\.\S+/.test(trimmedValue)) {
//           errorMsg = "Enter a valid email address";
//         }
//         break;

//       case "emp_mobile":
//         if (!trimmedValue) {
//           errorMsg = "Mobile Number is required";
//         } else if(!/^\d{10}$/.test(trimmedValue)){
//           errorMsg="Enter a valid Mobile Number"
//         }
//         break;
//       case "dept_id":
//         if (!trimmedValue) {
//           errorMsg = "Please Select Department";
//         }
//         break;
      // case "emp_img":
      // if (!trimmedValue) {
      //   errorMsg = "Employee image is required";
      // } else {
      //   const allowedExtensions = ["jpg", "jpeg", "png", "gif"];
      //   const extension = trimmedValue.name.split(".").pop().toLowerCase();
      //   if (!allowedExtensions.includes(extension)) {
      //     errorMsg = "Please upload a valid image file (jpg, jpeg, png, gif)";
      //   }
      // }
      // break;
//       case "emp_role":
//         if (!trimmedValue) {
//           errorMsg = "Please Select Role";
//         }
//         break;
//       case "hire_date":
//         if (!trimmedValue) {
//           errorMsg = "Hire Date is Required";
//         } else {
//           const today = new Date();
//           const selectedDate = new Date(trimmedValue);
    
//           if (selectedDate < today) {
//             errorMsg = "Hire Date cannot be before the current date";
//           }
//         }
//         break;
//       default:
//         break;
//     }

//     return errorMsg;
//   };

//   const handleInputChange = (event) => {
//     const { name, value } = event.target;
//     const errorMsg = validateField(name, value);
//     setFormData({ ...formData, [name]: value });
//     setFormErrors({ ...formErrors, [name]: errorMsg });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();

//     // const errors = validateForm(formData);
//     // if (Object.keys(errors).length > 0) {
//     //   setFormErrors(errors);
//     //   return;
//     // }

//     const errors = {};
//     Object.keys(formData).forEach((fieldName) => {
//       const value = fieldName === "emp_img" ? file : formData[fieldName];
//       const errorMsg = validateField(fieldName, value);
//       errors[fieldName] = errorMsg;
//     });

//     setFormErrors(errors);

//     // If there are any errors, prevent form submission
//     if (Object.values(errors).some((error) => error !== "")) {
//       return;
//     }

//     try {
//       const formDataWithFile = new FormData();
//       formDataWithFile.append("role_id", formData.emp_role);
//       formDataWithFile.append("dept_id", formData.dept_id);
//       formDataWithFile.append("emp_name", formData.emp_name);
//       formDataWithFile.append("emp_email", formData.emp_email);
//       formDataWithFile.append("emp_mobile", formData.emp_mobile);
//       formDataWithFile.append("emp_img", file);
//       formDataWithFile.append("dept_name", formData.dept_name);
//       formDataWithFile.append(
//         "emp_role",
//         roles.find((role) => role.role_id === formData.emp_role)?.role
//       );
//       formDataWithFile.append("hire_date", formData.hire_date);

//       // const response = await axios.post(
//       //   "https://server-0flp.onrender.com/employees",
//       //   formDataWithFile
//       // );
//       const response = await axios.post('http://localhost:3001/employees', formDataWithFile);

//       // Log the submitted data and the response from the server
//       console.log("Submitted Data:", formData);
//       console.log("Server Response:", response.data);

//       console.log("Employee added successfully");
//       onClose();
//     } catch (error) {
//       console.error("Error adding employee:", error);
//     }
//   };

//   const handleDepartmentChange = (e) => {
//     const selectedDepartment = e.target.value;
//     const selectedDepartmentObject = departments.find(
//       (dept) => dept.dept_id === selectedDepartment
//     );

//     axios
//       // .get(
//       //   `https://server-0flp.onrender.com/roles?dept_id=${selectedDepartment}`
//       // )
//       .get(`http://localhost:3001/roles?dept_id=${selectedDepartment}`)
//       .then((response) => {
//         setRoles(response.data);
//       })
//       .catch((error) => {
//         console.error("Error fetching roles:", error);
//       });

//     // Revalidate form data
//     const name = "dept_id";
//     const value = selectedDepartment;
//     const errorMsg = validateField(name, value);

//     setFormErrors({
//       ...formErrors,
//       [name]: errorMsg,
//     });

//     setFormData({
//       ...formData,
//       dept_id: selectedDepartment,
//       dept_name: selectedDepartmentObject
//         ? selectedDepartmentObject.dept_name
//         : "", // Set dept_name
//       emp_role: "",
//       role_id: "", // Reset role_id when department changes
//     });
//   };

//   useEffect(() => {
//     axios
//       // .get("https://server-0flp.onrender.com/departments")
//       .get('http://localhost:3001/departments')
//       .then((response) => {
//         setDepartments(response.data);
//       })
//       .catch((error) => {
//         console.error("Error fetching departments:", error);
//       });
//   }, []);

//   return (
//     <div>
//       <h1 className="text-center" style={{ color: "#1B9C85" }}>
//         Add Employee
//       </h1>

//       <Grid container spacing={3} className="mt-2">
//         <Grid item xs={6}>
//           <TextField
//             fullWidth
//             label="Employee Name"
//             name="emp_name"
//             value={formData.emp_name}
//             onChange={handleInputChange}
//             error={Boolean(formErrors.emp_name)}
//             helperText={formErrors.emp_name}
//           />
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             fullWidth
//             label="Email"
//             name="emp_email"
//             value={formData.emp_email}
//             onChange={handleInputChange}
//             error={Boolean(formErrors.emp_email)}
//             helperText={formErrors.emp_email}
//           />
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             fullWidth
//             label="Mobile Number"
//             name="emp_mobile"
//             type="number"
//             value={formData.emp_mobile}
//             onChange={handleInputChange}
//             error={Boolean(formErrors.emp_mobile)}
//             helperText={formErrors.emp_mobile}
//           />
//         </Grid>
//         <Grid item xs={6}>
//   <TextField
//     type="file"
//     InputLabelProps={{ shrink: true }}
    // onChange={(e) => {
    //   const selectedFile = e.target.files[0];
    //   const errorMsg = validateField("emp_img", selectedFile);
    //   setFormErrors({ ...formErrors, emp_img: errorMsg });
    //   setFile(selectedFile);
    // }}
//     error={Boolean(formErrors.emp_img)}
//     helperText={formErrors.emp_img}
//   />
// </Grid>

//         <Grid item xs={6}>
//           <TextField
//             fullWidth
//             select
//             label="Department"
//             name="dept_id"
//             value={formData.dept_id}
//             onChange={handleDepartmentChange}
//             error={Boolean(formErrors.dept_id)}
//             helperText={formErrors.dept_id}
//           >
//             <MenuItem>Select Department</MenuItem>
//             {departments.map((dept) => (
//               <MenuItem key={dept.dept_id} value={dept.dept_id}>
//                 {dept.dept_name}
//               </MenuItem>
//             ))}
//           </TextField>
//         </Grid>

//         <Grid item xs={6}>
//           <TextField
//             fullWidth
//             select
//             label="Role"
//             name="emp_role"
//             value={formData.emp_role}
//             onChange={handleInputChange}
//             error={Boolean(formErrors.emp_role)}
//             helperText={formErrors.emp_role}
//           >
//             <MenuItem>Select Role</MenuItem>
//             {roles.map((role) => (
//               <MenuItem key={role.role_id} value={role.role_id}>
//                 {role.role}
//               </MenuItem>
//             ))}
//           </TextField>
//         </Grid>
//         <Grid item xs={6}>
//           <TextField
//             fullWidth
//             label="Hire Date"
//             type="date"
//             name="hire_date"
//             InputLabelProps={{
//               shrink: true,
//             }}
//             value={formData.hire_date}
//             onChange={handleInputChange}
//             error={Boolean(formErrors.hire_date)}
//             helperText={formErrors.hire_date}
//           />
//         </Grid>
//       </Grid>
//       <div
//         style={{ display: "flex", justifyContent: "center", marginTop: "25px" }}
//       >
//         <Button
//           onClick={handleSubmit}
//           style={{
//             backgroundColor: "#1B9C85",
//             borderColor: "#1B9C85",
//             color: "white",
//           }}
//           className="action-button3"
//         >
//           Submit
//         </Button>
//       </div>
//     </div>
//   );
// }

// export default AddEmployee;






import React, { useEffect, useState } from "react";
import axios from "axios";
import { Button, Grid, MenuItem, TextField } from "@mui/material";
import config from "../../../config";
import moment from "moment";
function AddEmployee({ onClose }) {
  const [departments, setDepartments] = useState([]);
  const [roles, setRoles] = useState([]);

  const [formData, setFormData] = useState({
    role_id: "",
    dept_id: "",
    emp_name: "",
    emp_email: "",
    emp_mobile: "",
    emp_img: null,
    hire_date: "",
  });

  const [errors, setErrors] = useState({
    role_id: "",
    dept_id: "",
    emp_name: "",
    emp_email: "",
    emp_mobile: "",
    emp_img: "",
    hire_date: "",
  });

  const handleValidation = (name, value) => {
    let errorMsg = "";
    const trimmedValue =
      value && typeof value === "string" ? value.trim() : value;
    switch (name) {
      case "emp_name":
        if (!trimmedValue) {
          errorMsg = "Employee Name is Required";
        }
        break;
      case "emp_email":
        if (!trimmedValue) {
          errorMsg = "Email Address is Required";
        } else if (!/\S+@\S+\.\S+/.test(trimmedValue)) {
          errorMsg = "Enter a valid email address";
        }
        break;
      case "emp_mobile":
        if (!trimmedValue) {
          errorMsg = "Employee Mobile Number is Required";
        } else if (!/^\d{10}$/.test(trimmedValue)) {
          errorMsg = "Enter a valid Mobile Number";
        }
        break;
      case "emp_img":
        if (!trimmedValue) {
          errorMsg = "Employee image is required";
        } else {
          const allowedExtensions = ["jpg", "jpeg", "png", "gif"];
          const extension = trimmedValue.name.split(".").pop().toLowerCase();
          if (!allowedExtensions.includes(extension)) {
            errorMsg =
              "Please upload a valid image file (jpg, jpeg, png, gif)";
          }
        }
        break;
      case "dept_id":
        if (!trimmedValue) {
          errorMsg = "Please select Department";
        }
        break;
      case "role_id":
        if (!trimmedValue) {
          errorMsg = "Please select Role";
        }
        break;
        case "hire_date":
          if (!trimmedValue) {
              errorMsg = "Hiring Date is Required";
          } else {
              const currentDate = moment();
              const selectedDate = moment(trimmedValue);
      
              if (!selectedDate.isValid()) {
                  errorMsg = "Invalid Date Format";
              } else if (selectedDate.isBefore(currentDate, 'day')) {
                  errorMsg = "Hiring Date must be the current date or a future date";
              }
          }
          break;
      
      default:
        break;
    }
    return errorMsg;
  };

  const handleFileChange = (selectedFile) => {
    if (!selectedFile) {
      // User canceled file selection, do nothing
      return;
    }

    const error = handleValidation("emp_img", selectedFile);
    setErrors({ ...errors, emp_img: error });

    if (!error) {
      setFormData((prevFormData) => ({
        ...prevFormData,
        emp_img: selectedFile,
      }));
    }
  };

  const handleFileInputChange = (e) => {
    handleFileChange(e.target.files[0]);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    const error = handleValidation(name, value);

    setFormData({ ...formData, [name]: value });
    setErrors({ ...errors, [name]: error });

    if (name === "emp_img") {
      handleFileChange(e.target.files[0]);
    }
  };

  const handleDepartmentChange = (e) => {
    const selectedDepartment = e.target.value;
    const selectedDepartmentObject = departments.find(
      (dept) => dept.dept_id === selectedDepartment
    );

    axios
      .get(`${config.apiUrl}/roles?dept_id=${selectedDepartment}`)
      .then((response) => {
        setRoles(response.data);
      })
      .catch((error) => {
        console.error("Error fetching roles:", error);
      });

    const name = "dept_id";
    const value = selectedDepartment;
    const errorMsg = handleValidation(name, value);

    setErrors({
      ...errors,
      [name]: errorMsg,
      role_id: "",
    });

    setFormData({
      ...formData,
      dept_id: selectedDepartment,
      dept_name: selectedDepartmentObject
        ? selectedDepartmentObject.dept_name
        : "",
      emp_role: "",
      role_id: "",
    });
  };

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/departments`)
      .then((response) => {
        setDepartments(response.data);
      })
      .catch((error) => {
        console.error("Error Fetching Department", error);
      });
  }, []);

  useEffect(() => {
    if (formData.dept_id) {
      axios
        .get(`${config.apiUrl}/roles?dept_id=${formData.dept_id}`)
        .then((response) => {
          setRoles(response.data);
        })
        .catch((error) => {
          console.error("Error Fetching Role:", error);
        });
    }
  }, [formData.dept_id]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    let formErrors = {};
    Object.keys(formData).forEach((name) => {
      const value = formData[name];
      const error = handleValidation(name, value);
      if (error) {
        formErrors[name] = error;
      }
    });

    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      return;
    }

    try {
      const formDataWithFile = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        formDataWithFile.append(key, value);
      });

      const response = await axios.post(`${config.apiUrl}/employees`,formDataWithFile);

      console.log("Employee added successfully");
      onClose();
    } catch (error) {
      console.error("Error adding employee:", error);
    }
  };

  return (
    <div>
      <h1 className="text-center" style={{ color: "#1B9C85" }}>
        Add Employee
      </h1>

      <Grid container spacing={3} className="mt-2">
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Employee Name"
            name="emp_name"
            value={formData.emp_name}
            onChange={handleInputChange}
            error={!!errors.emp_name}
            helperText={errors.emp_name}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Email"
            name="emp_email"
            value={formData.emp_email}
            onChange={handleInputChange}
            error={!!errors.emp_email}
            helperText={errors.emp_email}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Mobile Number"
            name="emp_mobile"
            type="number"
            value={formData.emp_mobile}
            onChange={handleInputChange}
            error={!!errors.emp_mobile}
            helperText={errors.emp_mobile}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            type="file"
            InputLabelProps={{ shrink: true }}
            onChange={handleFileInputChange}
            error={!!errors.emp_img}
            helperText={errors.emp_img}
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            fullWidth
            select
            label="Department"
            name="dept_id"
            value={formData.dept_id}
            onChange={handleDepartmentChange}
            error={!!errors.dept_id}
            helperText={errors.dept_id}
          >
            <MenuItem>Select Department</MenuItem>
            {departments.map((dept) => (
              <MenuItem key={dept.dept_id} value={dept.dept_id}>
                {dept.dept_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>

        <Grid item xs={6}>
          <TextField
            fullWidth
            select
            label="Role"
            name="role_id"
            value={formData.role_id}
            onChange={handleInputChange}
            error={!!errors.role_id}
            helperText={errors.role_id}
          >
            <MenuItem>Select Role</MenuItem>
            {roles.map((role) => (
              <MenuItem key={role.role_id} value={role.role_id}>
                {role.role}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Hire Date"
            type="date"
            name="hire_date"
            InputLabelProps={{
              shrink: true,
            }}
            value={formData.hire_date}
            onChange={handleInputChange}
            error={!!errors.hire_date}
            helperText={errors.hire_date}
          />
        </Grid>
      </Grid>
      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "25px" }}
      >
        <Button
          onClick={handleSubmit}
          style={{
            backgroundColor: "#1B9C85",
            borderColor: "#1B9C85",
            color: "white",
          }}
          className="action-button3"
        >
          Submit
        </Button>
      </div>
    </div>
  );
}

export default AddEmployee;
