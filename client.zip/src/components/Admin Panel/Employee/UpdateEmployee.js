import React, { useState, useEffect } from 'react';
import { Button, Grid, MenuItem, TextField } from '@mui/material';
import axios from 'axios';
import moment from 'moment';
import config from '../../../config';
function UpdateEmployee({ onClose, empData, updateEmployeeData }) {

  const [departments, setDepartments] = useState([]);
  const [roles, setRoles] = useState([]);

  const [updateEmployee, setUpdateEmployee] = useState({
    role_id: empData ? empData.role_id : '',
    dept_id: empData ? empData.dept_id : '',
    emp_name: empData ? empData.emp_name : '',
    emp_email: empData ? empData.emp_email : '',
    emp_mobile: empData ? empData.emp_mobile : '',
    emp_img: empData ? empData.emp_img : '',
    dept_name: empData ? empData.dept_name : '',
    emp_role: empData ? empData.emp_role : '',
    hire_date: empData ? empData.hire_date : '',
  });



  const [errors, setErrors] = useState({
    role_id: '',
    dept_id: '',
    emp_name: '',
    emp_email: '',
    emp_mobile: '',
    emp_img: '',
    hire_date: '',
  });
  const handleValidation = (name, value) => {
    let errorMsg = "";
    const trimmedValue =
      value && typeof value === "string" ? value.trim() : value;
    switch (name) {
      case "emp_name":
        if (!trimmedValue) {
          errorMsg = "Employee Name is Required";
        }
        break;
      case "emp_email":
        if (!trimmedValue) {
          errorMsg = "Email Address is Required";
        } else if (!/\S+@\S+\.\S+/.test(trimmedValue)) {
          errorMsg = "Enter a valid email address";
        }
        break;
      case "emp_mobile":
        if (!trimmedValue) {
          errorMsg = "Employee Mobile Number is Required";
        } else if (!/^\d{10}$/.test(trimmedValue)) {
          errorMsg = "Enter a valid Mobile Number";
        }
        break;
      // case "emp_img":
      //   if (!trimmedValue) {
      //     errorMsg = "Employee image is required";
      //   } else {
      //     const allowedExtensions = ["jpg", "jpeg", "png", "gif"];
      //     const extension = trimmedValue.name.split(".").pop().toLowerCase();
      //     if (!allowedExtensions.includes(extension)) {
      //       errorMsg =
      //         "Please upload a valid image file (jpg, jpeg, png, gif)";
      //     }
      //   }
      //   break;
      case "dept_id":
        if (!trimmedValue) {
          errorMsg = "Please select Department";
        }
        break;
      case "role_id":
        if (!trimmedValue) {
          errorMsg = "Please select Role";
        }
        break;
      case "hire_date":
        if (!trimmedValue) {
          errorMsg = "Hiring Date is Required";
        }
        break;
      default:
        break;
    }
    return errorMsg;
  };

  
  const handleFileChange = (selectedFile) => {
    if (!selectedFile) {
      // User canceled file selection, do nothing
      return;
    }

    const error = handleValidation("emp_img", selectedFile);
    setErrors({ ...errors, emp_img: error });

    if (!error) {
      setUpdateEmployee((prevFormData) => ({
        ...prevFormData,
        emp_img: selectedFile,
      }));
    }
  };

  const handleFileInputChange = (e) => {
    handleFileChange(e.target.files[0]);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    const error = handleValidation(name, value);

    setUpdateEmployee({ ...updateEmployee, [name]: value });
    setErrors({ ...errors, [name]: error });

    if (name === "emp_img") {
      handleFileChange(e.target.files[0]);
    }
  };

  const handleDepartmentChange = (e) => {
    const selectedDepartment = e.target.value;
    const selectedDepartmentObject = departments.find(
      (dept) => dept.dept_id === selectedDepartment
    );

    axios
      .get(`${config.apiUrl}/roles?dept_id=${selectedDepartment}`)
      .then((response) => {
        setRoles(response.data);
      })
      .catch((error) => {
        console.error("Error fetching roles:", error);
      });

    const name = "dept_id";
    const value = selectedDepartment;
    const errorMsg = handleValidation(name, value);

    setErrors({
      ...errors,
      [name]: errorMsg,
      role_id: "",
    });

    setUpdateEmployee({
      ...updateEmployee,
      dept_id: selectedDepartment,
      dept_name: selectedDepartmentObject
        ? selectedDepartmentObject.dept_name
        : "",
      emp_role: "",
      role_id: "",
    });
  };

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/departments`)
      .then((response) => {
        setDepartments(response.data);
      })
      .catch((error) => {
        console.error("Error Fetching Department", error);
      });
  }, []);

  useEffect(() => {
    if (updateEmployee.dept_id) {
      axios
        .get(`${config.apiUrl}/roles?dept_id=${updateEmployee.dept_id}`)
        .then((response) => {
          setRoles(response.data);
        })
        .catch((error) => {
          console.error("Error Fetching Role:", error);
        });
    }
  }, [updateEmployee.dept_id]);
  

  const handleUpdate = async (e) => {
    e.preventDefault();
  
    let formErrors = {};
    Object.keys(updateEmployee).forEach((name) => {
      const value = updateEmployee[name];
      const error = handleValidation(name, value);
      if (error) {
        formErrors[name] = error;
      }
    });
  
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      return;
    }
  
    try {
      const formDataWithFile = new FormData();
      Object.entries(updateEmployee).forEach(([key, value]) => {
        if (key === 'emp_img') {
          // If key is 'emp_img', append it separately as a file
          formDataWithFile.append('emp_img', value);
        } else {
          formDataWithFile.append(key, value);
        }
      });
  
      updateEmployeeData(empData.emp_id, formDataWithFile);
  
      console.log("Employee Updated successfully");
      onClose();
    } catch (error) {
      console.error("Error updating employee:", error);
    }
  };
  

  return(
    <div>
    <h1 className="text-center" style={{ color: "#1B9C85" }}>
      Add Employee
    </h1>

    <Grid container spacing={3} className="mt-2">
      <Grid item xs={6}>
        <TextField
          fullWidth
          label="Employee Name"
          name="emp_name"
          value={updateEmployee.emp_name}
          onChange={handleInputChange}
          error={!!errors.emp_name}
          helperText={errors.emp_name}
        />
      </Grid>
      <Grid item xs={6}>
        <TextField
          fullWidth
          label="Email"
          name="emp_email"
          value={updateEmployee.emp_email}
          onChange={handleInputChange}
          error={!!errors.emp_email}
          helperText={errors.emp_email}
        />
      </Grid>
      <Grid item xs={6}>
        <TextField
          fullWidth
          label="Mobile Number"
          name="emp_mobile"
          type="number"
          value={updateEmployee.emp_mobile}
          onChange={handleInputChange}
          error={!!errors.emp_mobile}
          helperText={errors.emp_mobile}
        />
      </Grid>
      <Grid item xs={6}>
        <TextField
          fullWidth
          type="file"
          InputLabelProps={{ shrink: true }}
          onChange={handleFileInputChange}
         
        />
      </Grid>

      <Grid item xs={6}>
        <TextField
          fullWidth
          select
          label="Department"
          name="dept_id"
          value={updateEmployee.dept_id}
          onChange={handleDepartmentChange}
          error={!!errors.dept_id}
          helperText={errors.dept_id}
        >
          <MenuItem>Select Department</MenuItem>
          {departments.map((dept) => (
            <MenuItem key={dept.dept_id} value={dept.dept_id}>
              {dept.dept_name}
            </MenuItem>
          ))}
        </TextField>
      </Grid>

      <Grid item xs={6}>
        <TextField
          fullWidth
          select
          label="Role"
          name="role_id"
          value={updateEmployee.role_id}
          onChange={handleInputChange}
          error={!!errors.role_id}
          helperText={errors.role_id}
        >
          <MenuItem>Select Role</MenuItem>
          {roles.map((role) => (
            <MenuItem key={role.role_id} value={role.role_id}>
              {role.role}
            </MenuItem>
          ))}
        </TextField>
      </Grid>
      <Grid item xs={6}>
        <TextField
          fullWidth
          label="Hire Date"
          type="date"
          name="hire_date"
          InputLabelProps={{
            shrink: true,
          }}
          value={updateEmployee.hire_date}
          onChange={handleInputChange}
          error={!!errors.hire_date}
          helperText={errors.hire_date}
        />
      </Grid>
    </Grid>
    <div
      style={{ display: "flex", justifyContent: "center", marginTop: "25px" }}
    >
      <Button
        onClick={handleUpdate}
        style={{
          backgroundColor: "#1B9C85",
          borderColor: "#1B9C85",
          color: "white",
        }}
        className="action-button3"
      >
        Submit
      </Button>
    </div>
  </div>
);
}
export default UpdateEmployee