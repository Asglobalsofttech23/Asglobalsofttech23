import React, { useState, useEffect,useRef} from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Checkbox,
  Button,
  TextField,
  TablePagination,
  Dialog,
  DialogContent,
  DialogActions,
  MenuItem,
  Menu,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import axios from "axios";
import AddEmployee from "./AddEmployee";
import UpdateEmployee from "./UpdateEmployee";
import * as XLSX from "xlsx";
import { format } from "date-fns";
import ReactPaginate from "react-paginate";
import config from "../../../config";

const EmployeeIndex = ({searchQuery }) => {


  useEffect(() => {
    const highlightColor = 'black';
    const unhighlightColor = 'initial';
    const highlightBackground = 'yellow';
    const unhighlightBackground = 'white';
  
    const tableCells = document.querySelectorAll('td'); // Select all table cells or specific cells where you want to apply the highlight
  
    tableCells.forEach((cell) => {
      const cellText = cell.textContent;
      const searchQueryLC = searchQuery.toLowerCase();
      
      // Split the text content of the cell into parts based on the search query
      const parts = cellText.split(new RegExp(`(${searchQueryLC})`, 'gi'));
      
      // Recreate the inner HTML of the cell to highlight the matched parts
      cell.innerHTML = parts.map(part => {
        if (part.toLowerCase() === searchQueryLC) {
          return `<span style="color: ${highlightColor}; background-color: ${highlightBackground}">${part}</span>`;
        } else {
          return part;
        }
      }).join('');
    });
  }, [searchQuery]);
  
  
  
  
  const [employee, setEmployee] = useState([]);
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [searchInput, setSearchInput] = useState("");
 
  const [openDialog, setOpenDialog] = useState(false);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [isDataUpdated, setIsDataUpdated] = useState(false);
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [selectedEmployeeData, setSelectedEmployeeData] = useState(null);
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false); // State for delete confirmation dialog
  const [employeeToDelete, setEmployeeToDelete] = useState(null); // Store the employee to be deleted

  const fetchData = () => {
     axios.get(`${config.apiUrl}/employees`)
      .then((response) => {
        setEmployee(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  };


  useEffect(() => {
    fetchData();
  }, []);

  const updateEmployeeData = (empId, updatedData) => {
    axios
      .put(`${config.apiUrl}/employees/${empId}`, updatedData)
      .then((response) => {
        console.log("Employee data updated successfully:", response.data);

        // You may want to fetch the updated data again
        fetchData();
      })
      .catch((error) => {
        console.error("Error updating employee data:", error);
      });
  };

  const [searchedVal, setSearchedVal] = useState("");

  const filterData = (emp) => {
    const searchValue = searchedVal.toLocaleLowerCase();
    return Object.values(emp).some(
      (value) => value && value.toString().toLowerCase().includes(searchValue)
    );
  };

  

  const handleRowSelect = (emp_id) => {
    const selectedIndex = selectedRows.indexOf(emp_id);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selectedRows, emp_id);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selectedRows.slice(1));
    } else if (selectedIndex === selectedRows.length - 1) {
      newSelected = newSelected.concat(selectedRows.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selectedRows.slice(0, selectedIndex),
        selectedRows.slice(selectedIndex + 1)
      );
    }

    setSelectedRows(newSelected);
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedRows([]);
    } else {
      const allEmpIds = employee.map((emp) => emp.emp_id);
      setSelectedRows(allEmpIds);
    }
    setSelectAll(!selectAll);
  };

  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  // Export as CSV
  const handleCSVExport = () => {
    const csvData = employee.map(
      (
        {
          emp_id,
          emp_name,
          emp_email,
          emp_mobile,
          emp_project,
          emp_role,
          emp_project_status,
        },
        index
      ) => ({
        "S.no": index + 1,
        "Employee Name": emp_name,
        "Employee Email": emp_email,
        "Employee Mobile": emp_mobile,

        "Employee Project": emp_project,
        Role: emp_role,
        "Project Status": emp_project_status,
      })
    );

    const csvHeaders = [
      { label: "S.no", key: "S.no" },
      { label: "Employee Name", key: "Employee Name" },
      { label: "Employee Email", key: "Employee Email" },
      { label: "Employee Mobile", key: "Employee Mobile" },
      { label: "Employee Project", key: "Employee Project" },
      { label: "Role", key: "Role" },
      { label: "Project Status", key: "Project Status" },
    ];

    const csvFilename = "project_data.csv";

    // Example using react-csv
    // <CSVLink data={csvData} headers={csvHeaders} filename={csvFilename} className='btn btn-primary'>Export CSV</CSVLink>;
  };

  const handleExcelExport = () => {
    const excelData = employee.map(
      (
        {
          emp_id,
          emp_name,
          emp_email,
          emp_mobile,
          emp_project,
          emp_role,
          emp_project_status,
        },
        index
      ) => [
        index + 1,
        emp_name,
        emp_email,
        emp_mobile,
        emp_project,
        emp_role,
        emp_project_status,
      ]
    );

    const ws = XLSX.utils.aoa_to_sheet([
      [
        "S.no",
        "Employee Name",
        "Employee Email",
        "Employee Mobile",
        "Employee Project",
        "Role",
        "Project Status",
      ],
      ...excelData,
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Sheet 1");
    XLSX.writeFile(wb, "project_data.xlsx");
  };

  const handleJSONExport = () => {
    const jsonData = JSON.stringify(employee, null, 2); // The '2' parameter adds indentation for better readability
    const blob = new Blob([jsonData], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "project_data.json";
    link.click();
  };

  const exportDataToCSV = () => {
    const selectedData = employee.filter((emp) =>
      selectedRows.includes(emp.emp_id)
    );

    const csvData = selectedData.map((emp, index) => ({
      "Emp ID": emp.emp_id,
      Name: emp.emp_name,
      Email: emp.emp_email,
      Mobile: emp.emp_mobile,
      Project: emp.emp_project,
      Role: emp.emp_role,
      "Project Status": emp.emp_project_status,
    }));

    const csvString =
      "Emp ID,Name,Email,Mobile,Project,Role,Project Status\n" +
      csvData.map((row) => Object.values(row).join(",")).join("\n");

    const blob = new Blob([csvString], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.style.display = "none";
    a.href = url;
    a.download = "selected_data.csv";

    document.body.appendChild(a);
    a.click();

    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };


  const [itemPerPage, setItemPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  const handleItemPerPageChange = (e) => {
    const newItemPerPage = parseInt(e.target.value, 10);

    if (newItemPerPage === 0) {
      setItemPerPage(employee.length);
      setCurrentPage(1);
    } else {
      setItemPerPage(newItemPerPage);
      setCurrentPage(1);
    }
  };

  const indexOfLastItem = currentPage * itemPerPage;
  const indexOfFirstItem = indexOfLastItem - itemPerPage;
  const currentItem = employee.slice(indexOfFirstItem, indexOfLastItem);
  



  const handleOpenEditEmployee = (emp_id) => {
    const selectedEmployee = employee.find((emp) => emp.emp_id === emp_id);

    if (selectedEmployee) {
      setSelectedEmployeeData(selectedEmployee);
      setOpenEditDialog(true);
    }
  };

  const handleCloseEditEmployee = () => {
    setSelectedEmployeeData(null);
    setOpenEditDialog(false);
  };

  const handleDeleteEmployee = (emp_id) => {
    const selectedEmployee = employee.find((emp) => emp.emp_id === emp_id);

    if (selectedEmployee) {
      setEmployeeToDelete(selectedEmployee);
      setOpenDeleteDialog(true);
    }
  };

  const confirmDelete = () => {
    // You can perform the delete operation here, e.g., make an API call to delete the employee
    if (employeeToDelete) {
      axios.delete(`${config.apiUrl}/employees/${employeeToDelete.emp_id}/delete`)
        .then((response) => {
          console.log("Employee deleted successfully:", response.data);

          // You may want to fetch the updated data again
          fetchData();
          setOpenDeleteDialog(false); // Close the confirmation dialog
        })
        .catch((error) => {
          console.error("Error deleting employee:", error);
        });
    }
  };

  const handleOpenDialog = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    fetchData();
  };

  

  return (
    <>
   
      <div className="mt-4" style={{ marginRight: "20px" }}>
        <h1 className="text-center">Employee Index</h1>
        <div className="row">
          <div className="col-lg-3 col-md-3 col-sm-12">
            <Button
              style={{
                backgroundColor: "#1B9C85",
                borderColor: "#1B9C85",
                color: "white",
              }}
              onClick={handleClick}
            >
              Export data
            </Button>
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleClose}
            >
              <MenuItem onClick={exportDataToCSV}>Export as CSV</MenuItem>
              <MenuItem onClick={handleExcelExport}>Export as Excel</MenuItem>
              <MenuItem onClick={handleJSONExport}>Export as JSON</MenuItem>
            </Menu>
          </div>
          <div className="col-lg-3 col-md-3 col-sm-12">
          <TextField
            label="Search"
            onChange={(e) => setSearchedVal(e.target.value)}
          />
          </div>
          <div className="col-lg-3 col-md-3 col-sm-12">
            <div>
              <select
                id="rowsPerPage"
                value={itemPerPage}
                onChange={handleItemPerPageChange}
                style={{
                  padding: "5px 10px",
                  margin: "0 5px",
                  border: "1px solid #007bff",
                  borderRadius: "4px",
                  cursor: "pointer",
                  backgroundColor: "#fff",
                  color: "#007bff",
                  textDecoration: "none",
                  transition: "background-color 0.3s, color 0.3s",
                }}
              >
                <option value={5}>5 per page</option>
                <option value={10}>10 per page</option>
                <option value={20}>20 per page</option>
                <option value={0}>All per page</option>
              </select>
            </div>
          </div>
          <div className="col-lg-3 col-md-3 col-sm-12">
            <Button
              onClick={handleOpenDialog}
              style={{
                backgroundColor: "#1B9C85",
                borderColor: "#1B9C85",
                color: "white",
              }}
              className="action-button3"
            >
              Add New Employee
            </Button>
          </div>
        </div>
        {employee.length > 0 ? (
          <div style={{ marginTop: "50px" }}>
            <TableContainer component={Paper}>
              <Table>
                <TableHead style={{ backgroundColor: "#1B9C85" }}>
                  <TableRow>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      <Checkbox
                        checked={selectAll}
                        onChange={handleSelectAll}
                      />
                    </TableCell>
                    <TableCell
                      style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                    >
                      Emp ID
                    </TableCell>
                    <TableCell
                      style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                    >
                      Name
                    </TableCell>
                    <TableCell
                      style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                    >
                      Email
                    </TableCell>
                    <TableCell
                      style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                    >
                      Mobile
                    </TableCell>
                    <TableCell
                      style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                    >
                      {" "}
                      Employee Image
                    </TableCell>
                    <TableCell
                      style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                    >
                      Department
                    </TableCell>
                    <TableCell
                      style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                    >
                      Role
                    </TableCell>
                    <TableCell
                      style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                    >
                      Hire Date
                    </TableCell>
                    <TableCell
                      style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                    >
                      Action
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {currentItem.filter(filterData).map((emp, index) => (
                    <TableRow key={emp.emp_id}>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        <Checkbox
                          checked={selectedRows.includes(emp.emp_id)}
                          onChange={() => handleRowSelect(emp.emp_id)}
                        />
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {index + 1}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {emp.emp_name}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {emp.emp_email}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {emp.emp_mobile}
                      </TableCell>
                      <TableCell
                        style={{ border: "1px solid #ddd", width: "170px" }}
                      >
                        {emp.emp_img && (
                          <>
                            <img
                              src={`data:image/jpeg;base64,${emp.emp_img}`}
                              
                              alt={emp.emp_name}
                              style={{ maxWidth: "100px", maxHeight: "100px" }}
                            />
                          </>
                        )}
                      </TableCell>

                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {emp.dept_name}
                      </TableCell>
                      <TableCell style={{ border: "1px solid #ddd" }}>
                        {emp.emp_role}
                      </TableCell>
                      <TableCell
                        style={{ border: "1px solid #ddd", width: "200px" }}
                      >
                        {emp.hire_date && (
                          // Format the date using the format function
                          <>{format(new Date(emp.hire_date), "yyyy-MM-dd")}</>
                        )}
                      </TableCell>
                      <TableCell
                        style={{ border: "1px solid #ddd", width: "250px" }}
                      >
                        <Button
                          onClick={() => handleOpenEditEmployee(emp.emp_id)}
                        >
                          <EditIcon />
                          Edit
                        </Button>
                        <Button
                          onClick={() => handleDeleteEmployee(emp.emp_id)}
                        >
                          <DeleteIcon style={{ color: "red" }} />
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>

            <nav aria-label="Page navigation" className="text-center">
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
          <ReactPaginate
            previousLabel={
              <span
                style={{
                  padding: '5px 10px',
                  margin: '0 5px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: '#152445',
                  color: 'white',
                  textDecoration: 'underline',
                  textDecorationColor: '#152445',
                }}
              >
                Previous
              </span>
            }
            nextLabel={
              <span
                style={{
                  padding: '5px 10px',
                  margin: '0 5px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: '#152445',
                  color: 'white',
                  textDecoration: 'underline',
                  textDecorationColor: '#152445',
                }}
              >
                Next
              </span>
            }
            breakLabel={
              <span
                style={{
                  padding: '5px 10px',
                  margin: '0 5px',
                  border: '1px solid #ccc',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  backgroundColor: '#fff',
                  color: '#333',
                  textDecoration: 'none',
                }}
              >
                ...
              </span>
            }
            pageCount={Math.ceil(employee.filter(filterData).length / itemPerPage)} // Use 'customers' instead of 'filteredCustomers'
            marginPagesDisplayed={2}
            pageRangeDisplayed={4}
            onPageChange={({ selected }) => setCurrentPage(selected + 1)}
            containerClassName={"pagination justify-content-center"}
            subContainerClassName={"pages pagination"}
            activeClassName={"active"}
          />
        </div>
      </nav>
          </div>
        ) : (
          <div style={{ width: "176vh", height: "465px" }}>
            <p className="text-center">No projects available</p>
          </div>
        )}

        <Dialog
          open={openDialog}
          onClose={handleCloseDialog}
          maxWidth="md"
          fullWidth
        >
          <DialogContent>
            <AddEmployee onClose={handleCloseDialog} />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDialog} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>

        <Dialog
          open={openEditDialog}
          onClose={handleCloseEditEmployee}
          maxWidth="md"
          fullWidth
        >
          <DialogContent>
            <UpdateEmployee
              onClose={handleCloseEditEmployee}
              empData={selectedEmployeeData}
              updateEmployeeData={updateEmployeeData}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseEditEmployee} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>

        <Dialog
          open={openDeleteDialog}
          onClose={() => setOpenDeleteDialog(false)}
        >
          <DialogContent>
            <div>
              <p>Are you sure you want to delete this employee?</p>
            </div>
          </DialogContent>
          <DialogActions>
            <Button
              variant="contained"
              onClick={confirmDelete}
              style={{ backgroundColor: "#DC143C", color: "white" }}
            >
              OK
            </Button>
            <Button
              variant="contained"
              onClick={() => setOpenDeleteDialog(false)}
              style={{ backgroundColor: "#1B9C85", color: "white" }}
            >
              Cancel
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    </>
  );
};

export default EmployeeIndex;
