import { Button, Grid, IconButton, InputAdornment, MenuItem, TextField } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import config from "../../../config";
import SearchIcon from "@material-ui/icons/Search";
const districtData = [
  "Ariyalur",
  "Chengalpattu",
  "Chennai",
  "Coimbatore",
  "Cuddalore",
  "Dharmapuri",
  "Dindigul",
  "Erode",
  "Kallakurichi",
  "Kanchipuram",
  "Kanyakumari",
  "Karur",
  "Krishnagiri",
  "Madurai",
  "Nagapattinam",
  "Namakkal",
  "Nilgiris",
  "Perambalur",
  "Pudukkottai",
  "Ramanathapuram",
  "Ranipet",
  "Salem",
  "Sivaganga",
  "Tenkasi",
  "Thanjavur",
  "Theni",
  "Thoothukudi",
  "Tiruchirappalli",
  "Tirunelveli",
  "Tirupathur",
  "Tiruppur",
  "Tiruvallur",
  "Tiruvannamalai",
  "Tiruvarur",
  "Vellore",
  "Viluppuram",
  "Virudhunagar",
];

function AddCustomers({ onClose }) {
  const [employee, setEmployee] = useState([]);

  const [formData, setFormData] = useState({
    cust_name: "",
    cust_email: "",
    cust_mobile: "",
    bus_name: "",
    bus_category: "",
    follow_emp_id: "",
    follow_up_date: "",
    dist: "",
    city: "",
    converted_to_customer: "",
    converted_dated: null,
    cust_amount: "",
    payment_status: "",
    category: "",
    entered_by: "",
    
  });

  const [errors, setErrors] = useState({
    cust_name: "",
    cust_email: "",
    cust_mobile: "",
    bus_name: "",
    bus_category: "",
    follow_emp_id: "",
    follow_up_date: "",
    dist: "",
    city: "",
    converted_to_customer: "",
    converted_dated: null,
    cust_amount: "",
    payment_status: "",
    category: "",
    entered_by : "",
   
  });

  const validateField = (name, value, isConvertedCustomer) => {
    let errorMsg = "";
    const trimmedValue =
      value && typeof value === "string" ? value.trim() : value;

    switch (name) {
      case "cust_name":
        if (!trimmedValue) {
          errorMsg = "Customer Name is Required";
        }
        break;
      case "cust_email":
        if (!trimmedValue) {
          errorMsg = "Customer Email is Required";
        } else if (!/\S+@\S+\.\S+/.test(trimmedValue)) {
          errorMsg = "Enter a valid email address";
        }
        break;
      case "cust_mobile":
        if (!trimmedValue) {
          errorMsg = "Mobile Number is Required";
        } else if (!/^\d{10}$/.test(trimmedValue)) {
          errorMsg = "Enter a valid Mobile Number";
        }
        break;
      case "bus_name":
        if (!trimmedValue) {
          errorMsg = "Bussiness Name is Required";
        }
        break;
      case "bus_category":
        if (!trimmedValue) {
          errorMsg = "Bussiness Category is Required";
        }
        break;
      case "follow_emp_id":
        if (!trimmedValue) {
          errorMsg = "Employee Name is Required";
        }
        break;
      case "follow_up_date":
        if (!trimmedValue) {
          errorMsg = "Follow Up Date is Required";
        }
        break;
      case "converted_to_customer":
        if (!trimmedValue) {
          errorMsg = "Converting field  is Required";
        }
        break;
      case "converted_dated":
        if (isConvertedCustomer && !trimmedValue) {
          errorMsg = "Converted date is Required";
        }
        break;
      case "cust_amount":
        if (isConvertedCustomer && !trimmedValue) {
          errorMsg = " Payment Amount is Required";
        }
        break;
      case "payment_status":
        if (isConvertedCustomer && !trimmedValue) {
          errorMsg = " Payment Status is Required";
        }
        break;
      case "category":
        if (isConvertedCustomer && !trimmedValue) {
          errorMsg = "Category is Required";
        }
        break;
      case "dist":
        if (!trimmedValue) {
          errorMsg = "District is Required";
        }
        break;
      case "city":
        if (!trimmedValue) {
          errorMsg = "City is Required";
        }
        break;
      case "entered_by":
        if (!trimmedValue) {
          errorMsg = "Entered Employee Name is  Required";
        }
        break;
      default:
        break;
    }
    return errorMsg;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    let formErrors = {};
    const isConvertedCustomer = formData.converted_to_customer === "yes"; // Check if it's 'yes'

    Object.keys(formData).forEach((name) => {
      const value = formData[name];
      const error = validateField(name, value, isConvertedCustomer); // Pass the 'isConvertedCustomer' flag
      if (error) {
        formErrors[name] = error;
      }
    });

    // If there are errors, update the state and prevent submission
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      return;
    }

    axios
      .post(`${config.apiUrl}/customers`, formData)
      .then((response) => {
        console.log("Customer added successfully");
        onClose();
      })
      .catch((error) => {
        console.error("Error adding customer:", error);
      });
  };

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/employees`)
      .then((response) => {
        setEmployee(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  return (
    <div>
      <h1 className="text-center">Add Customers</h1>
      <Grid container spacing={3}>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Customer Name"
            name="cust_name"
            value={formData.cust_name}
            onChange={(e) => {
              const { name, value } = e.target;
              const error = validateField(name, value);
              setFormData({ ...formData, [name]: value });
              setErrors({ ...errors, [name]: error });
            }}
            error={!!errors.cust_name}
            helperText={errors.cust_name}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Email Address"
            name="cust_email"
            value={formData.cust_email}
            onChange={(e) => {
              const { name, value } = e.target;
              const error = validateField(name, value);
              setFormData({ ...formData, [name]: value });
              setErrors({ ...errors, [name]: error });
            }}
            error={!!errors.cust_email}
            helperText={errors.cust_email}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Customer Mobile No"
            name="cust_mobile"
            type="number"
            value={formData.cust_mobile}
            onChange={(e) => {
              const { name, value } = e.target;
              const error = validateField(name, value);
              setFormData({ ...formData, [name]: value });
              setErrors({ ...errors, [name]: error });
            }}
            error={!!errors.cust_mobile}
            helperText={errors.cust_mobile}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Bussiness Name"
            name="bus_name"
            value={formData.bus_name}
            onChange={(e) => {
              const { name, value } = e.target;
              const error = validateField(name, value);
              setFormData({ ...formData, [name]: value });
              setErrors({ ...errors, [name]: error });
            }}
            error={!!errors.bus_name}
            helperText={errors.bus_name}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Bussiness Category"
            name="bus_category"
            value={formData.bus_category}
            onChange={(e) => {
              const { name, value } = e.target;
              const error = validateField(name, value);
              setFormData({ ...formData, [name]: value });
              setErrors({ ...errors, [name]: error });
            }}
            error={!!errors.bus_category}
            helperText={errors.bus_category}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            select
            label="Employee Name"
            name="follow_emp_id" // Change this to follow_emp_id
            value={formData.follow_emp_id} // Ensure the value is set to formData.follow_emp_id
            onChange={(e) => {
              const { name, value } = e.target;
              const error = validateField(name, value);
              setFormData({ ...formData, [name]: value });
              setErrors({ ...errors, [name]: error });
            }}
            error={!!errors.follow_emp_id}
            helperText={errors.follow_emp_id}
          >
            <MenuItem value="">Select Employee</MenuItem>
            {employee.map((emp) => (
              <MenuItem key={emp.emp_id} value={emp.emp_id}>
                
                {emp.emp_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>

        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Follow up date"
            type="date"
            InputLabelProps={{
              shrink: true,
            }}
            name="follow_up_date"
            value={formData.follow_up_date}
            onChange={(e) => {
              const { name, value } = e.target;
              const error = validateField(name, value);
              setFormData({ ...formData, [name]: value });
              setErrors({ ...errors, [name]: error });
            }}
            error={!!errors.follow_up_date}
            helperText={errors.follow_up_date}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            name="dist"
            label="District"
            value={formData.dist}
            onChange={(e) => {
              const { name, value } = e.target;
              const error = validateField(name, value);
              setFormData({ ...formData, [name]: value });
              setErrors({ ...errors, [name]: error });
            }}
            error={!!errors.dist}
            helperText={errors.dist}
          >
            {districtData.map((dist,index)=>(
              <MenuItem key={index} value={dist}>{dist}</MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
          fullWidth
          name="city"
          label="City"
          value={formData.city}
          onChange={(e) => {
            const { name, value } = e.target;
            const error = validateField(name, value);
            setFormData({ ...formData, [name]: value });
            setErrors({ ...errors, [name]: error });
          }}
          error={!!errors.city}
            helperText={errors.city}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            select
            fullWidth
            label="Converted to customer"
            name="converted_to_customer"
            value={formData.converted_to_customer}
            onChange={(e) => {
              const { name, value } = e.target;
              const error = validateField(name, value);
              setFormData({ ...formData, [name]: value });
              setErrors({ ...errors, [name]: error });
            }}
            error={!!errors.converted_to_customer}
            helperText={errors.converted_to_customer}
            variant="outlined"
          >
            <MenuItem value="yes">YES</MenuItem>
            <MenuItem value="no">NO</MenuItem>
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            select
            label="Entered Employee Name"
            name="entered_by" // Change this to follow_emp_id
            value={formData.entered_by} // Ensure the value is set to formData.follow_emp_id
            onChange={(e) => {
              const { name, value } = e.target;
              const error = validateField(name, value);
              setFormData({ ...formData, [name]: value });
              setErrors({ ...errors, [name]: error });
            }}
            error={!!errors.entered_by}
            helperText={errors.entered_by}
          >
            <MenuItem value="">Select Employee</MenuItem>
            {employee.map((emp) => (
              <MenuItem key={emp.emp_id} value={emp.emp_id}>
                
                {emp.emp_name}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        {formData.converted_to_customer === "yes" && (
          <>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Converted date"
                type="date"
                InputLabelProps={{
                  shrink: true,
                }}
                name="converted_dated"
                value={formData.converted_dated}
                onChange={(e) => {
                  const { name, value } = e.target;
                  const error = validateField(name, value);
                  setFormData({ ...formData, [name]: value });
                  setErrors({ ...errors, [name]: error });
                }}
                error={!!errors.converted_dated}
                helperText={errors.converted_dated}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label=" Amount"
                name="cust_amount"
                type="number"
                value={formData.cust_amount}
                onChange={(e) => {
                  const { name, value } = e.target;
                  const error = validateField(name, value);
                  setFormData({ ...formData, [name]: value });
                  setErrors({ ...errors, [name]: error });
                }}
                error={!!errors.cust_amount}
                helperText={errors.cust_amount}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Payment Status"
                name="payment_status"
                value={formData.payment_status}
                onChange={(e) => {
                  const { name, value } = e.target;
                  const error = validateField(name, value);
                  setFormData({ ...formData, [name]: value });
                  setErrors({ ...errors, [name]: error });
                }}
                error={!!errors.payment_status}
                helperText={errors.payment_status}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                select
                fullWidth
                label="Category"
                name="category"
                value={formData.category}
                onChange={(e) => {
                  const { name, value } = e.target;
                  const error = validateField(name, value);
                  setFormData({ ...formData, [name]: value });
                  setErrors({ ...errors, [name]: error });
                }}
                error={!!errors.category}
                helperText={errors.category}
              >
                <MenuItem value="">Select Category</MenuItem>
                <MenuItem value="1">1st Priority</MenuItem>
                <MenuItem value="2">2nd Priority</MenuItem>
                <MenuItem value="3">3rd Priority</MenuItem>
                <MenuItem value="4">4th Priority</MenuItem>
              </TextField>
            </Grid>
          </>
        )}
      </Grid>

      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "25px" }}
      >
        <Button
          onClick={handleSubmit}
          style={{
            backgroundColor: "#1B9C85",
            borderColor: "#1B9C85",
            color: "white",
          }}
        >
          Submit
        </Button>
      </div>
    </div>
  );
}

export default AddCustomers;

// <TextField
// select
// label="YES or NO"
// value={selectedValue}
// onChange={handleSelectChange}
// variant="outlined"
// fullWidth
// >
// <MenuItem value="YES">YES</MenuItem>
// <MenuItem value="NO">NO</MenuItem>
// </TextField>
