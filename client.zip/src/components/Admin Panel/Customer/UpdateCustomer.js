import { Button, Grid, MenuItem, TextField } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import config from "../../../config";
const categoryLookup = {
  "1st Priority": 1,
  "2nd Priority": 2,
  "3rd Priority": 3,
  "4th Priority": 4,
};
const districtData = [
  "Ariyalur",
  "Chengalpattu",
  "Chennai",
  "Coimbatore",
  "Cuddalore",
  "Dharmapuri",
  "Dindigul",
  "Erode",
  "Kallakurichi",
  "Kanchipuram",
  "Kanyakumari",
  "Karur",
  "Krishnagiri",
  "Madurai",
  "Nagapattinam",
  "Namakkal",
  "Nilgiris",
  "Perambalur",
  "Pudukkottai",
  "Ramanathapuram",
  "Ranipet",
  "Salem",
  "Sivaganga",
  "Tenkasi",
  "Thanjavur",
  "Theni",
  "Thoothukudi",
  "Tiruchirappalli",
  "Tirunelveli",
  "Tirupathur",
  "Tiruppur",
  "Tiruvallur",
  "Tiruvannamalai",
  "Tiruvarur",
  "Vellore",
  "Viluppuram",
  "Virudhunagar",
];


function UpdateCustomer({ custData, updateCustomerData, onClose }) {
  const [updateCustomer, setUpdateCustomer] = useState({
    cust_name: custData ? custData.cust_name : "",
    cust_email: custData ? custData.cust_email : "",
    cust_mobile: custData ? custData.cust_mobile : "",
    bus_name: custData ? custData.bus_name : "",
    bus_category: custData ? custData.bus_category : "",
    follow_emp_id: custData ? custData.follow_emp_id : "",
    follow_up_date: custData ? custData.follow_up_date : "",
    dist: custData ? custData.dist : "",
    city: custData ? custData.city : "",
    converted_to_customer: custData ? custData.converted_to_customer : "",
    converted_dated: custData ? custData.converted_dated : "",
    cust_amount: custData ? custData.cust_amount : "",
    payment_status: custData ? custData.payment_status : "",
    category: custData ? categoryLookup[custData.category] || "" : "",
    entered_by: custData ? custData.entered_by : "",
    
  });

  
  

  


  const [errors, setErrors] = useState({
    cust_name: "",
    cust_email: "",
    cust_mobile: "",
    bus_name: "",
    bus_category: "",
    follow_emp_id: "",
    follow_up_date: "",
    dist : "",
    city : "",
    converted_to_customer: "",
    converted_dated: null,
    cust_amount: "",
    payment_status: "",
    category: "",
    entered_by:"",
  });

  const validateField = (name, value, isConvertedCustomer) => {
    let errorMsg = "";
    const trimmedValue =
      value && typeof value === "string" ? value.trim() : value;

    switch (name) {
      case "cust_name":
        if (!trimmedValue) {
          errorMsg = "Customer Name is Required";
        }
        break;
      case "cust_email":
        if (!trimmedValue) {
          errorMsg = "Customer Email is Required";
        } else if (!/\S+@\S+\.\S+/.test(trimmedValue)) {
          errorMsg = "Enter a valid email address";
        }
        break;
      case "cust_mobile":
        if (!trimmedValue) {
          errorMsg = "Mobile Number is Required";
        } else if (!/^\d{10}$/.test(trimmedValue)) {
          errorMsg = "Enter a valid Mobile Number";
        }
        break;
      case "bus_name":
        if (!trimmedValue) {
          errorMsg = "Bussiness Name is Required";
        }
        break;
      case "bus_category":
        if (!trimmedValue) {
          errorMsg = "Bussiness Category is Required";
        }
        break;
      case "follow_emp_id":
        if (!trimmedValue) {
          errorMsg = "Employee Name is Required";
        }
        break;
      case "follow_up_date":
        if (!trimmedValue) {
          errorMsg = "Follow Up Date is Required";
        }
        break;
      case "converted_to_customer":
        if (!trimmedValue) {
          errorMsg = "Converting field  is Required";
        }
        break;
      case "converted_dated":
        if (isConvertedCustomer && !trimmedValue) {
          errorMsg = "Converted date is Required";
        }
        break;
      case "cust_amount":
        if (isConvertedCustomer && !trimmedValue) {
          errorMsg = " Payment Amount is Required";
        }
        break;
      case "payment_status":
        if (isConvertedCustomer && !trimmedValue) {
          errorMsg = " Payment Status is Required";
        }
        break;
      case "category":
        if (isConvertedCustomer && !trimmedValue) {
          errorMsg = "Category is Required";
        }
        break;
      case "dist":
          if (!trimmedValue) {
            errorMsg = "District is Required";
          }
          break;
      case "city":
          if (!trimmedValue) {
            errorMsg = "City is Required";
          }
          break;
      case "entered_by":
          if (!trimmedValue) {
            errorMsg = "Entered Employee Name Required";
          }
          break;
      default:
        break;
    }
    return errorMsg;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    const error = validateField(name, value);
    setUpdateCustomer({ ...updateCustomer, [name]: value });
    setErrors({ ...errors, [name]: error });
  };

  const handleUpdateCustomer = () => {
    let formErrors = {};
    const isConvertedCustomer = updateCustomer.converted_to_customer === "yes";

    Object.keys(updateCustomer).forEach((name) => {
      const value = updateCustomer[name];
      const error = validateField(name, value, isConvertedCustomer); // Pass the 'isConvertedCustomer' flag
      if (error) {
        formErrors[name] = error;
      }
    });

    // If there are errors, update the state and prevent submission
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      return;
    }

    updateCustomerData(custData.cust_id, updateCustomer);

    onClose();
  };

  const [employee, setEmployee] = useState([]);

  useEffect(() => {
    axios.get(`${config.apiUrl}/employees`)
      .then((response) => {
        setEmployee(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  return (
    <div>
      {custData ? (
        <div>
          <h1 className="text-center">Add Customers</h1>
          <Grid container spacing={3}>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Customer Name"
                name="cust_name"
                value={updateCustomer.cust_name}
                onChange={handleInputChange}
                error={!!errors.cust_name}
                helperText={errors.cust_name}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Email Address"
                name="cust_email"
                value={updateCustomer.cust_email}
                onChange={handleInputChange}
                error={!!errors.cust_email}
                helperText={errors.cust_email}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Customer Mobile No"
                name="cust_mobile"
                type="number"
                value={updateCustomer.cust_mobile}
                onChange={handleInputChange}
                error={!!errors.cust_mobile}
                helperText={errors.cust_mobile}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Bussiness Name"
                name="bus_name"
                value={updateCustomer.bus_name}
                onChange={handleInputChange}
                error={!!errors.bus_name}
                helperText={errors.bus_name}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Category"
                name="bus_category"
                value={updateCustomer.bus_category}
                onChange={handleInputChange}
                error={!!errors.bus_category}
                helperText={errors.bus_category}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                select
                label="Employee Name"
                name="follow_emp_id" // Change this to follow_emp_id
                value={updateCustomer.follow_emp_id} // Ensure the value is set to updateCustomer.follow_emp_id
                onChange={handleInputChange} 
                error={!!errors.follow_emp_id}
                helperText={errors.follow_emp_id}
              >
                <MenuItem value="">Select Employee</MenuItem>
                {employee.map((emp) => (
                  <MenuItem key={emp.emp_id} value={emp.emp_id}>
                    {" "}
                    {/* Set the value to emp_id, not emp_name */}
                    {emp.emp_name}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>

            <Grid item xs={6}>
              <TextField
                fullWidth
                label="Follow up date"
                type="date"
                InputLabelProps={{
                  shrink: true,
                }}
                name="follow_up_date"
                value={updateCustomer.follow_up_date}
                onChange={handleInputChange}
                error={!!errors.follow_up_date}
                helperText={errors.follow_up_date}
              />
            </Grid>
            <Grid item xs={6}>
          <TextField
            select
            fullWidth
            name="dist"
            label="District"
            value={updateCustomer.dist}
            onChange={handleInputChange}
            error={!!errors.dist}
            helperText={errors.dist}
          >
            {districtData.map((dist,index)=>(
              <MenuItem key={index} value={dist}>{dist}</MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid item xs={6}>
          <TextField
          fullWidth
          name="city"
          label="City"
          value={updateCustomer.city}
          onChange={handleInputChange}
          error={!!errors.city}
            helperText={errors.city}
          />
        </Grid>
            <Grid item xs={6}>
              <TextField
                select
                fullWidth
                label="Converted to customer"
                name="converted_to_customer"
                value={updateCustomer.converted_to_customer}
                onChange={handleInputChange}
                variant="outlined"
                error={!!errors.converted_to_customer}
                helperText={errors.converted_to_customer}
              >
                <MenuItem value="yes">YES</MenuItem>
                <MenuItem value="no">NO</MenuItem>
              </TextField>
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                select
                label="Select Entered Employee Name"
                name="entered_by" 
                value={updateCustomer.entered_by} 
                onChange={handleInputChange} 
                error={!!errors.entered_by}
                helperText={errors.entered_by}
              >
                <MenuItem value="">Select Employee</MenuItem>
                {employee.map((emp) => (
                  <MenuItem key={emp.emp_id} value={emp.emp_id}>
                    {emp.emp_name}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
            {updateCustomer.converted_to_customer === "yes" && (
              <>
                <Grid item xs={6}>
                  <TextField
                    fullWidth
                    label="Converted date"
                    type="date"
                    InputLabelProps={{
                      shrink: true,
                    }}
                    name="converted_dated"
                    value={updateCustomer.converted_dated}
                    onChange={handleInputChange}
                    error={!!errors.converted_dated}
                    helperText={errors.converted_dated}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    fullWidth
                    label=" Amount"
                    name="cust_amount"
                    type="number"
                    value={updateCustomer.cust_amount}
                    onChange={handleInputChange}
                    error={!!errors.cust_amount}
                    helperText={errors.cust_amount}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    fullWidth
                    label="Payment Status"
                    name="payment_status"
                    value={updateCustomer.payment_status}
                    onChange={handleInputChange}
                    error={!!errors.payment_status}
                    helperText={errors.payment_status}
                  />
                </Grid>
                <Grid item xs={6}>
                <TextField
                select
  fullWidth
  
  label="Category"
  name="category"
  value={updateCustomer.category}
  onChange={handleInputChange}
  error={!!errors.category}
  helperText={errors.category}
>
  <MenuItem value="">Select Category</MenuItem>
  <MenuItem value="1">Category 1</MenuItem>
  <MenuItem value="2">Category 2</MenuItem>
  <MenuItem value="3">Category 3</MenuItem>
  <MenuItem value="4">Category 4</MenuItem>
</TextField>

                </Grid>
              </>
            )}
          </Grid>

          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginTop: "25px",
            }}
          >
            <Button
              onClick={handleUpdateCustomer}
              style={{
                backgroundColor: "#1B9C85",
                borderColor: "#1B9C85",
                color: "white",
              }}
            >
              Submit
            </Button>
          </div>
        </div>
      ) : (
        <>
          <p>No Available Customer Data</p>
        </>
      )}
    </div>
  );
}

export default UpdateCustomer;
