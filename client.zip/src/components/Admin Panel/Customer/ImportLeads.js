import React, { useEffect, useState } from "react";
import { Button, Container, Grid, Typography, TextField, MenuItem } from "@mui/material";
import axios from "axios";
import config from "../../../config";


const ImportLeads = ({onClose}) => {
  const [file, setFile] = useState(null);
  const [employees,setEmployees] = useState([]);
  const [employeesData,setEmployeesData] = useState({
    follow_emp_id : '',
    entered_by : ''  })

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleInputChange = (e) =>{
    const{name,value} = e.target;
    setEmployeesData({...employeesData,[name]:value})
  }

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/employees`)
      .then((response) => {
        setEmployees(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  const handleUpload = () => {
    const formData = new FormData();
    formData.append("file", file);

    // Append employeesData to formData
    Object.entries(employeesData).forEach(([key, value]) => {
        formData.append(key, value);
    });

    axios
      .post(`${config.apiUrl}/customers/importLeads`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((response) => {
        console.log("File uploaded successfully:", response.data);
        onClose();
      })
      .catch((error) => {
        console.error("Error uploading file:", error);
      });
};


  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        Upload Excel File
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={6}>
        <TextField name = 'file' label = 'Upload Leads' onChange={handleFileChange} type="file" InputLabelProps={{shrink:true}}/>
        </Grid>
        <Grid item xs={6}>
            <TextField 
            fullWidth
            select
            name="follow_emp_id"
            label = 'Followed By'
            value={employeesData.follow_emp_id}
            onChange={handleInputChange}
            >
                {employees.map((follow,index)=>(
                    <MenuItem key={index} value={follow.emp_id}>{follow.emp_email}</MenuItem>
                ))}
                
            </TextField>
        </Grid>
        <Grid item xs={6}>
            <TextField 
            fullWidth
            select
            name="entered_by"
            label = 'Entered By'
            value={employeesData.entered_by}
            onChange={handleInputChange}
            >
                {employees.map((enter,index)=>(
                    <MenuItem key={index} value={enter.emp_id}>{enter.emp_email}</MenuItem>
                ))}
                
            </TextField>
        </Grid>
        <Grid item xs={12}>
          <Button variant="contained" color="primary" onClick={handleUpload}>
            Upload
          </Button>
        </Grid>
      </Grid>
    </Container>
  );
};

export default ImportLeads;

