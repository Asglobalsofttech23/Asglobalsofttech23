// // import React, { useState } from 'react';
// // import { Tabs, Tab, Box } from '@mui/material';
// // import TopNav from '../TopNav/TopNav';
// // import SideNav from '../SideNav/SideNav';
// // import CustomerIndex from './CustomerIndex';
// // import ExistingCustomer from './ExistingCustomer';

// // function CustomerIndexRouting() {
//   // const [activeTab, setActiveTab] = useState(0);

//   // const handleTabChange = (event, newValue) => {
//   //   setActiveTab(newValue);
//   // };

// //   return (
// //     <div style={{overflow:'hidden'}}>
// //       <TopNav />
// //       <div className='row' style={{ display: 'flex',marginLeft:'-23.7px' }} >
     
// //         <div className='col-3'>
// //           <SideNav />
// //         </div>
// //         <div className='col-9 mt-3'>
//           // <Tabs value={activeTab}
//           //  onChange={handleTabChange} 
//           //  style={{ marginLeft: 'auto', marginRight: '130px',marginTop:'50px' }}
//           //  centered>
//           //   <Tab label="Customer" />
//           //   <Tab label="Existing Customer" />
//           // </Tabs>
//           // <Box hidden={activeTab !== 0}>
//           //   <CustomerIndex />
//           // </Box>
//           // <Box hidden={activeTab !== 1}>
//           //   <ExistingCustomer />
//           // </Box>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // }

// // export default CustomerIndexRouting;



// import React, { useState } from 'react'
// import { Tabs, Tab, Box } from '@mui/material';
// import TopNav from '../TopNav/TopNav';
// import SideNav from '../SideNav/SideNav';
// import CustomerIndex from './CustomerIndex';
// import ExistingCustomer from './ExistingCustomer';

// function CustomerIndexRouting() {
//   const [activeTab, setActiveTab] = useState(0);

//   const handleTabChange = (event, newValue) => {
//     setActiveTab(newValue);
//   };
//   return (
//     <div>
     
//       <div style={{display:'flex',overflowX:'hidden'}}>
//       <SideNav/>
//       <div style={{display:'column'}}>
//         <div style={{marginLeft:'-20px'}}>
//           <TopNav/>
//         </div>
//         <div >
//         <Tabs value={activeTab}
//            onChange={handleTabChange} 
//            style={{ marginTop:'50px',marginLeft:'500px'}}
//            >
//             <Tab label="Customer" />
//             <Tab label="Existing Customer" />
//           </Tabs>
//           <Box hidden={activeTab !== 0} >
//             <CustomerIndex />
//           </Box>
//           <Box hidden={activeTab !== 1} style={{marginLeft:'20px'}}>
//             <ExistingCustomer />
//           </Box>
//         </div>
//       </div>
//       </div>
//     </div>
//   )
// }

// export default CustomerIndexRouting

import React,{ useState } from 'react';
import SideNav from '../SideNav/SideNav';
import TopNav from '../TopNav/TopNav';
import ExistingCustomer from './ExistingCustomer';

function CustomerIndexRouting() {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchInputChange = (query) => {
    setSearchQuery(query);
  };
  return (
    <div style={{ display: 'flex', overflow: 'hidden' ,minHeight:'700px'}}>
      <SideNav />
      <div style={{ overflowY: 'hidden', flexGrow: 1, marginLeft: '-20px' }}>
        <TopNav onSearchInputChange={handleSearchInputChange} />
        <div style={{marginLeft:'20px',marginRight:'20px'}}>
        <ExistingCustomer searchQuery={searchQuery} />
        </div>
      </div>
    </div>
  );
}

export default CustomerIndexRouting;





// import React from 'react'
// import SideNav from '../SideNav/SideNav'
// import TopNav from '../TopNav/TopNav'
// import ExistingCustomer from './ExistingCustomer';
// function CustomerIndexRouting() {
//   return (
   
//       <>
     
     
        
//      <div style={{overflowX:'hidden'}}>
//      <TopNav/>
//      <div className='row'>
//       <div className='col-4'>
//       <SideNav/>
//       </div>
//       <div className='col-8'>
//       <ExistingCustomer/>
//       </div>
//      </div>
//      </div>

 
    
//       </>
     

//   )
// }

// export default CustomerIndexRouting
