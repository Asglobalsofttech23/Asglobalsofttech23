import { Dialog, DialogActions, DialogContent, DialogTitle, Grid, MenuItem, TextField,Button } from '@mui/material';
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import config from '../../../config';
function AddMarketingCustomer({onClose}) {

    const [employee,setEmployee] = useState([])

    const [errorDialog,setErrorDialog] = useState(false);
    const [errorData,setErrorData] = useState('')



    useEffect(()=>{
        axios.get(`${config.apiUrl}/marketing/getmarketingEmployee`)
        .then(response =>{
            setEmployee(response.data)
        })
        .catch((error) =>{
            setErrorDialog(true);
            setErrorData(error);
        })
    },[])

    const [formData,setFormData] = useState({
        mark_cust_name : '',
        mark_cust_mobile : '',
        mark_cust_email : '',
        mark_cust_bus_name : '',
        mark_cust_bus_category : '',
        category : '',
        follow_up_date : '',
        emp_id : ''
    })

    const [errors,setErrors] = useState({
        mark_cust_name : '',
        mark_cust_mobile : '',
        mark_cust_email : '',
        mark_cust_bus_name : '',
        mark_cust_bus_category : '',
        category : '',
        follow_up_date : '',
        emp_id : ''
    })

    const handleValidation = (name,value) =>{
        let errorMsg = "";
        const trimmedValue = value && typeof value === "string" ? value.trim() : value ;

        switch (name){
            case "mark_cust_name" :
                if(!trimmedValue){
                    errorMsg = "Customer Name is Required"
                }
                break ;
            case "mark_cust_mobile" :
                if(!trimmedValue){
                    errorMsg = "Customer Mobile Number is Required"
                }else if (!/^\d{10}$/.test(trimmedValue)) {
                    errorMsg = "Enter a valid Mobile Number";
                }
                break;
            case "mark_cust_email" :
                if(!trimmedValue){
                    errorMsg = "Email Address is Required";
                }else if (!/\S+@\S+\.\S+/.test(trimmedValue)) {
                    errorMsg = "Enter a valid email address";
                  }
                break;
            case "mark_cust_bus_name" :
                if(!trimmedValue){
                    errorMsg = "Bussiness Name is Required"
                }
                break;
            case "mark_cust_bus_category" :
                if(!trimmedValue){
                    errorMsg = "Bussiness Category is Required"
                }
                break;
            case "category" :
                if(!trimmedValue){
                    errorMsg = "Please select one priority"
                }
                break;
            case "emp_id" :
                if(!trimmedValue){
                    errorMsg = "Please select Followed Employee"
                }
                break;
            case "follow_up_date" :
                if(!trimmedValue){
                    errorMsg = "Followed Date is Required"
                }
                break;
            default:
                break;
        }
        return errorMsg;
    }

    const handleInputChange = (e) =>{
        const {name,value} = e.target;
        const error = handleValidation(name,value)
        setFormData({...formData,[name]:value});
        setErrors({...errors,[name]:error})
    }


    const handleSubmit = (e) =>{
        e.preventDefault();
        let formErrors = {};

        Object.keys(formData).forEach((name)=>{
            const value = formData[name];
            const error = handleValidation(name,value);
            if(error){
                formErrors[name] = error;
            }
        });

      
        if (Object.keys(formErrors).length > 0) {
            setErrors(formErrors);
            return;
        }
       
            axios.post(`${config.apiUrl}/marketing/postmarkCustData`,formData)
            .then((res)=>{
                console.log("result:",res)
                onClose();
            })
        
            .catch((error) => {
                setErrorDialog(true);
                setErrorData(error);
            });
    }

  return (
    <div>
        <h1 className='text-center'>Marketing Customer</h1>
      <Grid container spacing={3} style={{marginTop:'10px'}}>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label="Customer Name"
            name="mark_cust_name"
            value={formData.mark_cust_name}
            onChange={handleInputChange}
            error={!!errors.mark_cust_name}
            helperText={errors.mark_cust_name}
            
            />
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label="Customer Mobile"
            name="mark_cust_mobile"
            value={formData.mark_cust_mobile}
            onChange={handleInputChange}
            error={!!errors.mark_cust_mobile}
            helperText={errors.mark_cust_mobile}
            
            />
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label="Customer Email"
            name="mark_cust_email"
            value={formData.mark_cust_email}
            onChange={handleInputChange}
            error={!!errors.mark_cust_email}
            helperText={errors.mark_cust_email}
            
            />
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label="Bussiness Name"
            name="mark_cust_bus_name"
            value={formData.mark_cust_bus_name}
            onChange={handleInputChange}
            error={!!errors.mark_cust_bus_name}
            helperText={errors.mark_cust_bus_name}
            
            />
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label="Bussiness Category"
            name="mark_cust_bus_category"
            value={formData.mark_cust_bus_category}
            onChange={handleInputChange}
            error={!!errors.mark_cust_bus_category}
            helperText={errors.mark_cust_bus_category}
            
            />
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            select
            label="Priority"
            name="category"
            value={formData.category}
            onChange={handleInputChange}
            error={!!errors.category}
            helperText={errors.category}
            >
                <MenuItem value=''> Select Priority</MenuItem>
                <MenuItem value='1'> 1st Priority</MenuItem>
                <MenuItem value='2'> 2nd Priority</MenuItem>
                <MenuItem value='3'> 3rd Priority</MenuItem>
                <MenuItem value='4'> 4th Priority</MenuItem>
                </TextField>
        </Grid>
        <Grid item xs={6}>
            <TextField
            select
            fullWidth
            label="Select Employee"
            name = "emp_id"
            onChange={handleInputChange}
            error = {!!errors.emp_id}
            helperText={errors.emp_id}
            >
                {employee.map((emp)=>(
                    <MenuItem key={emp.emp_id} value={emp.emp_id}>{emp.emp_name}</MenuItem>
                ))}
            </TextField>
        </Grid>
        <Grid item xs={6}>
        <TextField
            fullWidth
            label="Follow Up Date"
            name="follow_up_date"
            type='date'
            value={formData.follow_up_date}
            onChange={handleInputChange}
            InputLabelProps={{shrink:true}}
            error={!!errors.follow_up_date}
            helperText={errors.follow_up_date}
            />
        </Grid>
        <Grid item xs={12} style={{display:'flex',justifyContent:'center'}}>
            <Button style={{
                backgroundColor: "#1B9C85",
                borderColor: "#1B9C85",
                color: "white",
            }} onClick={handleSubmit}>Submit</Button>
        </Grid>
      </Grid>

      <Dialog open={errorDialog}>
        <DialogTitle className='text-center bg-danger'>Error</DialogTitle>
        <DialogContent>
          <p>Status Code: {errorData.response?.status}</p>
          <p>Error Message: {errorData.message}</p>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setErrorDialog(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}

export default AddMarketingCustomer
