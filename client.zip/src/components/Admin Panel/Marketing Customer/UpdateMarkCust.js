import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, MenuItem, TextField } from '@mui/material'
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import config from '../../../config';
const categoryLookup = {
    "1st Priority": 1,
    "2nd Priority": 2,
    "3rd Priority": 3,
    "4th Priority": 4,
  };
function UpdateMarkCust({custData,onClose}) {
    const [updateData,setUpdateData] = useState({
        mark_cust_id : custData ? custData.mark_cust_id : '',
        mark_cust_name : custData ? custData.mark_cust_name : '',
        mark_cust_mobile : custData ? custData.mark_cust_mobile : '',
        mark_cust_email : custData ? custData.mark_cust_email : '',
        mark_cust_bus_name : custData ? custData.mark_cust_bus_name : '',
        mark_cust_bus_category : custData ? custData.mark_cust_bus_category : '',
        category : custData ? categoryLookup[custData.category] || '' : '',
        emp_id : custData ? custData.emp_id : '',
        follow_up_date : custData ? custData.follow_up_date : '',

    })
    const [errorDialog,setErrorDialog] = useState(false);
    const [errorData,setErrorData] = useState('')
    const [employee,setEmployee] = useState([])

    useEffect(()=>{
        axios.get(`${config.apiUrl}/marketing/getmarketingEmployee`)
        .then(response =>{
            setEmployee(response.data)
        })
        .catch((error) =>{
            setErrorDialog(true);
            setErrorData(error);
        })
    },[])

    const [errors,setErrors] = useState({
        mark_cust_name : '',
        mark_cust_mobile : '',
        mark_cust_email : '',
        mark_cust_bus_name : '',
        mark_cust_bus_category : '',
        category : '',
        follow_up_date : '',
        emp_id : ''
    })

    const handleValidation = (name,value) =>{
        let errorMsg = "";
        const trimmedValue = value && typeof value === "string" ? value.trim() : value ;

        switch (name){
            case "mark_cust_name" :
                if(!trimmedValue){
                    errorMsg = "Customer Name is Required"
                }
                break ;
            case "mark_cust_mobile" :
                if(!trimmedValue){
                    errorMsg = "Customer Mobile Number is Required"
                }else if (!/^\d{10}$/.test(trimmedValue)) {
                    errorMsg = "Enter a valid Mobile Number";
                }
                break;
            case "mark_cust_email" :
                if(!trimmedValue){
                    errorMsg = "Email Address is Required";
                }else if (!/\S+@\S+\.\S+/.test(trimmedValue)) {
                    errorMsg = "Enter a valid email address";
                  }
                break;
            case "mark_cust_bus_name" :
                if(!trimmedValue){
                    errorMsg = "Bussiness Name is Required"
                }
                break;
            case "mark_cust_bus_category" :
                if(!trimmedValue){
                    errorMsg = "Bussiness Category is Required"
                }
                break;
            case "category" :
                if(!trimmedValue){
                    errorMsg = "Please select one priority"
                }
                break;
            case "emp_id" :
                if(!trimmedValue){
                    errorMsg = "Please select Followed Employee"
                }
                break;
            case "follow_up_date" :
                if(!trimmedValue){
                    errorMsg = "Followed Date is Required"
                }
                break;
            default:
                break;
        }
        return errorMsg;
    }

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        const error = handleValidation(name, value);
        setUpdateData({ ...updateData, [name]: value });
        setErrors({ ...errors, [name]: error });
      };
    
      const handleUpdate = (e) => {
        e.preventDefault();
        let formErrors = {};

        Object.keys(updateData).forEach((name)=>{
            const value = updateData[name];
            const error = handleValidation(name,value);
            if(error){
                formErrors[name] = error;
            }
        });

      
        if (Object.keys(formErrors).length > 0) {
            setErrors(formErrors);
            return;
        }
       
            axios.put(`${config.apiUrl}/marketing/${updateData.mark_cust_id}/update`,updateData)
            .then((res)=>{
                console.log("result:",res)
                onClose();
            })
        
            .catch((error) => {
                setErrorDialog(true);
                setErrorData(error);
            });
    }

  return (
    <div>
      <Grid container spacing={3}>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label = "Customer Name"
            name="mark_cust_name"
            value={updateData.mark_cust_name}
            onChange={handleInputChange}
            error={!!errors.mark_cust_name}
            helperText={errors.mark_cust_name}
            />
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label = "Customer Mobile"
            name="mark_cust_mobile"
            value={updateData.mark_cust_mobile}
            onChange={handleInputChange}
            error={!!errors.mark_cust_mobile}
            helperText={errors.mark_cust_mobile}

            />
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label = "Customer Email"
            name="mark_cust_email"
            value={updateData.mark_cust_email}
            onChange={handleInputChange}
            error={!!errors.mark_cust_email}
            helperText={errors.mark_cust_email}
            />
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label = "Customer Bussiness Name"
            name="mark_cust_bus_name"
            value={updateData.mark_cust_bus_name}
            onChange={handleInputChange}
            error={!!errors.mark_cust_bus_name}
            helperText={errors.mark_cust_bus_name}
            />
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label = "Customer Bussiness Category"
            name="mark_cust_bus_category"
            value={updateData.mark_cust_bus_category}
            onChange={handleInputChange}
            error={!!errors.mark_cust_bus_category}
            helperText={errors.mark_cust_bus_category}
            />
        </Grid>
        <Grid item xs={6}>
        <TextField
            select
            fullWidth
            label="Priority"
            name="category"
            value={updateData.category}
            onChange={handleInputChange}
            error={!!errors.category}
            helperText={errors.category}
            >
            <MenuItem value="">Select Priority</MenuItem>
            <MenuItem value="1">1st Priority</MenuItem>
            <MenuItem value="2">2nd Priority</MenuItem>
            <MenuItem value="3">3rd Priority</MenuItem>
            <MenuItem value="4">4th Priority</MenuItem>
            </TextField>

        </Grid>
        <Grid item xs={6}>
            <TextField
            select
            fullWidth
            label = "Select Employee"
            name="emp_id"
            value={updateData.emp_id}
            onChange={handleInputChange}
            error={!!errors.emp_id}
            helperText={errors.emp_id}
            >
                {employee.map((emp)=>(
                    <MenuItem key={emp.emp_id} value={emp.emp_id}>{emp.emp_name}</MenuItem>
                ))}
            </TextField>
        </Grid>
        <Grid item xs={6}>
            <TextField
            fullWidth
            label = "Follow up Date"
            name="follow_up_date"
            type='date'
            InputLabelProps={{shrink:true}}
            value={updateData.follow_up_date}
            onChange={handleInputChange}
            error={!!errors.follow_up_date}
            helperText={errors.follow_up_date}
            />
        </Grid>
        <Grid item xs={12} sx={{display:'flex',justifyContent:'center'}}>
            <Button onClick={handleUpdate} style={{backgroundColor: "#1B9C85",
                borderColor: "#1B9C85",
                color: "white",}}>Update</Button>
        </Grid>
      </Grid>

      <Dialog open={errorDialog}>
        <DialogTitle className='text-center bg-danger'>Error</DialogTitle>
        <DialogContent>
          <p>Status Code: {errorData.response?.status}</p>
          <p>Error Message: {errorData.message}</p>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setErrorDialog(false)}>Close</Button>
        </DialogActions>
      </Dialog>
    </div>
  )
}

export default UpdateMarkCust
