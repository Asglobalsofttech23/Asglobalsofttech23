import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Menu,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import axios from "axios";
import * as XLSX from "xlsx";
import ReactPaginate from "react-paginate";
import AddMarketingCustomer from "./AddMarketingCustomer";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import UpdateMarkCust from "./UpdateMarkCust";
import config from "../../../config";
function MarketingCustomers({ searchQuery }) {
  

  useEffect(() => {
    const highlightColor = 'black';
    const unhighlightColor = 'initial';
    const highlightBackground = 'yellow';
    const unhighlightBackground = 'white';
  
    const tableCells = document.querySelectorAll('td'); // Select all table cells or specific cells where you want to apply the highlight
  
    tableCells.forEach((cell) => {
      const cellText = cell.textContent;
      const searchQueryLC = searchQuery.toLowerCase();
      
      // Split the text content of the cell into parts based on the search query
      const parts = cellText.split(new RegExp(`(${searchQueryLC})`, 'gi'));
      
      // Recreate the inner HTML of the cell to highlight the matched parts
      cell.innerHTML = parts.map(part => {
        if (part.toLowerCase() === searchQueryLC) {
          return `<span style="color: ${highlightColor}; background-color: ${highlightBackground}">${part}</span>`;
        } else {
          return part;
        }
      }).join('');
    });
  }, [searchQuery]);
  

  const [marketingCustomer, setMarketingCustomer] = useState([]);

  useEffect(() => {
    axios
      .get(`${config.apiUrl}/marketing/getmarketingCustData`)
      .then((response) => {
        setMarketingCustomer(response.data);
      })
      .catch((error) => {
        console.log("Marketing Customer Data Could not be fetched", error);
      });
  });

  const [itemsPerPage, setItemsPerPage] = useState(5);
  const [currentPage, setCurrentPage] = useState(1);

  const handleChangeItemPerPage = (e) => {
    const newItemsPerPage = parseInt(e.target.value, 10);
    if (newItemsPerPage === 0) {
      setItemsPerPage(marketingCustomer.length);
      setCurrentPage(1);
    } else {
      setItemsPerPage(newItemsPerPage);
      setCurrentPage(1);
    }
  };

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = itemsPerPage - indexOfLastItem;
  const currentItems = marketingCustomer.slice(
    indexOfFirstItem,
    indexOfLastItem
  );

  const [searchedVal, setSearchedVal] = useState("");

  const filterData = (markCust) => {
    const searchValue = searchedVal.toLocaleLowerCase();
    return Object.values(markCust).some(
      (value) => value && value.toString().toLowerCase().includes(searchValue)
    );
  };

  const [selectedCustomer, setSelectedCustomer] = useState([]);

  const [selectAll, setSelectAll] = useState(false);

  const handleCheckboxChange = (markCustId) => {
    const selectedCustomerIds = [...selectedCustomer];
    if (selectedCustomerIds.includes(markCustId)) {
      const index = selectedCustomerIds.indexOf(markCustId);
      selectedCustomerIds.splice(index, 1);
    } else {
      selectedCustomerIds.push(markCustId);
    }
    setSelectedCustomer(selectedCustomerIds);
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedCustomer([]);
    } else {
      const allCustIds = marketingCustomer.map(
        (markCust) => markCust.mark_cust_id
      );
      setSelectedCustomer(allCustIds);
    }
    setSelectAll(!selectAll);
  };

  const [anchorEl, setAnchorEl] = useState(null);

  const handleExport = (format) => {
    if (marketingCustomer.length === 0) {
      console.log("No Customer selected for export");
      return;
    }

    switch (format) {
      case "CSV":
        exportToCSV();
        break;
      case "Excel":
        exportToExcel();
        break;
      case "JSON":
        exportToJSON();
        break;
      default:
        break;
    }
  };

  const exportToCSV = () => {
    if (selectedCustomer.length === 0) {
      console.log("No Customer selected for export");
      return;
    }

    const selectedCustomerData = marketingCustomer.filter((markCust) =>
      selectedCustomer.includes(markCust.mark_cust_id)
    );

    // Create CSV content
    const header = Object.keys(selectedCustomerData[0]).join(",");
    const csv = [
      header,
      ...selectedCustomerData.map((markCust) =>
        Object.values(markCust)
          .map((value) => `"${value}"`)
          .join(",")
      ),
    ].join("\n");

    // Create Blob for CSV file
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);

    // Download CSV file
    const a = document.createElement("a");
    a.href = url;
    a.download = "marketing customer.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportToExcel = () => {
    const selectedCustomerData = marketingCustomer.filter((markCust) =>
      selectedCustomer.includes(markCust.mark_cust_id)
    );
    const worksheet = XLSX.utils.json_to_sheet(selectedCustomerData);

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Customer");
    XLSX.writeFile(workbook, "marketing customer.xlsx");
  };

  const exportToJSON = () => {
    const selectedCustomerData = marketingCustomer.filter((markCust) =>
      selectedCustomer.includes(markCust.mark_cust_id)
    );

    const jsonData = JSON.stringify(selectedCustomerData, null, 2);
    const blob = new Blob([jsonData], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "marketing customer.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const [addCustomer, setAddCustomer] = useState(false);
  const [openSuccessDialog, setOpenSuccessDialog] = useState(false);

  const handleOpenDialog = () => {
    setAddCustomer(true);
  };

  const handlecloseAddForm = () => {
    setAddCustomer(false);
    setOpenSuccessDialog(true);
  };

  const [openEditDialog,setOpenEditDialog] = useState(false);
  const [selectedCustDataEdit,setSelectedCustDataEdit] = useState();
  const [updateSuccessmsg , setUpdateSuccessmsg] = useState()

  const handleEditCustomer = (markCustId) =>{
    const selectedCustData = marketingCustomer.find((markCust)=>markCust.mark_cust_id === markCustId);
    if(selectedCustData){
      setOpenEditDialog(true);
      setSelectedCustDataEdit(selectedCustData);
    }
  }

  const handleCloseEdit = () =>{
    setOpenEditDialog(false);
    setUpdateSuccessmsg(true)
  }

  const [openDltDialog, setOpenDltDialog] = useState(false);
  const [deleteCustomerId, setDeleteCustomerId] = useState(null);

  const handleDltCustomer = (markCustId) => {
    setDeleteCustomerId(markCustId);
    setOpenDltDialog(true);
  };

  const confirmDlt = () => {
    if (!deleteCustomerId) {
      setOpenDltDialog(false);
      return;
    }
  
    axios
      .delete(`${config.apiUrl}/marketing/${deleteCustomerId}/delete`)
      .then(() => {
        // Handle successful deletion, e.g., update state or fetch data again
        const updatedMarketingCustomer = marketingCustomer.filter(
          (markCust) => markCust.mark_cust_id !== deleteCustomerId
        );
        setMarketingCustomer(updatedMarketingCustomer);
  
        setOpenDltDialog(false);
      })
      .catch((error) => {
        console.error("Error deleting customer:", error);
        
      });
  };
  
  return (
    <div>
      <h1 className="text-center mt-5">Marketing Customer</h1>
      <div className="row" style={{ marginTop: "50px", marginBottom: "50px" }}>
        <div className="col-3">
          <Button
            style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}
            onClick={(e) => setAnchorEl(e.currentTarget)}
          >
            Export data
          </Button>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={() => setAnchorEl(null)}
          >
            <MenuItem onClick={() => handleExport("CSV")}>
              Export as CSV
            </MenuItem>
            <MenuItem onClick={() => handleExport("Excel")}>
              Export as Excel
            </MenuItem>
            <MenuItem onClick={() => handleExport("JSON")}>
              Export as JSON
            </MenuItem>
          </Menu>
        </div>
        <div className="col-3">
          <TextField
            label="Search"
            onChange={(e) => setSearchedVal(e.target.value)}
          />
        </div>
        <div className="col-3">
          <select
            value={itemsPerPage}
            onChange={handleChangeItemPerPage}
            style={{
              padding: "5px 10px",
              margin: "0 5px",
              border: "1px solid #007bff",
              borderRadius: "4px",
              cursor: "pointer",
              backgroundColor: "#fff",
              color: "#007bff",
              textDecoration: "none",
              transition: "background-color 0.3s, color 0.3s",
            }}
          >
            <option value="5">5 Per Page</option>
            <option value="10">10 Per Page</option>
            <option value="15">15 Per Page</option>
            <option value="0">All Per Page</option>
          </select>
        </div>
        <div className="col-3">
          <Button
            onClick={handleOpenDialog}
            style={{
              backgroundColor: "#1B9C85",
              borderColor: "#1B9C85",
              color: "white",
            }}
          >
            Add New Customer
          </Button>
        </div>
      </div>
      {marketingCustomer.length > 0 ? (
        <>
          <TableContainer component={Paper}>
            <Table>
              <TableHead style={{ backgroundColor: "#1B9C85" }}>
                <TableRow>
                  <TableCell>
                    <Checkbox checked={selectAll} onChange={handleSelectAll} />
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    S.No
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Name
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Mobile
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Customer Email
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Bussiness Name
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Bussiness Category
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Priority
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Followed By
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Follo Up Date
                  </TableCell>
                  <TableCell
                    style={{ border: "1px solid #ddd", color: "whitesmoke" }}
                  >
                    Action
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {currentItems.filter(filterData).map((markCust, index) => (
                  <TableRow key={markCust.mark_cust_id}>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      <Checkbox
                        checked={selectedCustomer.includes(
                          markCust.mark_cust_id
                        )}
                        onChange={() =>
                          handleCheckboxChange(markCust.mark_cust_id)
                        }
                      />
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {index + 1}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {markCust.mark_cust_name}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {markCust.mark_cust_mobile}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {markCust.mark_cust_email}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {markCust.mark_cust_bus_name}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {markCust.mark_cust_bus_category}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {markCust.category}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {markCust.emp_name}
                    </TableCell>
                    <TableCell style={{ border: "1px solid #ddd" }}>
                      {markCust.follow_up_date}
                    </TableCell>
                    <TableCell
                      style={{ border: "1px solid #ddd", width: "250px" }}
                    >
                      <Button
                          onClick={() => handleEditCustomer(markCust.mark_cust_id)}
                        >
                          <EditIcon />
                          Edit
                        </Button>
                      <Button
                        onClick={() => handleDltCustomer(markCust.mark_cust_id)}
                      >
                        <DeleteIcon style={{ color: "red" }} />
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <nav aria-label="Page navigation" className="text-center">
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "20px",
              }}
            >
              <ReactPaginate
                previousLabel={
                  <span
                    style={{
                      padding: "5px 10px",
                      margin: "0 5px",
                      border: "1px solid #ccc",
                      borderRadius: "4px",
                      cursor: "pointer",
                      backgroundColor: "#152445",
                      color: "white",
                      textDecoration: "underline",
                      textDecorationColor: "#152445",
                    }}
                  >
                    Previous
                  </span>
                }
                nextLabel={
                  <span
                    style={{
                      padding: "5px 10px",
                      margin: "0 5px",
                      border: "1px solid #ccc",
                      borderRadius: "4px",
                      cursor: "pointer",
                      backgroundColor: "#152445",
                      color: "white",
                      textDecoration: "underline",
                      textDecorationColor: "#152445",
                    }}
                  >
                    Next
                  </span>
                }
                breakLabel={
                  <span
                    style={{
                      padding: "5px 10px",
                      margin: "0 5px",
                      border: "1px solid #ccc",
                      borderRadius: "4px",
                      cursor: "pointer",
                      backgroundColor: "#fff",
                      color: "#333",
                      textDecoration: "none",
                    }}
                  >
                    ...
                  </span>
                }
                pageCount={Math.ceil(
                  marketingCustomer.filter(filterData).length / itemsPerPage
                )} // Use 'customers' instead of 'filteredCustomers'
                marginPagesDisplayed={2}
                pageRangeDisplayed={4}
                onPageChange={({ selected }) => setCurrentPage(selected + 1)}
                containerClassName={"pagination justify-content-center"}
                subContainerClassName={"pages pagination"}
                activeClassName={"active"}
              />
            </div>
          </nav>

          
        </>
      ) : (
        <p>Marketing Customer data is not available</p>
      )}

          <Dialog
            open={addCustomer}
            onClose={() => setAddCustomer(false)}
            maxWidth="md"
          >
            <DialogContent>
              <AddMarketingCustomer onClose={handlecloseAddForm} />
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setAddCustomer(false)}>Close</Button>
            </DialogActions>
          </Dialog>

          <Dialog
            open={openSuccessDialog}
            onClose={() => setOpenSuccessDialog(false)}
            maxWidth="md"
          >
             <DialogTitle className="text-center bg-success">Success</DialogTitle>
            <DialogContent>
              <p className="text-center">
                Marketing Customer Added Successfully
              </p>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setOpenSuccessDialog(false)}>Close</Button>
            </DialogActions>
          </Dialog>

          <Dialog
            open={updateSuccessmsg}
            onClose={() => setUpdateSuccessmsg(false)}
            maxWidth="md"
          >
            <DialogTitle className="text-center bg-success">Success</DialogTitle>
            <DialogContent>
              <p className="text-center">
                Marketing Customer Updated Successfully
              </p>
            </DialogContent>
            <DialogActions>
              <Button onClick={() => setUpdateSuccessmsg(false)}>Close</Button>
            </DialogActions>
          </Dialog>



          <Dialog open={openEditDialog} onClose={()=>setOpenEditDialog(false)} maxWidth='md'>
            <DialogContent>
              <UpdateMarkCust custData={selectedCustDataEdit} onClose={handleCloseEdit}/>
            </DialogContent>
            <DialogActions>
              <Button onClick={()=>setOpenEditDialog(false)}></Button>
            </DialogActions>
          </Dialog>

          <Dialog open={openDltDialog} onClose={() => setOpenDltDialog(false)}>
  <DialogContent>
    <div>
      <p>Are you sure you want to delete this Customer?</p>
    </div>
  </DialogContent>
  <DialogActions>
    <Button
      variant="contained"
      onClick={confirmDlt}
      style={{ backgroundColor: "#DC143C", color: "white" }}
    >
      OK
    </Button>
    <Button
      variant="contained"
      onClick={() => setOpenDltDialog(false)}
      style={{ backgroundColor: "#1B9C85", color: "white" }}
    >
      Cancel
    </Button>
  </DialogActions>
</Dialog>

    </div>
  );
}

export default MarketingCustomers;
