import React from 'react'

import Login from './Login';
import LoginTopNav from './LoginTopNav';

const LoginRouting = ({handleLogin}) =>{

    return(
        <>
        <LoginTopNav/>
        <Login handleLogin={handleLogin}/>
        </>
    )
}

export default LoginRouting;