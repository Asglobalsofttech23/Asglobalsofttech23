

import { Button, Grid, Paper, TextField } from '@mui/material';
import React, { useState } from 'react';

function Login({ handleLogin }) {
    const [formData, setFormData] = useState({
        username: '',
        password: '',
    });

    const handleChangeInput = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        handleLogin(formData.username, formData.password);
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
            <Paper elevation={3} style={{ padding: '20px', width: '300px', textAlign: 'center', borderRadius: '10px', background: '#f0f0f0' }}>
                <h1>Login Form</h1>
                <form onSubmit={handleSubmit}>
                    <TextField
                        fullWidth
                        label="User Name"
                        name="username"
                        value={formData.username}
                        onChange={handleChangeInput}
                        variant="outlined"
                        style={{ marginBottom: '15px' }}
                    />
                    <TextField
                        fullWidth
                        label="Password"
                        name="password"
                        type="password"
                        value={formData.password}
                        onChange={handleChangeInput}
                        variant="outlined"
                        style={{ marginBottom: '15px' }}
                    />
                     <Button type="submit" variant="contained" >
                        Login
                       
                    </Button>
                </form>
            </Paper>
        </div>
    );
}

export default Login;
