// config.js
const config = {
  apiUrl: 'http://localhost:3001',
  // apiUrl: 'https://server-0flp.onrender.com',
};

export default config;
