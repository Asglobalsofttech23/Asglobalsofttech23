import React, { useState } from 'react';
import axios from 'axios';

const Images = () => {
  const [imageData, setImageData] = useState(null);

  const handleFileChange = (e) => {
    // Use FormData to handle file uploads
    const formData = new FormData();
    formData.append('imageData', e.target.files[0]);
    setImageData(formData);
  };

  const handleUpload = () => {
    if (imageData) {
      axios.post('http://localhost:3001/departments/uploadImages', imageData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })
        .then((res) => {
          console.log("Image added successfully");
        })
        .catch((error) => {
          console.error("Error uploading image:", error);
        });
    }
  };

  return (
    <div>
      <input type="file" onChange={handleFileChange} />
      <button onClick={handleUpload}>Upload Image</button>
    </div>
  );
};

export default Images;
