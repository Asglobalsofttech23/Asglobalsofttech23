import React, { useState } from 'react';
import axios from 'axios';
import {Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, Paper, TextField} from '@mui/material'

function SmsSender() {
  const [message, setMessage] = useState('');
  const [numbers, setNumbers] = useState('');
  const [openSuccessMsg,setOpenSuccessMsg] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3001/sms/send-message', {
        message: message,
        numbers: numbers,
      });
      console.log('Server response:', response.data);
      // Handle success or display a success message to the user
    } catch (error) {
      console.error('Error:', error.message);
      // Handle error or display an error message to the user
    }
    setOpenSuccessMsg(true)
  };

  const handleChangeInput = (e) => {
    const { name, value } = e.target;
    if (name === 'number') {
      setNumbers(value);
    } else if (name === 'message') {
      setMessage(value);
    }
  };
  

  return (
    <>
    <h1 className='text-center'>SMS Form</h1>
   <Grid container spacing={3}>
    <Grid item xs={6}>
    <TextField
    fullWidth
    label="Numbers"
    name='number'
    value={numbers}
    onChange={handleChangeInput}
    />
    </Grid>
    <Grid item xs={6}>
      <TextField
      fullWidth
      label="Message"
      name='message'
      value={message}
      onChange={handleChangeInput}
      />
    </Grid>
   </Grid>
   <div style={{display:'flex',justifyContent:'center',marginTop:'20px'}}>
    <Button style={{backgroundColor:'GrayText',color:'whitesmoke'}} onClick={handleSubmit}>Submit</Button>
   </div>

   <Dialog open={openSuccessMsg} onClose={()=>setOpenSuccessMsg(false)}>
    <DialogTitle className='text-center' style={{backgroundColor:"green",color:'white'}}>Success Message</DialogTitle>
    <DialogContent>
      <h4>Successfully Send SMS</h4>
    </DialogContent>
    <DialogActions>
      <Button onClick={()=>setOpenSuccessMsg(false)}>Close</Button>
    </DialogActions>
   </Dialog>
  </>
  );
}

export default SmsSender;

