import React, { useState, useEffect } from 'react';
import axios from 'axios';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

function GetUserLocation() {
    const [latitude, setLatitude] = useState();
    const [longitude, setLongitude] = useState();
    const [userAddress, setUserAddress] = useState();

    useEffect(() => {
        const geo = navigator.geolocation;
        const userCoords = (position) => {
            let userLatitude = position.coords.latitude;
            let userLongitude = position.coords.longitude;
            setLatitude(userLatitude);
            setLongitude(userLongitude);
        };
        geo.getCurrentPosition(userCoords);
    }, []);

    const getUserAddress = () => {
        if (latitude !== undefined && longitude !== undefined) {
            axios
                .get(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=AIzaSyCSLb6avWRYIgKg6ERHurckG6-mtbfCV0E`)
                .then((res) => {
                    // const address = res.data.results[0].formatted_address;
                    console.log('User Address:', res);
                    // setUserAddress(address);
                    renderMap();
                })
                .catch((error) => {
                    console.error('Error fetching user address:', error);
                    setUserAddress('Address not available');
                });
        }
    };

    const renderMap = () => {
        const map = L.map('map').setView([latitude, longitude], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);
        L.marker([latitude, longitude]).addTo(map).bindPopup(userAddress).openPopup();
    };

    useEffect(() => {
        getUserAddress();
    }, [latitude, longitude]);

    return (
        <div>
            <h1>Get User Location</h1>
            <h2>Latitude - {latitude}</h2>
            <h2>Longitude - {longitude}</h2>
            <div id="map" style={{ width: '100%', height: '400px' }}></div>
        </div>
    );
}

export default GetUserLocation;
