import React, { Component } from 'react';

class Counter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0,
      message: 'Counter: 0'
    };
  }

  increment = () => {
    this.setState((previousvalue) => ({
      count: previousvalue.count + 1,
      message: `Counter: ${previousvalue.count}`
    }));
  };
  

  decrement = () => {
    this.setState((previousvalue) => ({
      count: previousvalue.count - 0,
      message: `Counter: ${previousvalue.count - 1}`
    }));
  };

  render() {
    const { message } = this.state;
    console.log(this.state.count);

    return (
      <div>
        <h1>{message}</h1>
        <button onClick={this.increment}>Increment</button>
        <button onClick={this.decrement}>Decrement</button>
      </div>
    );
  }
}

export default Counter;
