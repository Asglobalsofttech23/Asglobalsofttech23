import React, { useState } from 'react'

function Vignesh({variable}) {

  

  return (
    <div>
       {variable.map((vari,index) => (
       <p>{index}</p>
      ))}
    </div>
  )
}

export default Vignesh
