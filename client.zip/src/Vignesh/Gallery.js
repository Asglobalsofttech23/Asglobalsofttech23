import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Gallery() {
  const [images, setImages] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3001/departments/getAllImages')
      .then((res) => {
        console.log('Image response:', res.data);
        setImages(res.data);  // Set the image data in the state
      })
      .catch((error) => {
        console.error('Error fetching images:', error);
      });
  }, []);

  return (
    <div>
      <h1>Image Gallery</h1>
      {images.map((image, index) => (
        <img key={index} src={`data:image/jpeg;base64,${image.imageData}`} alt={`Image ${index}`} />
      ))}
    </div>
  );
}

export default Gallery;
