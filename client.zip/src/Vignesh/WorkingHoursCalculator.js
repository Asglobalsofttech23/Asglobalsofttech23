import React, { useState } from "react";
import moment from "moment";
import { Button, Grid, TextField } from "@mui/material";

const WorkingHoursCalculator = () => {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [hoursPerDay, setHoursPerDay] = useState("");
  const [totalHours, setTotalHours] = useState(0);
  const [workingDays, setWorkingDays] = useState([]);
  const [selectedHolidays, setSelectedHolidays] = useState([]);
  const [isHolidaysEnabled, setIsHolidaysEnabled] = useState(false);
  const [workingDayCounts, setWorkingDayCounts] = useState(null);

  const calculateTotalHours = () => {
    const start = moment(startDate, "YYYY-MM-DD");
    const end = moment(endDate, "YYYY-MM-DD");
    const hoursPerDayNumber = parseInt(hoursPerDay, 10);

    let currentDate = moment(start);
    let totalWorkingHours = 0;
    const days = [];
    const holidays = [...selectedHolidays];
    setIsHolidaysEnabled(true);

    while (currentDate <= end) {
      const dayOfWeek = currentDate.day();

      const currentFormattedDate = currentDate.format("YYYY-MM-DD");

      if (dayOfWeek !== 0 && dayOfWeek !== 7) {
        if (!holidays.includes(currentFormattedDate)) {
          totalWorkingHours += hoursPerDayNumber;
          days.push(currentDate.format("dddd"));
        }
      }
      currentDate.add(1, "day");
    }

    setTotalHours(totalWorkingHours);
    setWorkingDays(days);

    const dayCounts = {
      Sunday: 0,
      Monday: 0,
      Tuesday: 0,
      Wednesday: 0,
      Thursday: 0,
      Friday: 0,
      Saturday: 0,
    };

    for (const day of days) {
      const dayOfWeek = moment(day, "dddd").format("dddd");
      dayCounts[dayOfWeek]++;
    }

    const table = (
      <table>
        <thead>
          <tr>
            {Object.keys(dayCounts).map((day) => (
              <th key={day}>{day}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          <tr>
            {Object.values(dayCounts).map((count, index) => (
              <td key={index}>{count}</td>
            ))}
          </tr>
        </tbody>
      </table>
    );

    setWorkingDayCounts(table);
  };

  const handleHolidaySelection = (e) => {
    const selectedDate = e.target.value;
    const selectedMoment = moment(selectedDate, "YYYY-MM-DD");

    if (
      selectedMoment.isSameOrAfter(moment(startDate)) &&
      selectedMoment.isSameOrBefore(moment(endDate))
    ) {
      if (!selectedHolidays.includes(selectedDate)) {
        setSelectedHolidays([...selectedHolidays, selectedDate]);
      } else {
        const updatedHolidays = selectedHolidays.filter(
          (date) => date !== selectedDate
        );
        setSelectedHolidays(updatedHolidays);
      }
    } else {
      // Alert or message indicating the selected date is outside the range
      // You can use state to display a message or an alert here
      console.log("Selected date is outside the range of start and end dates");
    }
  };

  
  

  return (
    <>
      <Grid container spacing={2}>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Start Date"
            type="date"
            value={startDate}
            InputLabelProps={{ shrink: true }}
            onChange={(e) => setStartDate(e.target.value)}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="End Date"
            type="date"
            InputLabelProps={{ shrink: true }}
            value={endDate}
            onChange={(e) => {
              setEndDate(e.target.value);
              setIsHolidaysEnabled(false);
            }}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Select Holidays"
            type="date"
            InputLabelProps={{ shrink: true }}
            onChange={handleHolidaySelection}
            min={startDate}
            max={endDate}
            value={selectedHolidays}
            multiple
            InputProps={{
              inputProps: {
                min: startDate,
                max: endDate,
              },
            }}
          />
        </Grid>

        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Hours Per Day"
            type="number"
            value={hoursPerDay}
            onChange={(e) => setHoursPerDay(e.target.value)}
          />
        </Grid>
        <Grid item xs={12}>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginTop: "25px",
            }}
          >
            <Button
              onClick={calculateTotalHours}
              style={{
                backgroundColor: "#1B9C85",
                borderColor: "#1B9C85",
                color: "white",
              }}
            >
              Calculate Total Hours
            </Button>
          </div>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginTop: "25px",
            }}
          >
            <p>Total Working Hours: {totalHours}</p>
            {workingDayCounts && <div>{workingDayCounts}</div>}
          </div>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginTop: "25px",
            }}
          >
            <p>Total Working Days: {workingDays.length}</p>
            {/* <p>Total Holidays: {selectedHolidays.length}</p> */}
          </div>
        </Grid>
      </Grid>
    </>
  );
};

export default WorkingHoursCalculator;

// import React, { useState } from 'react';
// import moment from 'moment';
// const WorkingHoursCalculator = () => {
//   const [startDate, setStartDate] = useState('');
//   const [endDate, setEndDate] = useState('');
//   const [hoursPerDay, setHoursPerDay] = useState('');
//   const [totalHours, setTotalHours] = useState(0);
//   const [workingDays, setWorkingDays] = useState([]);

//   const calculateTotalHours = () => {
//     // const start = new Date(startDate);
//     const start = moment(startDate).format('YYYY-MM-DD');
//     console.log("Start Date :",start)
//     const end =  moment(endDate).format('YYYY-MM-DD');
//     const hoursPerDayNumber = parseInt(hoursPerDay);

//     let currentDate = moment(start);
//     console.log("Current Date :",currentDate)
//     let totalWorkingHours = 0;
//     const days = [];

//     while (currentDate <= end) {
//       const dayOfWeek = currentDate.getDay();
//       if (dayOfWeek !== 0 && dayOfWeek !== 6) {
//         // Exclude weekends (Sunday = 0, Saturday = 6)
//         totalWorkingHours += hoursPerDayNumber;
//         days.push(currentDate.toLocaleString('default', { weekday: 'long' }));
//       }
//       currentDate.setDate(currentDate.getDate() + 1); // Move to the next day
//     }

//     setTotalHours(totalWorkingHours);
//     setWorkingDays(days);
//   };

//   return (
//     <div>
//       <label>
//         Start Date:
//         <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
//       </label>
//       <br />
//       <label>
//         End Date:
//         <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
//       </label>
//       <br />
//       <label>
//         Hours per Day:
//         <input type="number" value={hoursPerDay} onChange={(e) => setHoursPerDay(e.target.value)} />
//       </label>
//       <br />
//       <button onClick={calculateTotalHours}>Calculate Total Hours</button>
//       <br />
//       <p>Total Working Hours: {totalHours}</p>
//       <p>Working Days: {workingDays.join(', ')}</p>
//     </div>
//   );
// };

// export default WorkingHoursCalculator;
