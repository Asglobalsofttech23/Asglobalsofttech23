import axios from 'axios';
import React, { useState } from 'react'

function Raja() {

  const [data,setData] = useState([]);

  axios.get(`https://jsonplaceholder.typicode.com/users`)
  .then((res)=>{
console.log(res)
  })
  return (
    <div>
      
    </div>
  )
}

export default Raja
