import React, { useState } from "react";

const TimetableGenerator = () => {
  const [daysInWeek, setDaysInWeek] = useState(5);
  const [periodsInDay, setPeriodsInDay] = useState(6);
  const [subjectsOffered, setSubjectsOffered] = useState([]);
  const [teachersAvailable, setTeachersAvailable] = useState([]);
  const [classesSections, setClassesSections] = useState([]);

  const handleSubjectsChange = (e, index) => {
    const subjects = [...subjectsOffered];
    subjects[index] = e.target.value;
    setSubjectsOffered(subjects);
  };

  const handleTeachersChange = (e, index) => {
    const teachers = [...teachersAvailable];
    teachers[index] = e.target.value;
    setTeachersAvailable(teachers);
  };

  const handleClassesChange = (e, index) => {
    const classes = [...classesSections];
    classes[index] = e.target.value;
    setClassesSections(classes);
  };

  const addSubject = () => {
    setSubjectsOffered([...subjectsOffered, ""]);
  };

  const addTeacher = () => {
    setTeachersAvailable([...teachersAvailable, ""]);
  };

  const addClass = () => {
    setClassesSections([...classesSections, ""]);
  };

  const generateTimetable = () => {
    // Logic to generate timetable (not included without backend)
    // This function would typically call a backend API with the input data
    console.log("Generating timetable...");
    console.log({
      daysInWeek,
      periodsInDay,
      subjectsOffered,
      teachersAvailable,
      classesSections,
    });
  };

  return (
    <div>
      <h2>Timetable Generator</h2>
      <label>
        Number of Days in a Week:
        <input
          type="number"
          value={daysInWeek}
          onChange={(e) => setDaysInWeek(e.target.value)}
        />
      </label>
      <br />
      <label>
        Number of Periods in a Day:
        <input
          type="number"
          value={periodsInDay}
          onChange={(e) => setPeriodsInDay(e.target.value)}
        />
      </label>
      <br />
      <h3>Subjects Offered</h3>
      {subjectsOffered.map((subject, index) => (
        <div key={index}>
          <input
            type="text"
            value={subject}
            onChange={(e) => handleSubjectsChange(e, index)}
            placeholder={`Subject ${index + 1}`}
          />
        </div>
      ))}
      <button onClick={addSubject}>Add Subject</button>
      <br />
      <h3>Teachers Available</h3>
      {teachersAvailable.map((teacher, index) => (
        <div key={index}>
          <input
            type="text"
            value={teacher}
            onChange={(e) => handleTeachersChange(e, index)}
            placeholder={`Teacher ${index + 1}`}
          />
        </div>
      ))}
      <button onClick={addTeacher}>Add Teacher</button>
      <br />
      <h3>Classes/Sections</h3>
      {classesSections.map((cls, index) => (
        <div key={index}>
          <input
            type="text"
            value={cls}
            onChange={(e) => handleClassesChange(e, index)}
            placeholder={`Class/Section ${index + 1}`}
          />
        </div>
      ))}
      <button onClick={addClass}>Add Class/Section</button>
      <br />
      <button onClick={generateTimetable}>Generate Timetable</button>
    </div>
  );
};

export default TimetableGenerator;
