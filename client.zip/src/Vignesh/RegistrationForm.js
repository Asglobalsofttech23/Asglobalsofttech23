// import { Grid, TextField } from '@mui/material';
// import React, { useState } from 'react'
// import Vignesh from './Vignesh';

// const RegistrationForm = () =>{
//     const [formData,setFormData] = useState({
//         u_name:''
//     })

//     const [submited, setSubmited] = useState(false)

//     const handleSubmit = (e) =>{
//         setSubmited(true)
//     }

//     return(
//         <>

//         <Grid container>
//             <Grid>
//                 <TextField
//                 label="Enter Your Name"
//                 name='u_name'
//                 value={formData.u_name}
//                 onChange={(e) => setFormData({...formData,u_name:e.target.value})}
//                 />
//             </Grid>
//         </Grid>
//         <button onClick={handleSubmit}>Submit</button>


//        {submited ? (<>
//         <Vignesh name = {formData}/>
//        </>):(<>No Name is avialable</>)}
        
//         </>
//     )
// }

// export default RegistrationForm;




import React from 'react'
import Vignesh from './Vignesh';
import Raja from './Raja';

function RegistrationForm() {
    const name = ["Selva","Raja"]
  return (
    <div>
      <Vignesh variable = {name}/>
      <Raja/>
    </div>
  )
}

export default RegistrationForm
