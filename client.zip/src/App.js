import React, { useEffect, useState } from 'react'
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route ,Navigate } from "react-router-dom";
import axios from 'axios';
import DashboardRouting from './components/Admin Panel/Dashboard/DashboardRouting'
import CustomerTable from './components/Employee Panel/Customer/CustomerTable'
import Login from './components/Login/Login'
import EmployeeIndexRouting from './components/Admin Panel/Employee/EmployeeIndexRouting'
import CustomerIndexRouting from './components/Admin Panel/Customer/CustomerIndexRouting'
import ProjectRouting from './components/Admin Panel/Projects/ProjectRouting'
import AddProject from './components/Admin Panel/Projects/AddProject'
import EntryList from './components/Admin Panel/Attendance/EntryList'
import TaskIndexRouting from './components/Admin Panel/Projects/Task/TaskIndexRouting'
import ModuleIndexRouting from './components/Admin Panel/Projects/Module/ModuleIndexRouting'
import SubModuleIndexRouting from './components/Admin Panel/Projects/Sub Module/SubModuleIndexRouting'
import SingleProjectDashboardRouting from './components/Admin Panel/Projects/Project Dashboard/SingleProjectDashboardRouting'
import WorkingHoursCalculator from './Vignesh/WorkingHoursCalculator'
import SmsSender from './Vignesh/SmsSender'
import CustomerTableRouting from './components/Employee Panel/Customer/CustomerTableRouting';
import CustMainTableRouting from './components/Employee Panel/Customer Maintenance/CustMainTableRouting';
import EmployeeDashboardRouting from './components/Employee Panel/Employee Dashboard/EmployeeDashboardRouting';
import CustomerReportRouter from './components/Employee Panel/Report/CustomerReportRouter';
import LeadsRouting from './components/Admin Panel/Customer/LeadsRouting';
import AdminCustFollowupRouting from './components/Admin Panel/Customer FollowUp/AdminCustFollowupRouting';
import AdminCustMainReportRouting from './components/Admin Panel/Admin Report/AdminCustMainReportRouting';
import LoginRouting from './components/Login/LoginRouting';
import ProjectEmployeeRouting from './components/Admin Panel/Projects/ProjectEmployee/ProjectEmployeeRouting';
import ProjcetTableRouting from './components/Employee Panel/Project/ProjcetTableRouting';
import ProjectTable from './components/Employee Panel/Project/ProjectTable';
import MarketingCustomerRouting from './components/Admin Panel/Marketing Customer/MarketingCustomerRouting';
import MarketingReportRouting from './components/Admin Panel/Marketing Report/MarketingReportRouting';
import config from './config';
import FollowingReportForm from './components/Admin Panel/FollowingReport/FollowingReportForm';
import FollowingReportRouter from './components/Admin Panel/FollowingReport/FollowingReportRouter';
import FollowingDashboard from './components/Admin Panel/Following Data/FollowingDashboard';
import GetUserLocation from './Vignesh/GetUserLocation';
// import Images from './Vignesh/Images';
// import Gallery from './Vignesh/Gallery';


function App() {
  const [employeeIn, setEmployeeIn] = useState(sessionStorage.getItem('employeeLoggedIn') === 'true');
  const [superAdminIn,setSuperAdminIn] = useState(sessionStorage.getItem('adminLoggedIn') === 'true');
  const [employeeData, setEmployeeData] = useState([]);

  useEffect(() => {
   axios.get(`${config.apiUrl}/employees`)
      .then((response) => {
        setEmployeeData(response.data);
      })
      .catch((error) => {
        console.error('Error fetching employee data:', error);
      });
  }, []);

  const handleLogin = (username, password) => {
    const isAdmin = username === 'admin' && password === 'password';

    if (isAdmin) {
      setSuperAdminIn(true);
      sessionStorage.setItem('adminLoggedIn', 'true');
    } else {
      const empData = employeeData.find((employee) => employee.emp_email === username && employee.emp_mobile === password);
      if (empData) {
        setEmployeeIn(true);
        sessionStorage.setItem('employeeLoggedIn', 'true');
        sessionStorage.setItem('emp_id', empData.emp_id);
      } else {
        alert('Invalid username or password');
        return null; // or any appropriate handling for incorrect login
      }
    }
  };
 
  return (
   <div className='App'>

  <BrowserRouter>
  <Routes>
  {/* <Route path="/login" element={<Login handleLogin={handleLogin} />} />
  <Route path="/" element = {employeeIn ? (superAdminIn ? (<DashboardRouting/>):(<EmployeeDashboardRouting />)):(<Login handleLogin={handleLogin}/>)} /> */}

<Route path="/login" element={<LoginRouting handleLogin={handleLogin} />} />
          {superAdminIn ? (
            <Route path="/" element={<DashboardRouting />} />
          ) : employeeIn ? (
            <Route path="/" element={<EmployeeDashboardRouting />} />
          ) : (
            <Route path="/" element={<LoginRouting handleLogin={handleLogin} />} />
          )}
  
  {superAdminIn && (<>
    
    <Route path='/emp_index' element={<EmployeeIndexRouting/>}/>
    <Route path='/cust_index' element={<CustomerIndexRouting/>}/>
    <Route path='/leads_index' element={<LeadsRouting/>}/>
    <Route path='/projectindex' element={<ProjectRouting/>}/>
    <Route path='/addproject' element={<AddProject/>}/>
    <Route path='/empEntry' element={<EntryList/>}/>
    <Route path='/taskindex' element={<TaskIndexRouting/>}/>
    <Route path='/moduleindex' element={<ModuleIndexRouting/>}/>
    <Route path='/submoduleindex' element={<SubModuleIndexRouting/>}/>
    <Route path='/projectDashboard/:proId' element={<SingleProjectDashboardRouting/>}/>
    <Route path='/projectEmployees/:proId' element={<ProjectEmployeeRouting/>}/>
    <Route path='/counter' element={<WorkingHoursCalculator/>}/>
    <Route path='/sms' element={<SmsSender/>}/>
    <Route path='/workinghours' element={<WorkingHoursCalculator/>}/>
    <Route path='/adminCustFollowup' element={<AdminCustFollowupRouting/>}/>
    <Route path='/adminCustmainreport' element={<AdminCustMainReportRouting/>}/>
    <Route path='/markcustomer' element={<MarketingCustomerRouting/>}/>
    <Route path='/marketingreport' element={<MarketingReportRouting/>}/>
    <Route path='/followingreport' element={<FollowingReportRouter/>}/>
    <Route path='/followingdashboard' element={<FollowingDashboard/>}/>

    </>)}


    {employeeIn && (<>
    <Route path="/cust_table" element={<CustomerTableRouting/>} />
    <Route path="/customermaintenance" element={<CustMainTableRouting />} />
    <Route path="/custreport" element={<CustomerReportRouter />} />
    <Route path="/emp_projects" element={<ProjcetTableRouting/>} />
         
    </>)}
  
    
    <Route path="/getlocation" element={<GetUserLocation/>} /> 
            
  </Routes>
  </BrowserRouter>
   </div>
  );
}


export default App;


// Google API KEY

// AIzaSyAmKsnGRWcCvUSPnA9v5P6lICzA_MAzsTA